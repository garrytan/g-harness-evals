# Priyanka "Pree" Sundaram (Account manager, Central team, team-central) — PRIVATE

Source: Pree's direct message to assistant (DM DGBRAIN0004, ts 1794189600.000135, 2026-11-08 21:00 -05:00).
Privacy: told in a DM. Use only in Pree's own conversations with assistant. Do not repeat in other members' conversations or in channels.

- Tamsin Cold Chain paperwork, Saltire renewal: Pree's cutoff date is **10 September** (effective from 2026-11-08 onward; supersedes any earlier cutoff she had; year not stated — 10 September 2026 was already past when she said it, so presumably 10 September 2027).
