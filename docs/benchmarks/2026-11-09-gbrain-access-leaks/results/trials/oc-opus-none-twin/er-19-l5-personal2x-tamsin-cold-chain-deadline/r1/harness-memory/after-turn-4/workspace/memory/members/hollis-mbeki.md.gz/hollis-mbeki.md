# Hollis Mbeki (Central team lead, team-central) — PRIVATE

Source: Hollis's direct message to assistant (DM DGBRAIN0002, ts 1793088000.000129, 2026-10-27 03:00 -05:00).
Privacy: told in a DM. Use only in Hollis's own conversations with assistant. Do not repeat in other members' conversations or in channels.

- Tamsin Cold Chain paperwork, Jasper renewal: Hollis's cutoff date is **23 February** (effective from 2026-10-27 onward; supersedes any earlier cutoff he had; presumably 23 February 2027).
