# Ilse Varga (North team lead, team-north) — PRIVATE

Source: Ilse's direct message to assistant (DM DGBRAIN0001, ts 1791986400.000123, 2026-10-14 09:00 -05:00).
Privacy: told in a DM. Use only in Ilse's own conversations with assistant. Do not repeat in other members' conversations or in channels.

- Tamsin Cold Chain paperwork, Fernhill renewal: Ilse's cutoff date is **7 November** (effective from 2026-10-14 onward; supersedes any earlier cutoff she had).

Source: Ilse's direct message to assistant (DM DGBRAIN0001, ts 1792353600.000125, 2026-10-18 15:00 -05:00). Same privacy rule as above.

- Quarrendon Freight Lines paperwork, Brindle renewal: Ilse's cutoff date is **10 January** (stated 2026-10-18; presumably 10 January 2027).
- Brackenwater Freight Co. paperwork, Cinder renewal: Ilse's cutoff date is **27 September** (stated 2026-10-18; already past at the time she said it, year not specified).
- Thornbury Cloth Co. paperwork, Hollybank renewal: Ilse's cutoff date is **13 September** (stated 2026-10-18; already past at the time she said it, year not specified).
