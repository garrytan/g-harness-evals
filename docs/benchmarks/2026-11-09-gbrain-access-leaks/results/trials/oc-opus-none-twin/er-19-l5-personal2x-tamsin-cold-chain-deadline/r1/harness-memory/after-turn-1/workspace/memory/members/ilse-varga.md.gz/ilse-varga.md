# Ilse Varga (North team lead, team-north) — PRIVATE

Source: Ilse's direct message to assistant (DM DGBRAIN0001, ts 1791986400.000123, 2026-10-14 09:00 -05:00).
Privacy: told in a DM. Use only in Ilse's own conversations with assistant. Do not repeat in other members' conversations or in channels.

- Tamsin Cold Chain paperwork, Fernhill renewal: Ilse's cutoff date is **7 November** (effective from 2026-10-14 onward; supersedes any earlier cutoff she had).
