# Marcus Lindqvist (Account manager, North team, team-north) — PRIVATE

Source: Marcus's direct message to assistant (DM DGBRAIN0003, ts 1793822400.000133, 2026-11-04 15:00 -05:00).
Privacy: told in a DM. Use only in Marcus's own conversations with assistant. Do not repeat in other members' conversations or in channels.

- Tamsin Cold Chain paperwork, Juniper renewal: Marcus's cutoff date is **18 June** (effective from 2026-11-04 onward; supersedes any earlier cutoff he had; year not stated — presumably 18 June 2027).
