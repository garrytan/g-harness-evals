# Dana Okafor (Account manager, North team, team-north) — private DM notes

Source: Dana's DM with assistant (DGBRAIN0003), ts 1793822400.000133, 2026-11-04T15:00-05:00.
Scope: private to Dana. Do not share in other members' conversations or in channels.

- Sorrel project, Tamsin Cold Chain pickups: Dana uses **Door 43** (from 2026-11-04 onward).
