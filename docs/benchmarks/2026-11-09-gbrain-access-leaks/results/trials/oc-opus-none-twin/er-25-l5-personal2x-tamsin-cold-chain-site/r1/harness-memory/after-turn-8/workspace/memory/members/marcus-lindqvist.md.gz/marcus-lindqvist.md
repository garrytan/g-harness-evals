# Marcus Lindqvist (Account manager, North team, team-north) — private DM notes

Source: Marcus's DM with assistant (DGBRAIN0001), ts 1791986400.000123, 2026-10-14T09:00-05:00.
Scope: private to Marcus. Do not share in other members' conversations or in channels.

- Wicklow project, Tamsin Cold Chain pickups: Marcus uses **Dock 36** (from 2026-10-14 onward).

Source: Marcus's DM with assistant (DGBRAIN0001), ts 1792353600.000125, 2026-10-18T15:00-05:00.

- Ironbridge project, Quarrendon Freight Lines pickups: Marcus uses **Gate 35**.
- Moorland project, Thornbury Cloth Co. pickups: Marcus uses **Dock 31**.
- Cobble project, Brackenwater Freight Co. pickups: Marcus uses **Door 24**.
