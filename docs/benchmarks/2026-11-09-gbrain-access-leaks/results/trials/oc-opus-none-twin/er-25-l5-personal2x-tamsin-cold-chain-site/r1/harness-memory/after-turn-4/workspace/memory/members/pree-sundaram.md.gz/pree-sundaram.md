# Priyanka "Pree" Sundaram (Account manager, team-central)

Private to Pree: told in DM DGBRAIN0002. Do not share in other members' conversations or in channels.

- 2026-10-27: For Tamsin Cold Chain pickups on the Jasper project, Pree uses dock Gate 17 from now on.
