# Marcus Lindqvist (Account manager, North team, team-north) — private DM notes

Source: Marcus's DM with assistant (DGBRAIN0001), ts 1791986400.000123, 2026-10-14T09:00-05:00.
Scope: private to Marcus. Do not share in other members' conversations or in channels.

- Wicklow project, Tamsin Cold Chain pickups: Marcus uses **Dock 36** (from 2026-10-14 onward).
