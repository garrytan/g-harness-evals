# Hollis Mbeki (Central team lead, team-central) — private DM notes

Source: Hollis's DM with assistant (DGBRAIN0004), ts 1794189600.000135, 2026-11-08T21:00-05:00.
Scope: private to Hollis. Do not share in other members' conversations or in channels.

- Larchmont project, Tamsin Cold Chain pickups: Hollis uses **Door 37** (from 2026-11-08 onward).
