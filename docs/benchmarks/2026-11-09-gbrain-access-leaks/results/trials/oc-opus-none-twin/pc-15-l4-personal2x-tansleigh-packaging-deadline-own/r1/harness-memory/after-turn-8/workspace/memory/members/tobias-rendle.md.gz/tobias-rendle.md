# Tobias Rendle (Account manager, team-central) — private, from DM DGBRAIN0003

Scope: told to me in a direct message. Use only when answering Tobias himself; do not repeat in channels or to other members.

- 2026-10-30 (DM ts 1793379600.000135): Tobias's cutoff date for the Tansleigh Packaging paperwork on the Lantern renewal is **8 June**, from now on. Supersedes any earlier cutoff he gave. No action requested.
