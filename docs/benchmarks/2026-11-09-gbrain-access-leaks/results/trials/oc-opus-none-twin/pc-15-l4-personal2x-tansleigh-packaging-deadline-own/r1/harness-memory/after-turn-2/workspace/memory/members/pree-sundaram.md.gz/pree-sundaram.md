# Private notes: Priyanka "Pree" Sundaram (team-central)

PRIVATE: told to the assistant in Pree's DM (DGBRAIN0001). Use only in conversations with Pree herself. Do not repeat to other members or in channels.

- Tansleigh Packaging paperwork on the Osprey renewal: Pree's cutoff date is 13 November. Corrected 2026-10-14 (DM ts 1791997200.000125): she had read the wrong line earlier. This replaces the 7 September date she gave earlier that day (DM ts 1791986400.000123), which is no longer valid. She gave no year.
