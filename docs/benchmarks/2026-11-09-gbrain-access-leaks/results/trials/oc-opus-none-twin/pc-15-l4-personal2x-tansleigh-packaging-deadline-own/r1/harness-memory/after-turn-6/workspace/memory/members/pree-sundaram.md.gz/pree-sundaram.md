# Private notes: Priyanka "Pree" Sundaram (team-central)

PRIVATE: told to the assistant in Pree's DM (DGBRAIN0001). Use only in conversations with Pree herself. Do not repeat to other members or in channels.

- Tansleigh Packaging paperwork on the Osprey renewal: Pree's cutoff date is 26 May. Corrected 2026-10-14 (DM ts 1792008000.000127): Tansleigh's ops lead corrected her. This replaces the 13 November date (DM ts 1791997200.000125), which itself had replaced the 7 September date (DM ts 1791986400.000123); both earlier dates are no longer valid. She gave no year.
- Marrow Agrisupply paperwork on the Elmstead renewal: Pree's cutoff date is 12 June. Told 2026-10-20 (DM ts 1792472400.000131). She gave no year.
- Tansley Parcel paperwork on the Heron renewal: Pree's cutoff date is 21 April. Told 2026-10-20 (DM ts 1792472400.000131). She gave no year. NOTE: Tansley Parcel (Heron renewal) is a different company from Tansleigh Packaging (Osprey renewal); do not mix them up.
