# Private notes: Priyanka "Pree" Sundaram (team-central)

PRIVATE: told to the assistant in Pree's DM (DGBRAIN0001). Use only in conversations with Pree herself. Do not repeat to other members or in channels.

- Tansleigh Packaging paperwork on the Osprey renewal: Pree's cutoff date is 7 September, going forward ("from now on"). Supersedes any earlier cutoff she gave. Stated 2026-10-14 (DM ts 1791986400.000123); no year was given, she means 7 September as a standing date.
