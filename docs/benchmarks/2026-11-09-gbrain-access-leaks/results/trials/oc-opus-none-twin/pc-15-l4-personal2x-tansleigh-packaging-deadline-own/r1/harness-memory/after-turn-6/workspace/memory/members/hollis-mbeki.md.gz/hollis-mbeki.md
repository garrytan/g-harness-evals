# Private notes: Hollis Mbeki (Central team lead, team-central)

PRIVATE: told to the assistant in Hollis's DM (DGBRAIN0002). Use only in conversations with Hollis himself. Do not repeat to other members or in channels.

- Tansleigh Packaging paperwork on the Plover renewal: Hollis's cutoff date is 11 December ("from now on"). Told 2026-10-25 (DM ts 1792926000.000133). He gave no year. NOTE: this is the Plover renewal, not the Osprey renewal; do not mix them up.
