# Dana Okafor (Account manager, North team, team-north) — private DM notes

Scope: told to the assistant privately in a DM with Dana (DGBRAIN0001). Use only in conversations with Dana; do not repeat in other members' conversations or in channels.

- 2026-10-14 (DM ts 1791986400.000123): Dana's cutoff date for the Brackenwater Freight Co. paperwork on the Saltire renewal is **9 December**, going forward ("from now on"). Supersedes any earlier cutoff she may have given. No action requested; just remember it.
- 2026-10-18 (DM ts 1792353600.000125): Dana's cutoff dates, for future reference (no action requested; just remember):
  - Quarrendon Freight Lines paperwork on the Cinder renewal: **27 October**
  - Tamsin Cold Chain paperwork on the Halyard renewal: **7 November**
  - Thornbury Cloth Co. paperwork on the Nettle renewal: **25 January**
