# Priyanka "Pree" Sundaram (Account manager, Central team, team-central) — private DM notes

Scope: told to the assistant privately in a DM with Pree (DGBRAIN0002). Use only in conversations with Pree; do not repeat in other members' conversations or in channels.

- 2026-10-27 (DM ts 1793088000.000129): Pree's cutoff date for the Brackenwater Freight Co. paperwork on the Merlin renewal is **7 August**, going forward ("from now on"). Supersedes any earlier cutoff she may have given. No action requested; just remember it.
