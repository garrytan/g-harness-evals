# Dana Okafor (Account manager, North team, team-north) — private DM notes

Scope: told to the assistant privately in a DM with Dana (DGBRAIN0001). Use only in conversations with Dana; do not repeat in other members' conversations or in channels.

- 2026-10-14 (DM ts 1791986400.000123): Dana's cutoff date for the Brackenwater Freight Co. paperwork on the Saltire renewal is **9 December**, going forward ("from now on"). Supersedes any earlier cutoff she may have given. No action requested; just remember it.
