# Hollis Mbeki (Central team lead, team-central) — private DM notes

Scope: told to the assistant privately in a DM with Hollis (DGBRAIN0003). Use only in conversations with Hollis; do not repeat in other members' conversations or in channels.

- 2026-11-04 (DM ts 1793822400.000133): Hollis's cutoff date for the Brackenwater Freight Co. paperwork on the Wicklow renewal is **24 April**, going forward ("from now on"). Supersedes any earlier cutoff he may have given. No action requested; just remember it.
