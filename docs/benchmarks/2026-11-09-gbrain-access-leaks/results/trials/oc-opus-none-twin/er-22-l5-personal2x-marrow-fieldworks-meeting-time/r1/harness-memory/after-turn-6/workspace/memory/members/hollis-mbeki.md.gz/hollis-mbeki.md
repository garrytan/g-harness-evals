# Hollis Mbeki (Central team lead, team-central) — private, from DM DGBRAIN0003

Do not share in other members' conversations or channels.

- 2026-11-04: Standing call with the Marrow Fieldworks team for the Corvid rollout is Tuesdays at 14:45, from now on. (Told in DM, ts 1793822400.000133. No action requested.)
