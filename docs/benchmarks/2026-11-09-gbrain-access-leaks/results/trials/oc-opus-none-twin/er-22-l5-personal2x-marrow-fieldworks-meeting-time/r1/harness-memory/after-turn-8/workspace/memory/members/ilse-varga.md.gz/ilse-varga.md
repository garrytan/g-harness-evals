# Ilse Varga (North team lead, team-north): private, from DM DGBRAIN0004

Do not share in other members' conversations or channels.

- 2026-11-08: Ilse's standing call with the **Marrow Fieldworks** team for the **Gannet** rollout is **Thursdays at 11:15**, from now on. She said no action was needed; she only asked me to remember it. (Source: DM ts 1794189600.000135)
  - This is separate from other members' Marrow Fieldworks calls for other rollouts. Keep them apart.
