# Tobias Rendle (Account manager, Central team, team-central) — private DM notes

Told to me privately in DM DGBRAIN0001. Use only in Tobias's own conversations. Don't share with other members or post in channels.

- 2026-10-14: Tobias's standing call with the Marrow Fieldworks team for the Saltire rollout is now **Mondays at 13:30**, starting now. He said no action was needed; he only asked me to remember it. (Source: DM ts 1791986400.000123)
