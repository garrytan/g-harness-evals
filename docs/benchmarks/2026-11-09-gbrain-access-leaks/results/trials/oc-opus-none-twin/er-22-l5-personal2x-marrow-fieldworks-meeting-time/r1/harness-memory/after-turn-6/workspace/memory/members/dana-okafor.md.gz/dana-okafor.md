# Dana Okafor (Account manager, North team, team-north) — private DM notes

Told to me privately in DM DGBRAIN0002. Use only in Dana's own conversations. Don't share with other members or post in channels.

- 2026-10-27: Dana's standing call with the **Marrow Fieldworks** team for the **Linden** rollout is now **Mondays at 16:15**, going forward. She said no action was needed; she only asked me to remember it. (Source: DM ts 1793088000.000129)
  - Not the same as Tobias Rendle's Marrow Fieldworks / Saltire call. Keep them separate.
