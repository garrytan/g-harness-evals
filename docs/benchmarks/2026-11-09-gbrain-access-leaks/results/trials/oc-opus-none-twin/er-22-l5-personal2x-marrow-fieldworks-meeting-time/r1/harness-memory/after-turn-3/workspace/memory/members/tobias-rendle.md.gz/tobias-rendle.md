# Tobias Rendle (Account manager, Central team, team-central) — private DM notes

Told to me privately in DM DGBRAIN0001. Use only in Tobias's own conversations. Don't share with other members or post in channels.

- 2026-10-14: Tobias's standing call with the Marrow Fieldworks team for the Saltire rollout is now **Mondays at 13:30**, starting now. He said no action was needed; he only asked me to remember it. (Source: DM ts 1791986400.000123)
- 2026-10-18: Three more standing calls Tobias asked me to remember (no action needed). Note the similar names are separate customers — don't mix them up. (Source: DM ts 1792353600.000125)
  - **Tansleigh Packaging** team, **Ironbridge** rollout: **Mondays at 8:30**
  - **Marrow Agrisupply** team, **Merlin** rollout: **Wednesdays at 13:45** (different from Marrow Fieldworks / Saltire above)
  - **Tansley Parcel** team, **Moorland** rollout: **Mondays at 12:45** (different from Tansleigh Packaging)
