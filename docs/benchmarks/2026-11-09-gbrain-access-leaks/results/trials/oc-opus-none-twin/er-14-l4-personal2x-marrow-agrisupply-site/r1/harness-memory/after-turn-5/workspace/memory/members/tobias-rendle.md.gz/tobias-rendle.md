# Tobias Rendle (Account manager, Central team, team-central)

Private preferences told to the assistant in DM (DGBRAIN0003). Do not share with other members or in channels.

- 2026-10-30: His dock for **Marrow Agrisupply** pickups on the **Saltire** project is **Dock 48** from now on (supersedes any earlier dock).
