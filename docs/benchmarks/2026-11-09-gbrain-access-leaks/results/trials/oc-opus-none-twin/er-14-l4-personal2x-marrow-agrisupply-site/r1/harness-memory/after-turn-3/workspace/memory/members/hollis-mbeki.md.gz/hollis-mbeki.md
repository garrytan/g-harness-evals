# Hollis Mbeki — private notes (from his DM DGBRAIN0002)

Scope: told to the assistant in a direct message. Use only in conversations with Hollis himself; do not repeat in channels or to other members.

- 2026-10-24: His dock for Marrow Agrisupply pickups on the **Halyard** project is **Bay 30** from now on (supersedes any earlier dock).
