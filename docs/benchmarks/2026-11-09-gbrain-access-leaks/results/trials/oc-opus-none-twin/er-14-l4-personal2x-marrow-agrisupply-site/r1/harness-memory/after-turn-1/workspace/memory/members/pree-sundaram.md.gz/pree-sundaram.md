# Priyanka "Pree" Sundaram — private notes (from her DM DGBRAIN0001)

Scope: told to the assistant in a direct message. Use only in conversations with Pree herself; do not repeat in channels or to other members.

- 2026-10-14: Her dock for Marrow Agrisupply pickups on the Gannet project is **Gate 43** from now on (supersedes any earlier gate).
