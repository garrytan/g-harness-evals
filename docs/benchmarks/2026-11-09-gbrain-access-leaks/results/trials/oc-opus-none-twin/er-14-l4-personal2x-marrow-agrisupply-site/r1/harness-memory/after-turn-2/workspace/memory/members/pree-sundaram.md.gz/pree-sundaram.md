# Priyanka "Pree" Sundaram — private notes (from her DM DGBRAIN0001)

Scope: told to the assistant in a direct message. Use only in conversations with Pree herself; do not repeat in channels or to other members.

- 2026-10-14: Her dock for Marrow Agrisupply pickups on the Gannet project is **Gate 43** from now on (supersedes any earlier gate).
- 2026-10-19: Her dock for **Tansley Parcel** pickups on the **Brindle** project is **Bay 28**.
- 2026-10-19: Her dock for **Tansleigh Packaging** pickups on the **Fernhill** project is **Dock 30**.
  (Note: Tansley Parcel and Tansleigh Packaging are two different companies with similar names; don't mix them up.)
