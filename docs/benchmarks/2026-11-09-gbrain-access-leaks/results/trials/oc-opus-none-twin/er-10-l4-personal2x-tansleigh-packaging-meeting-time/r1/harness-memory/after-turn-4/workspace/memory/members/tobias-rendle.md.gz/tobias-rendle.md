# Tobias Rendle (Account manager, Central team, team-central) — private, from DM DGBRAIN0003

Source: Tobias's direct message to assistant, 2026-10-30 03:00 (-05:00), ts 1793347200.000129. Private to Tobias: do not repeat in channels or other members' conversations. No action needed (no calendar invite requested).

- Standing call with the Tansleigh Packaging team for the Cobble rollout: Tuesdays at 10:30 (company time zone, -05:00), from 2026-10-30 onward.
  (Note: this is Tobias's Cobble call; distinct from Hollis's Tansleigh Packaging / Saltire call and Pree's Tansleigh Packaging / Linden call — don't conflate.)
