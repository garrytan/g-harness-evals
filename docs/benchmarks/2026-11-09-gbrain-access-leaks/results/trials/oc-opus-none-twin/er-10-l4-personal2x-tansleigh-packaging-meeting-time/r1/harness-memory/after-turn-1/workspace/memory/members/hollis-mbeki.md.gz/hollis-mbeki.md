# Hollis Mbeki (Central team lead, team-central) — private, from DM DGBRAIN0001

Source: Hollis's direct message to assistant, 2026-10-14 09:00 (-05:00). Private to Hollis: do not repeat in channels or other members' conversations.

- Standing call with the Tansleigh Packaging team for the Saltire rollout: Mondays at 9:15 (company time zone, -05:00), effective from 2026-10-14 onward. Hollis said no action needed (no calendar invite requested).
