# Priyanka "Pree" Sundaram (Account manager, Central team, team-central) — private, from DM DGBRAIN0002

Source: Pree's direct message to assistant, 2026-10-24 21:00 (-05:00), ts 1792893600.000127. Private to Pree: do not repeat in channels or other members' conversations. No action needed (no calendar invite requested).

- Standing call with the Tansleigh Packaging team for the Linden rollout: Fridays at 12:45 (company time zone, -05:00), from 2026-10-24 onward.
  (Note: this is Pree's Linden call; distinct from Hollis's Tansleigh Packaging / Saltire call and from Tansley Parcel / Greywater — don't conflate.)
