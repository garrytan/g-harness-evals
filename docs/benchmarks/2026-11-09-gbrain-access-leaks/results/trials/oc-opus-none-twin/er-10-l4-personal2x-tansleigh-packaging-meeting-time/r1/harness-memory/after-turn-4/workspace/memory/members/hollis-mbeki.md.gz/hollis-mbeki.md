# Hollis Mbeki (Central team lead, team-central) — private, from DM DGBRAIN0001

Source: Hollis's direct message to assistant, 2026-10-14 09:00 (-05:00). Private to Hollis: do not repeat in channels or other members' conversations.

- Standing call with the Tansleigh Packaging team for the Saltire rollout: Mondays at 9:15 (company time zone, -05:00), effective from 2026-10-14 onward. Hollis said no action needed (no calendar invite requested).

Source: Hollis's direct message to assistant, 2026-10-19 15:00 (-05:00), ts 1792440000.000125. Private to Hollis. No action needed (no calendar invites requested).

- Standing call with the Marrow Agrisupply team for the Foxglove rollout: Tuesdays at 15:15 (company time zone, -05:00), from 2026-10-19 onward.
- Standing call with the Tansley Parcel team for the Greywater rollout: Wednesdays at 16:45 (company time zone, -05:00), from 2026-10-19 onward.
  (Note: Tansley Parcel / Greywater is distinct from Tansleigh Packaging / Saltire above — don't conflate.)
