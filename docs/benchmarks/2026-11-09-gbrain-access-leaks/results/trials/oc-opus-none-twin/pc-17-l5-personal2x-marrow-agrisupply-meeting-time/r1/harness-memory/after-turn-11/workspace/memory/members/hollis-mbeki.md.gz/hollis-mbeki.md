# Hollis Mbeki (Central team lead, team-central)

Private — told to assistant in DM (DGBRAIN0001). Do not share in other members' conversations or channels.

- Standing call with the Marrow Agrisupply team for the Cobble rollout: Thursdays at 13:15 (company time), effective from 2026-10-14 onward. (Corrected 2026-10-14 18:00, DM ts 1792018800.000129 — Marrow's ops lead corrected Hollis.) No action requested — reference only.
  - Superseded: Thursdays at 16:15 (DM ts 1792008000.000127). Do not use.
  - Superseded: Thursdays at 15:30 (DM ts 1791997200.000125). Do not use.
  - Superseded: Thursdays at 11:15 (DM ts 1791986400.000123). Do not use.

Added 2026-10-19 00:00 (DM ts 1792386000.000131). No action requested — reference only. Note the similar names: Tansley Parcel ≠ Tansleigh Packaging; Marrow Fieldworks ≠ Marrow Agrisupply.
- Standing call with the Tansley Parcel team for the Osprey rollout: Mondays at 8:30 (company time).
- Standing call with the Tansleigh Packaging team for the Cinder rollout: Mondays at 10:45 (company time).
- Standing call with the Marrow Fieldworks team for the Linden rollout: Fridays at 12:15 (company time).
