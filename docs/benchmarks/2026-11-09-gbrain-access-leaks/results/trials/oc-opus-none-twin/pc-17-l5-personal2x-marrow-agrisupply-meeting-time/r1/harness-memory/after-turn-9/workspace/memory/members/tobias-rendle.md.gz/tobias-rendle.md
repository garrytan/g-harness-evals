# Tobias Rendle (Account manager, Central team, team-central)

Private — told to assistant in DM (DGBRAIN0002). Do not share in other members' conversations or channels.

- Standing call with the Marrow Agrisupply team for the Quillon rollout: Tuesdays at 11:30 (company time), effective from 2026-10-27 onward. (DM ts 1793120400.000135, 2026-10-27 12:00 -05:00.) No action requested — reference only.
  - Note similar names: Marrow Agrisupply ≠ Marrow Fieldworks.
