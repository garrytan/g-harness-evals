# Hollis Mbeki (Central team lead, team-central)

Private — told to assistant in DM (DGBRAIN0001). Do not share in other members' conversations or channels.

- Standing call with the Marrow Agrisupply team for the Cobble rollout: Thursdays at 15:30 (company time), effective from 2026-10-14 onward. (Corrected 2026-10-14, DM ts 1791997200.000125 — Hollis had read the wrong line earlier.) No action requested — reference only.
  - Superseded: earlier note said Thursdays at 11:15 (DM ts 1791986400.000123). Do not use.
