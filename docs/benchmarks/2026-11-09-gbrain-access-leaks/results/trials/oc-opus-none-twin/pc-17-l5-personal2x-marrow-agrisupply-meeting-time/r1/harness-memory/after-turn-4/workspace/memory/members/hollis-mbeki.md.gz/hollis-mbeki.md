# Hollis Mbeki (Central team lead, team-central)

Private — told to assistant in DM (DGBRAIN0001). Do not share in other members' conversations or channels.

- Standing call with the Marrow Agrisupply team for the Cobble rollout: Thursdays at 13:15 (company time), effective from 2026-10-14 onward. (Corrected 2026-10-14 18:00, DM ts 1792018800.000129 — Marrow's ops lead corrected Hollis.) No action requested — reference only.
  - Superseded: Thursdays at 16:15 (DM ts 1792008000.000127). Do not use.
  - Superseded: Thursdays at 15:30 (DM ts 1791997200.000125). Do not use.
  - Superseded: Thursdays at 11:15 (DM ts 1791986400.000123). Do not use.
