# Priyanka "Pree" Sundaram (Account manager, team-central) — private, DM-only

Told to me in DM DGBRAIN0003 (ts 1793854800.000139, 2026-11-05). Do not share in other members' conversations or channels.

- Standing call with the Marrow Agrisupply team for the Wicklow rollout: Fridays at 11:45, going forward (from 2026-11-05). No action requested; for reference only.
