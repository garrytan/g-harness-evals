# Marcus Lindqvist (Account manager, North team, team-north) — private, from DM DGBRAIN0002

Confidential to Marcus: told in a direct message. Do not repeat in other members' conversations or in channels.

- Brackenwater Freight Co. paperwork cutoff date on the Wicklow renewal: **16 October** (stated 2026-10-27, msg ts 1793088000.000129; "from now on", so it replaces any earlier date).
