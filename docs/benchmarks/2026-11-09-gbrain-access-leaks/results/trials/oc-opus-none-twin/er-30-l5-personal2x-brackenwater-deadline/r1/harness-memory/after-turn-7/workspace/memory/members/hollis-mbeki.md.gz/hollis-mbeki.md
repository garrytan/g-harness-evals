# Hollis Mbeki (Central team lead, team-central) — private, from DM DGBRAIN0004

Confidential to Hollis: told in a direct message. Do not repeat in other members' conversations or in channels.

- Brackenwater Freight Co. paperwork cutoff date on the Marlowe renewal: **8 June** (stated 2026-11-08, msg ts 1794189600.000135; "from now on", so it replaces any earlier date).
