# Ilse Varga (North team lead, team-north) — private, from DM DGBRAIN0001

Confidential to Ilse: told in a direct message. Do not repeat in other members' conversations or in channels.

- Brackenwater Freight Co. paperwork cutoff date on the Tamarack renewal: **22 January** (stated 2026-10-14, msg ts 1791986400.000123; "from now on" — supersedes any earlier date).
- Thornbury Cloth Co. paperwork cutoff date on the Greywater renewal: **3 July** (stated 2026-10-18, msg ts 1792353600.000125).
- Quarrendon Freight Lines paperwork cutoff date on the Gannet renewal: **25 September** (stated 2026-10-18, msg ts 1792353600.000125).
- Tamsin Cold Chain paperwork cutoff date on the Hollybank renewal: **3 August** (stated 2026-10-18, msg ts 1792353600.000125).
