# Ilse Varga — private notes (from DM DGBRAIN0003)

Private to Ilse (North team lead, team-north). Do not share in other members' conversations or in channels.

## Standing calls (told 2026-11-04; times as stated, time zone not specified)
- Tansley Parcel team, Petrel rollout: Mondays 12:15 ("from now on")
