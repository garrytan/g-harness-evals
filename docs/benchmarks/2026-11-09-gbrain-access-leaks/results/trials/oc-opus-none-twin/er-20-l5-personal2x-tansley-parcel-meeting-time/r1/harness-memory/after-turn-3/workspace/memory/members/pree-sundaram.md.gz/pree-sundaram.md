# Priyanka "Pree" Sundaram — private notes (from DM DGBRAIN0001)

Private to Pree. Do not share in other members' conversations or in channels.

## Standing calls (told 2026-10-18; times as stated, time zone not specified)
- Marrow Agrisupply team, Saltire rollout: Wednesdays 9:30
- Tansleigh Packaging team, Kestrel rollout: Fridays 11:45
- Marrow Fieldworks team, Ironbridge rollout: Wednesdays 14:45
