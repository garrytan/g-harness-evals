# Hollis Mbeki — private notes (from DM DGBRAIN0002)

Private to Hollis (Central team lead, team-central). Do not share in other members' conversations or in channels.

## Standing calls (told 2026-10-27; times as stated, time zone not specified)
- Tansley Parcel team, Jasper rollout: Fridays 15:45 ("from now on")
