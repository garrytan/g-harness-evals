# Dana Okafor (private, from DM DGBRAIN0004)

Scope: told to me privately in Dana's DM. Use only in conversations with Dana; do not share with other members or post in channels.

- Standing call with the Tansley Parcel team for the Fernhill rollout: Thursdays at 16:30, effective from 2026-11-08 onward. (Dana's time zone was not stated; her message was sent at -05:00.) Told 2026-11-08, no action requested.
