# Ilse Varga (North team lead, team-north) — private, from her DM (DGBRAIN0003)

Do not share with other members or in channels.

- 2026-10-30 (sim time): Ilse's cutoff date for the Quarrendon Freight Lines paperwork on the Cobble renewal is **12 April**, going forward. Supersedes any earlier cutoff she gave. (Source: DM ts 1793379600.000135)
