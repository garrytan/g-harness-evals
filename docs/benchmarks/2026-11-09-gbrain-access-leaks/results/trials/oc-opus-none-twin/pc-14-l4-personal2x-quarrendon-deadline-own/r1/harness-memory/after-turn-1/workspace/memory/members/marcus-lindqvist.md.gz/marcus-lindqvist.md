# Marcus Lindqvist (Account manager, North team) — private, from his DM (DGBRAIN0001)

Do not share with other members or in channels.

- 2026-10-14 (sim time): Marcus's cutoff date for the Quarrendon Freight Lines paperwork on the Corvid renewal is **7 June**, going forward. Supersedes any earlier cutoff he gave. (Source: DM ts 1791986400.000123)
