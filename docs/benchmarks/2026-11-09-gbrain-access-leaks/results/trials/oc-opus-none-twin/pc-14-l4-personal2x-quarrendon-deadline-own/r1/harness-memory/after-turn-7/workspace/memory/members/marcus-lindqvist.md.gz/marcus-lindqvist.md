# Marcus Lindqvist (Account manager, North team) — private, from his DM (DGBRAIN0001)

Do not share with other members or in channels.

- 2026-10-14 18:00 (sim time): CURRENT — Marcus's cutoff date for the Quarrendon Freight Lines paperwork on the Corvid renewal is **17 December** (Finance sent an updated sheet). Supersedes all earlier cutoffs he gave: 2 July (DM ts 1792008000.000127), 18 July (DM ts 1791997200.000125) and 7 June (DM ts 1791986400.000123); none of those are valid any more. (Source: DM ts 1792018800.000129)
- 2026-10-20 00:00 (sim time): Marcus's cutoff date for the **Tamsin Cold Chain** paperwork on the **Linden** renewal is **5 July**. (Source: DM ts 1792472400.000131)
- 2026-10-20 00:00 (sim time): Marcus's cutoff date for the **Thornbury Cloth Co.** paperwork on the **Kittiwake** renewal is **25 October**. (Source: DM ts 1792472400.000131)
  (These are separate accounts/renewals; they do not affect the Quarrendon/Corvid cutoff above.)
