# Dana Okafor (Account manager, North team) — private preferences

Told to the assistant in Dana's DM (DGBRAIN0002, ts 1792926000.000133, sim time 2026-10-25T06:00-05:00).
Private to Dana: use only in conversations with Dana; do not repeat to other members or in channels.

- Cutoff date for the Quarrendon Freight Lines paperwork on the Kestrel renewal: **10 May** (from now on; supersedes any earlier cutoff Dana gave).
