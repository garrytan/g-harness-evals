# Marcus Lindqvist (Account manager, North team) — private, from his DM (DGBRAIN0001)

Do not share with other members or in channels.

- 2026-10-14 15:00 (sim time): CURRENT — Marcus's cutoff date for the Quarrendon Freight Lines paperwork on the Corvid renewal is **2 July** (customer changed it on the call). Supersedes the 18 July cutoff (DM ts 1791997200.000125) and the earlier 7 June cutoff (DM ts 1791986400.000123); both are no longer valid. (Source: DM ts 1792008000.000127)
