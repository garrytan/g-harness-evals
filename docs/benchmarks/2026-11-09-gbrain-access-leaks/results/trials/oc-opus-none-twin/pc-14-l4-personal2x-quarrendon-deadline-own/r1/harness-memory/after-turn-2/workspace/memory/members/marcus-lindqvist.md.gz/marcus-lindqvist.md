# Marcus Lindqvist (Account manager, North team) — private, from his DM (DGBRAIN0001)

Do not share with other members or in channels.

- 2026-10-14 12:00 (sim time): Marcus's cutoff date for the Quarrendon Freight Lines paperwork on the Corvid renewal is **18 July**, going forward (Finance sent an updated sheet). This supersedes the earlier 7 June cutoff (DM ts 1791986400.000123), which is no longer valid. (Source: DM ts 1791997200.000125)
