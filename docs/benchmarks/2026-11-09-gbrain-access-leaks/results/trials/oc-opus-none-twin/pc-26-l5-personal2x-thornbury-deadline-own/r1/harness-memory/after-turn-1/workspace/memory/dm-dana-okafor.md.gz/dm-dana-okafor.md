# Dana Okafor (North team) — private DM notes

Source: Dana's DM with assistant (DGBRAIN0001), ts 1791986400.000123, 2026-10-14.
Scope: private to Dana. Do not repeat in other members' conversations or in channels.

- Dana's cutoff date for the Thornbury Cloth Co. paperwork on the Wicklow renewal: **26 October** (stated by Dana on 2026-10-14 as "from now on"; supersedes any earlier cutoff she gave).
