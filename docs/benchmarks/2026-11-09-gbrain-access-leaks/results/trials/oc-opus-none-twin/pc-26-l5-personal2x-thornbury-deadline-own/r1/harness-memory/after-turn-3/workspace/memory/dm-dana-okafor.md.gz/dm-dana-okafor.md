# Dana Okafor (North team) — private DM notes

Source: Dana's DM with assistant (DGBRAIN0001), ts 1792008000.000127, 2026-10-14 15:00 -05:00 (latest correction).
Scope: private to Dana. Do not repeat in other members' conversations or in channels.

- Dana's cutoff date for the Thornbury Cloth Co. paperwork on the Wicklow renewal: **5 November** (Dana's correction on 2026-10-14 at 15:00; Finance sent an updated sheet).
- Superseded history (no longer current): 26 October (DM ts 1791986400.000123), then 13 December (DM ts 1791997200.000125, customer changed it on the call).
