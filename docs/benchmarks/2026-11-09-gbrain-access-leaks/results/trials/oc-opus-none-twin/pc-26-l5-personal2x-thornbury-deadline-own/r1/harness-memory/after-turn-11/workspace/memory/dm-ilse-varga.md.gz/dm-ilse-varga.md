# Ilse Varga (North team lead, team-north) — private DM notes

Source: Ilse's DM with assistant (DGBRAIN0003), ts 1793854800.000139, 2026-11-05.
Scope: private to Ilse. Do not repeat in other members' conversations or in channels.

- Ilse's cutoff date for the Thornbury Cloth Co. paperwork on the Jasper renewal: **25 January** (stated by Ilse on 2026-11-05 as "from now on"; supersedes any earlier cutoff she gave).
