# Marcus Lindqvist (Account manager, North team) — private DM notes

Source: Marcus's DM with assistant (DGBRAIN0002), ts 1793120400.000135, sim time 2026-10-27T12:00-05:00.
Scope: Marcus's own preference, told in a DM. Use only in conversations with Marcus; do not share with other members or in channels.

- Thornbury Cloth Co. paperwork on the Juniper renewal: Marcus's cutoff date is **25 October** (standing, "from now on"). Supersedes any earlier cutoff he gave.
