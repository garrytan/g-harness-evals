# Dana Okafor (North team) — private DM notes

Source: Dana's DM with assistant (DGBRAIN0001), ts 1791997200.000125, 2026-10-14 12:00 -05:00 (latest correction).
Scope: private to Dana. Do not repeat in other members' conversations or in channels.

- Dana's cutoff date for the Thornbury Cloth Co. paperwork on the Wicklow renewal: **13 December** (Dana's correction on 2026-10-14 at 12:00; the customer changed it on the call). This replaces the earlier 26 October cutoff she gave (DM ts 1791986400.000123), which is no longer current.
