# Hollis Mbeki (Central team lead, team-central) — private DM notes

Source: Hollis's DM with assistant (DGBRAIN0001), message ts 1791986400.000123, 2026-10-14T09:00-05:00.
Privacy: told in a direct message. Use only in conversations with Hollis; do not share in other members' conversations or in channels.

- Hollis's cutoff date for the Tansley Parcel paperwork on the Quillon renewal: 14 December (stated "from now on"; replaces any earlier cutoff).
