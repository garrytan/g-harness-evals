# Hollis Mbeki (Central team lead, team-central) — private DM notes

Privacy: told in a direct message (DGBRAIN0001). Use only in conversations with Hollis; do not share in other members' conversations or in channels.

- Hollis's cutoff date for the Tansley Parcel paperwork on the Quillon renewal: 5 June.
  - Source: Hollis's DM, message ts 1792018800.000129, 2026-10-14T18:00-05:00. Correction: Hollis had read the wrong line. Replaces the earlier 23 August cutoff.
  - Superseded: 23 August (DM ts 1792008000.000127, 2026-10-14T15:00-05:00; Finance had sent an updated sheet).
  - Superseded: 2 November (DM ts 1791997200.000125, 2026-10-14T12:00-05:00).
  - Superseded: 14 December (DM ts 1791986400.000123, 2026-10-14T09:00-05:00).
- Hollis's cutoff date for the Marrow Agrisupply paperwork on the Cobble renewal: 26 November.
  - Source: Hollis's DM, message ts 1792386000.000131, 2026-10-19T00:00-05:00.
- Hollis's cutoff date for the Tansleigh Packaging paperwork on the Wicklow renewal: 21 December.
  - Source: Hollis's DM, message ts 1792386000.000131, 2026-10-19T00:00-05:00.
- Hollis's cutoff date for the Marrow Fieldworks paperwork on the Heron renewal: 3 May.
  - Source: Hollis's DM, message ts 1792386000.000131, 2026-10-19T00:00-05:00.
