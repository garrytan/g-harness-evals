# Hollis Mbeki (Central team lead, team-central) — private DM notes

Privacy: told in a direct message (DGBRAIN0001). Use only in conversations with Hollis; do not share in other members' conversations or in channels.

- Hollis's cutoff date for the Tansley Parcel paperwork on the Quillon renewal: 2 November.
  - Source: Hollis's DM, message ts 1791997200.000125, 2026-10-14T12:00-05:00. Correction: Finance sent an updated sheet. Replaces the earlier 14 December cutoff.
  - Superseded: 14 December (DM ts 1791986400.000123, 2026-10-14T09:00-05:00).
