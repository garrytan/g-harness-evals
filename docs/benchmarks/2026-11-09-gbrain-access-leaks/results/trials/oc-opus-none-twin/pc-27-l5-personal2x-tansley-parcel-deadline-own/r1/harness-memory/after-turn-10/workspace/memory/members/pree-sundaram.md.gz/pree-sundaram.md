# Priyanka "Pree" Sundaram (Account manager, Central team, team-central) — private DM notes

Privacy: told in a direct message (DGBRAIN0002). Use only in conversations with Pree; do not share in other members' conversations or in channels.

- Pree's cutoff date for the Tansley Parcel paperwork on the Thistle renewal: 20 August ("from now on").
  - Source: Pree's DM, message ts 1793120400.000135, 2026-10-27T12:00-05:00.
  - Note: distinct from Hollis's Tansley Parcel / Quillon renewal note; do not mix them.
- Pree's cutoff date for the Tansley Parcel paperwork on the Jasper renewal: 27 February ("from now on").
  - Source: Pree's DM, message ts 1794222000.000141, 2026-11-09T06:00-05:00.
  - Note: separate from her Thistle renewal cutoff (20 August) above; the Jasper one does not replace it.
