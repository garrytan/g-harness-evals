# Marcus Lindqvist (Account manager, North team, team-north)

Private: told to assistant in DM (DGBRAIN0001). Only use in conversations with Marcus; do not share in other members' conversations or channels.

- Standing call with the Tamsin Cold Chain team for the Gannet rollout: Mondays at 11:45 (Marcus's local time, -05:00), effective from 2026-10-14 onward. Source: DM ts 1791986400.000123. Marcus said no action needed (no calendar event requested).
