# Marcus Lindqvist (Account manager, North team, team-north)

Private: told to assistant in DM (DGBRAIN0001). Only use in conversations with Marcus; do not share in other members' conversations or channels.

- Standing call with the Tamsin Cold Chain team for the Gannet rollout: Thursdays at 8:15 (Marcus's local time, -05:00). Corrected 2026-10-14 18:00 -05:00; the customer changed it on the call. Source: DM ts 1792018800.000129. Marcus said no action needed (no calendar event requested).
  - Superseded: Mondays at 14:15 (DM ts 1791997200.000125); no longer valid.
  - Superseded: Mondays at 11:45 (DM ts 1791986400.000123); no longer valid.
