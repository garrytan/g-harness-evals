# Marcus Lindqvist (Account manager, North team, team-north)

Private: told to assistant in DM (DGBRAIN0001). Only use in conversations with Marcus; do not share in other members' conversations or channels.

- Standing call with the Tamsin Cold Chain team for the Gannet rollout: Mondays at 14:15 (Marcus's local time, -05:00). Corrected 2026-10-14 per Finance's updated sheet. Source: DM ts 1791997200.000125. Marcus said no action needed (no calendar event requested).
  - Superseded: previously recorded as Mondays at 11:45 (DM ts 1791986400.000123); no longer valid.
