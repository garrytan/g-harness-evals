# Dana Okafor (Account manager, North team, team-north)

Private: told to assistant in DM (DGBRAIN0002). Only use in conversations with Dana; do not share in other members' conversations or channels.

- Standing call with the Tamsin Cold Chain team for the Elmstead rollout: Wednesdays at 12:15 (Dana's local time, -05:00), effective from 2026-10-27 onward. Source: DM ts 1793120400.000135. Dana said no action needed (no calendar event requested).
- Standing call with the Tamsin Cold Chain team for the Bittern rollout: Wednesdays at 12:30 (Dana's local time, -05:00), effective from 2026-11-09 onward. Source: DM ts 1794222000.000141. Dana said no action needed (no calendar event requested). Separate from the Elmstead rollout call above.
