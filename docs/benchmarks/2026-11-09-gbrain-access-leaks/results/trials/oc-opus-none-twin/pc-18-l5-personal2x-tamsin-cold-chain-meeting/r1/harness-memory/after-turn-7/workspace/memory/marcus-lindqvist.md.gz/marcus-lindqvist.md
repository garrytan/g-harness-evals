# Marcus Lindqvist (private DM notes — do not share in other members' conversations or channels)
- 2026-10-14: Standing call with the Tamsin Cold Chain team is Wednesdays at 11:15 (Marcus's correction; supersedes whatever time he gave earlier; per an updated Finance sheet).
