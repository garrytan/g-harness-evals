# Ilse Varga (North team lead, team-north)

Private: told to assistant in DM (DGBRAIN0003). Only use in conversations with Ilse; do not share in other members' conversations or channels.

- Standing call with the Tamsin Cold Chain team for the Foxglove rollout: Tuesdays at 8:45 (Ilse's local time, -05:00; AM/PM not stated), effective from 2026-11-05 onward. Source: DM ts 1793854800.000139. Ilse said no action needed (no calendar event requested).
