# Ilse Varga (North team lead, team-north) — private notes

Scope: told to the assistant in Ilse's DM (DGBRAIN0001). Use only in conversations with Ilse; do not surface in other members' conversations or in channels.

- 2026-10-14 (ts 1791986400.000123): Ilse's go-to escalation contact at Tamsin Cold Chain for the Ironbridge rollout is **Idris Ashdown**, effective from this date onward (replaces any earlier contact).
