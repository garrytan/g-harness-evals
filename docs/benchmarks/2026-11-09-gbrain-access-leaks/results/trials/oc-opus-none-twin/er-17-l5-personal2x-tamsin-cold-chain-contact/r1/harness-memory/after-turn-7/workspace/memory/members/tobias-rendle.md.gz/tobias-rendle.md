# Tobias Rendle (Account manager, Central team, team-central)

Private notes from Tobias's DMs with assistant (DGBRAIN0004). Do not share with other members or in channels.

- 2026-11-08: Tobias's go-to escalation contact at Tamsin Cold Chain for the Thistle rollout is now Linnea Quillan (replaces any earlier contact). Told in DM ts 1794189600.000135.
