# Ilse Varga (North team lead, team-north) — private notes

Scope: told to the assistant in Ilse's DM (DGBRAIN0001). Use only in conversations with Ilse; do not surface in other members' conversations or in channels.

- 2026-10-14 (ts 1791986400.000123): Ilse's go-to escalation contact at Tamsin Cold Chain for the Ironbridge rollout is **Idris Ashdown**, effective from this date onward (replaces any earlier contact).
- 2026-10-18 (ts 1792353600.000125): Ilse's go-to escalation contact at Brackenwater Freight Co. for the Petrel rollout is **Soren Castellane**.
- 2026-10-18 (ts 1792353600.000125): Ilse's go-to escalation contact at Thornbury Cloth Co. for the Lantern rollout is **Oriel Quillan**.
- 2026-10-18 (ts 1792353600.000125): Ilse's go-to escalation contact at Quarrendon Freight Lines for the Fernhill rollout is **Oriel Tolland**. (Note: two different Oriels — Quillan at Thornbury/Lantern, Tolland at Quarrendon/Fernhill.)
