# Dana Okafor (Account manager, North team, team-north) — private notes

Scope: told to the assistant in Dana's DM (DGBRAIN0002). Use only in conversations with Dana; do not surface in other members' conversations or in channels.

- 2026-10-27 (ts 1793088000.000129): Dana's go-to escalation contact at Tamsin Cold Chain for the Wicklow rollout is **Wren Quillan**, effective from this date onward (replaces any earlier contact). (Not to be confused with Ilse's separate notes or other Quillans.)
