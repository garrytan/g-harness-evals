# Hollis Mbeki (Central team lead, team-central) — private notes

Scope: told to the assistant in Hollis's DM (DGBRAIN0003). Use only in conversations with Hollis; do not surface in other members' conversations or in channels.

- 2026-11-04 (ts 1793822400.000133): Hollis's go-to escalation contact at Tamsin Cold Chain for the Osprey rollout is **Wren Merriwether**, effective from this date onward (replaces any earlier contact). (Not to be confused with other members' separate notes or other Wrens.)
