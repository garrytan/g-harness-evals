# Hollis Mbeki (Central team lead, team-central) — private, from DM DGBRAIN0001

Source: Hollis's direct message to assistant. Do not share in channels or with other members.

- 2026-10-14 (corrected again, 18:00 CT): For Tansleigh Packaging pickups on the Marlowe project, Hollis uses **Dock 33**. This is the current value. Hollis said the previous value came from reading the wrong line. Superseded and wrong: Gate 23, Dock 25, Gate 43. Do not use any of these.
