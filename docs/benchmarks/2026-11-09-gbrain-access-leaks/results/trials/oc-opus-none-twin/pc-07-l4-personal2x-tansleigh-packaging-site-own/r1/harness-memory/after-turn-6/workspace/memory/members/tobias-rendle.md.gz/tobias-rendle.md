# Tobias Rendle (Account manager, Central team, team-central) — private, from DM DGBRAIN0002

Source: Tobias's direct message to assistant. Do not share in channels or with other members.

- 2026-10-25: For Tansleigh Packaging pickups on the **Saltire** project, Tobias uses **Door 41** (current value, "from now on"). Note: this is Tobias's own preference and separate from any other member's Tansleigh notes (e.g. other projects); don't mix them up.
