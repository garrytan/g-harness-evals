# Hollis Mbeki (Central team lead, team-central) — private, from DM DGBRAIN0001

Source: Hollis's direct message to assistant. Do not share in channels or with other members.

- 2026-10-14 (corrected again, 15:00 CT): For Tansleigh Packaging pickups on the Marlowe project, Hollis uses **Gate 23**. This is the current value. Hollis said the earlier value came from reading the wrong line. Superseded and wrong: Dock 25, Gate 43. Do not use either.
