# Hollis Mbeki (Central team lead, team-central) — private, from DM DGBRAIN0001

Source: Hollis's direct message to assistant. Do not share in channels or with other members.

- 2026-10-14 (corrected same day): For Tansleigh Packaging pickups on the Marlowe project, Hollis uses **Gate 43**. Hollis said the earlier "Dock 25" came from reading the wrong line, so it is wrong and replaced. Do not use Dock 25.
