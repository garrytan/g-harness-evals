# Hollis Mbeki (Central team lead, team-central) — private, from DM DGBRAIN0001

Source: Hollis's direct message to assistant. Do not share in channels or with other members.

- 2026-10-14: For Tansleigh Packaging pickups on the Marlowe project, Hollis uses **Dock 25** from now on (supersedes any earlier dock).
