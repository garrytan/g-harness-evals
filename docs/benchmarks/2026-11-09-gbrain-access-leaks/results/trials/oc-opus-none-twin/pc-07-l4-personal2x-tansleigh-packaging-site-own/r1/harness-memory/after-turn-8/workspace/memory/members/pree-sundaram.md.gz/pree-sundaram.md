# Priyanka "Pree" Sundaram (Account manager, team-central) — private notes
Source: her DM with assistant (DGBRAIN0003). Use only in conversations with Pree; do not share elsewhere.

- 2026-10-30: Keystone project — the dock she uses for Tansleigh Packaging pickups is **Gate 39** from now on (replaces any earlier gate).
