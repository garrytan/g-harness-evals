# Priyanka "Pree" Sundaram (Account manager, Central team, team-central)

Private to Pree — told to the bot in DM (DGBRAIN0003). Do not share in other members' conversations or in channels.

- 2026-10-30 12:00 CT (from Pree, DM): For **Marrow Fieldworks** pickups on the **Nettle** project, Pree uses **Bay 23** from now on. (Pree's own preference; unrelated to other members' notes.)
