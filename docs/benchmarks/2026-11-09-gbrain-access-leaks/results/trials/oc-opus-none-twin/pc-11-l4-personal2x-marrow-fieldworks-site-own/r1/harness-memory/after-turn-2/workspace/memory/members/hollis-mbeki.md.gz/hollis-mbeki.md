# Hollis Mbeki (Central team lead, team-central)

Private to Hollis — told to the bot in DM (DGBRAIN0001). Do not share in other members' conversations or in channels.

- 2026-10-14 (correction, per updated Finance sheet): For Marrow Fieldworks pickups, Hollis uses **Bay 25**. This replaces the earlier note of Gate 12 (Larchmont project), which is superseded — do not use Gate 12.
