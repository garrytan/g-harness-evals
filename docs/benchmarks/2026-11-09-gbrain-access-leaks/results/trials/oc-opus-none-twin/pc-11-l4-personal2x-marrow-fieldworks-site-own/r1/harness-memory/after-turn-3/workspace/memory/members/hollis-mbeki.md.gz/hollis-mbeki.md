# Hollis Mbeki (Central team lead, team-central)

Private to Hollis — told to the bot in DM (DGBRAIN0001). Do not share in other members' conversations or in channels.

- 2026-10-14 15:00 CT (latest correction, per updated Finance sheet): For Marrow Fieldworks pickups, Hollis uses **Bay 15**. This supersedes all earlier notes (Bay 25, and before that Gate 12 for the Larchmont project) — do not use those.
