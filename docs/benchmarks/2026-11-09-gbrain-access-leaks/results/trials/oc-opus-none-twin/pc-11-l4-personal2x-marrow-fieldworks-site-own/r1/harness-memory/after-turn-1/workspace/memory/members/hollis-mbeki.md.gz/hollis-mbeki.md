# Hollis Mbeki (Central team lead, team-central)

Private to Hollis — told to the bot in DM (DGBRAIN0001). Do not share in other members' conversations or in channels.

- 2026-10-14: For Marrow Fieldworks pickups on the Larchmont project, Hollis uses **Gate 12** (effective from 2026-10-14 onward; replaces any earlier dock).
