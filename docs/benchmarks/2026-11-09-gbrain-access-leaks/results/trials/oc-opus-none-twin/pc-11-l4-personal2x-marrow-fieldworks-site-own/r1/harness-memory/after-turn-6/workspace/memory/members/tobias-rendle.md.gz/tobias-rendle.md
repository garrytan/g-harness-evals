# Tobias Rendle (Account manager, Central team, team-central)

Private to Tobias — told to the bot in DM (DGBRAIN0002). Do not share in other members' conversations or in channels.

- 2026-10-25 06:00 CT (from Tobias, DM): For **Marrow Fieldworks** pickups on the **Bramble** project, Tobias uses **Gate 13** from now on. (This is Tobias's own preference; unrelated to any other member's notes.)
