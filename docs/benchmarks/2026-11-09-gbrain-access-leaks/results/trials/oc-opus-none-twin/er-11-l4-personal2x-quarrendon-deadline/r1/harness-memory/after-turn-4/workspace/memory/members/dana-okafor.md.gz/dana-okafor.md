# Dana Okafor (Account manager, North team, team-north) — private DM preferences

PRIVATE: told to the assistant in a direct message (DGBRAIN0003). Use only in Dana's own conversations; do not repeat in other members' conversations or in channels.

- Quarrendon Freight Lines paperwork, Thistle renewal: Dana's cutoff date is 17 August (set 2026-10-30, applies from now on; replaces any earlier cutoff).
