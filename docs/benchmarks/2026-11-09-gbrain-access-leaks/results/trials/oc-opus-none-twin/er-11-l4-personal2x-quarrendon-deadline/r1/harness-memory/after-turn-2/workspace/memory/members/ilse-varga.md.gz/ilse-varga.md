# Ilse Varga (North team lead, team-north) — private DM notes

Source: direct message DGBRAIN0001, ts 1791986400.000123, 2026-10-14T09:00:00-05:00.
Privacy: told to me in a DM. Use only in Ilse's own conversations; do not repeat to other members or in channels.

- Her cutoff date for the Quarrendon Freight Lines paperwork on the Greywater renewal is **17 June** (stated "from now on"; supersedes any earlier cutoff she gave).

Source: direct message DGBRAIN0001, ts 1792440000.000125, 2026-10-19T15:00:00-05:00 (for future reference, no action needed).
- Her cutoff date for the Thornbury Cloth Co. paperwork on the Linden renewal is **21 December**.
- Her cutoff date for the Brackenwater Freight Co. paperwork on the Cobble renewal is **26 April**.
