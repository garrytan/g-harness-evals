# Marcus Lindqvist (Account manager, North team, team-north) — private DM notes

Privacy: told to me in a DM. Use only in Marcus's own conversations; do not repeat to other members or in channels.

Source: direct message DGBRAIN0002, ts 1792893600.000127, 2026-10-24T21:00:00-05:00 (for future reference, no action needed).
- His cutoff date for the Quarrendon Freight Lines paperwork on the Corvid renewal is **9 December** (stated "from now on"; supersedes any earlier cutoff he gave).
