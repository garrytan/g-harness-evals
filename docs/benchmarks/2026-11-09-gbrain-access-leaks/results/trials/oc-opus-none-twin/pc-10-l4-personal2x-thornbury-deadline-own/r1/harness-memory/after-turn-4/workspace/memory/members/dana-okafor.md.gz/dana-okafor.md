# Dana Okafor (private DM notes — do not share outside Dana's DM)

- Thornbury Cloth Co. paperwork cutoff date (Wicklow renewal): **13 September** (Dana's correction, 2026-10-14 18:00 — customer changed it on the call). Supersedes all earlier dates she gave: 12 April (09:00), 9 August (12:00), 6 December (15:00), none valid any more.
  - Note: as of 2026-10-14, 13 September 2026 is already past; year not confirmed by Dana (asked whether she means 13 September 2027).
