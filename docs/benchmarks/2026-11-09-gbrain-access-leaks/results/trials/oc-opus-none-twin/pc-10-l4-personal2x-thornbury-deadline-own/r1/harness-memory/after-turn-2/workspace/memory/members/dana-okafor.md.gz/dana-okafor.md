# Dana Okafor (private DM notes — do not share outside Dana's DM)

- Thornbury Cloth Co. paperwork cutoff date: **9 August** (Dana's correction, 2026-10-14, per updated Finance sheet; supersedes whatever she said before).
