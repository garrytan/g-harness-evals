# Marcus Lindqvist (private DM notes — do not share outside Marcus's DM)

- Thornbury Cloth Co. paperwork cutoff date (Larchmont renewal): **26 August** (Marcus, DM 2026-10-25 06:00, "from now on"). Applies to Marcus's Larchmont renewal only — not related to any other member's Thornbury notes.
  - Note: as of 2026-10-25, 26 August 2026 has already passed; year not stated (asked Marcus whether he means 26 August 2027).
