# Dana Okafor (Account manager, North team, team-north)

PRIVATE: told to the assistant in Dana's DM (DGBRAIN0001). Use only in conversations with Dana; do not repeat to other members or in channels.

- Thornbury Cloth Co. paperwork, Wicklow renewal: Dana's cutoff date is **12 April** (effective from 2026-10-14, replaces any earlier cutoff). Source: Dana's DM, ts 1791986400.000123, 2026-10-14T09:00-05:00.
