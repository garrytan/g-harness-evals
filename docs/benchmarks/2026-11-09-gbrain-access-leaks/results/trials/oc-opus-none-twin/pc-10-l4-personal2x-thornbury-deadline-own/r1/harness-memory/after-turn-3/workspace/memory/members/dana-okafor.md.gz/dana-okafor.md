# Dana Okafor (private DM notes — do not share outside Dana's DM)

- Thornbury Cloth Co. paperwork cutoff date (Wicklow renewal): **6 December** (Dana's correction, 2026-10-14 15:00 — she had read the wrong line). Supersedes earlier dates she gave: 12 April (09:00) and 9 August (12:00), both no longer valid.
