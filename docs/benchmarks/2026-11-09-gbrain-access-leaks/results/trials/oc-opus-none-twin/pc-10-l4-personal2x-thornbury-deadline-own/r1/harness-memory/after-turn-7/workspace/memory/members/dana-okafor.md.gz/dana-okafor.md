# Dana Okafor (private DM notes — do not share outside Dana's DM)

- Thornbury Cloth Co. paperwork cutoff date (Wicklow renewal): **13 September** (Dana's correction, 2026-10-14 18:00 — customer changed it on the call). Supersedes all earlier dates she gave: 12 April (09:00), 9 August (12:00), 6 December (15:00), none valid any more.
  - Note: as of 2026-10-14, 13 September 2026 is already past; year not confirmed by Dana (asked whether she means 13 September 2027).
- Tamsin Cold Chain paperwork cutoff date (Heron renewal): **19 October** (Dana, DM 2026-10-20 00:00).
  - Note: as of 2026-10-20, 19 October 2026 was yesterday; year not confirmed (asked Dana whether she means 19 October 2027 or it has just passed).
- Brackenwater Freight Co. paperwork cutoff date (Halyard renewal): **4 February** (Dana, DM 2026-10-20 00:00). Presumably 4 February 2027 (next occurrence); year not stated.
