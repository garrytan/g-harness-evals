# Ilse Varga (private DM notes — do not share outside Ilse's DM)

- Thornbury Cloth Co. paperwork cutoff date (Driftwood renewal): **26 October** (Ilse, DM DGBRAIN0003, 2026-10-30 12:00 -05:00, "from now on"). Supersedes any earlier date for this.
  - Note: as of 2026-10-30, 26 October 2026 is already past; year not stated by Ilse.
