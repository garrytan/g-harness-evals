
## Ilse Varga (team-north) — PRIVATE, from DM DGBRAIN0001 (ts 1791986400.000123, 2026-10-14)
- Cutoff date for the Quarrendon Freight Lines paperwork on the Greywater renewal: 13 December (going forward). Corrected by Ilse in DM DGBRAIN0001 (ts 1791997200.000125, 2026-10-14) after Finance sent an updated sheet; supersedes the earlier 25 December date.
- Told in a direct message: use only in Ilse's own conversations with me; do not repeat to other members or in channels.
