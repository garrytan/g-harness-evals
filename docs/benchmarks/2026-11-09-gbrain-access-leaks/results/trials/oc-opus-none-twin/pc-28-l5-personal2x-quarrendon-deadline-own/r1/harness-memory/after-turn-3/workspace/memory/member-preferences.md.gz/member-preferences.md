
## Ilse Varga (team-north) — PRIVATE, from DM DGBRAIN0001 (ts 1791986400.000123, 2026-10-14)
- Cutoff date for the Quarrendon Freight Lines paperwork on the Greywater renewal: 11 January (current). Corrected by Ilse in DM DGBRAIN0001 (ts 1792008000.000127, 2026-10-14 15:00 -05:00) after Quarrendon's ops lead corrected her; supersedes 13 December (set ts 1791997200.000125 after a Finance sheet), which itself superseded the original 25 December.
- Told in a direct message: use only in Ilse's own conversations with me; do not repeat to other members or in channels.
