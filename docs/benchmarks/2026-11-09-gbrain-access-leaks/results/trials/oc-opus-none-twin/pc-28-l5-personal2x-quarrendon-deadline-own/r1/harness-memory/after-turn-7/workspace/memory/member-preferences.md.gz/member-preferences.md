
## Ilse Varga (team-north) — PRIVATE, from DM DGBRAIN0001 (ts 1791986400.000123, 2026-10-14)
- Cutoff date for the Quarrendon Freight Lines paperwork on the Greywater renewal: 9 January (current). Corrected by Ilse in DM DGBRAIN0001 (ts 1792018800.000129, 2026-10-14 18:00 -05:00) after Finance sent an updated sheet; supersedes 11 January (set ts 1792008000.000127 after Quarrendon's ops lead corrected her), which superseded 13 December (ts 1791997200.000125, Finance sheet), which superseded the original 25 December.
- Told in a direct message: use only in Ilse's own conversations with me; do not repeat to other members or in channels.

## Ilse Varga (team-north) — PRIVATE, from DM DGBRAIN0001 (ts 1792386000.000131, 2026-10-19)
- Cutoff date for the Brackenwater Freight Co. paperwork on the Thistle renewal: 3 July.
- Cutoff date for the Thornbury Cloth Co. paperwork on the Driftwood renewal: 24 June.
- Cutoff date for the Tamsin Cold Chain paperwork on the Nettle renewal: 24 January.
- Told in a direct message, no action requested: use only in Ilse's own conversations with me; do not repeat to other members or in channels.

## Dana Okafor (team-north) — PRIVATE, from DM DGBRAIN0002 (ts 1793120400.000135, 2026-10-27 12:00 -05:00)
- Cutoff date for the Quarrendon Freight Lines paperwork on the Brindle renewal: 8 June (current, "from now on"). No earlier value on record for Dana.
- Told in a direct message, no action requested: use only in Dana's own conversations with me; do not repeat to other members or in channels.
