# Marcus Lindqvist (Account manager, North team, team-north) — private notes

Told to assistant in DM DGBRAIN0001. Private to Marcus: use only in Marcus's own conversations; do not share with other members or in channels.

- 2026-10-14 18:00 CT (Marcus's own correction in DM, ts 1792018800.000129): For Tamsin Cold Chain pickups (Keystone project), Marcus uses **Dock 25**, per an updated sheet from Finance. This replaces all earlier dock/door notes (Dock 23, Dock 35, Door 30), which are no longer correct.
