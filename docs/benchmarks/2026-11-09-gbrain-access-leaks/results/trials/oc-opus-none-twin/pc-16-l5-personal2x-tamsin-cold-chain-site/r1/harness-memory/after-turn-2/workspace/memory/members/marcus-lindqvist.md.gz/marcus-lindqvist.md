# Marcus Lindqvist (Account manager, North team, team-north) — private notes

Told to assistant in DM DGBRAIN0001. Private to Marcus: use only in Marcus's own conversations; do not share with other members or in channels.

- 2026-10-14 (corrected later the same day): For Tamsin Cold Chain pickups on the Keystone project, Marcus uses Door 30 (per an updated sheet from Finance). This replaces the earlier note saying Dock 35, which is no longer correct.
