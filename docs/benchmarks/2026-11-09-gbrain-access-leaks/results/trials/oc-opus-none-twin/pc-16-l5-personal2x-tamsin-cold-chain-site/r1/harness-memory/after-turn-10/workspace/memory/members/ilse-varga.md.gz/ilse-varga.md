# Ilse Varga (North team lead, team-north) — private notes

Told to assistant in DM DGBRAIN0002. Private to Ilse: use only in Ilse's own conversations; do not share with other members or in channels.

- 2026-10-27 12:00 CT (Ilse in DM, ts 1793120400.000135): For Tamsin Cold Chain pickups on the **Bramble project**, Ilse uses **Door 43** from now on.
- 2026-11-09 06:00 ET (Ilse in DM, ts 1794222000.000141): For Tamsin Cold Chain pickups on the **Moorland project**, Ilse uses **Door 46** from now on. (Separate from the Bramble project note above, which still stands.)
