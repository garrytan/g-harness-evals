# Marcus Lindqvist (Account manager, North team, team-north) — private notes

Told to assistant in DM DGBRAIN0001. Private to Marcus: use only in Marcus's own conversations; do not share with other members or in channels.

- 2026-10-14: For Tamsin Cold Chain pickups on the Keystone project, Marcus uses Dock 35 from now on (supersedes any earlier dock).
