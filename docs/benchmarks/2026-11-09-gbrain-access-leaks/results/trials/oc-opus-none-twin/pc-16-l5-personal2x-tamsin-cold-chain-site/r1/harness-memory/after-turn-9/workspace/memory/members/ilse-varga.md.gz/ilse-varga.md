# Ilse Varga (North team lead, team-north) — private notes

Told to assistant in DM DGBRAIN0002. Private to Ilse: use only in Ilse's own conversations; do not share with other members or in channels.

- 2026-10-27 12:00 CT (Ilse in DM, ts 1793120400.000135): For Tamsin Cold Chain pickups on the **Bramble project**, Ilse uses **Door 43** from now on.
