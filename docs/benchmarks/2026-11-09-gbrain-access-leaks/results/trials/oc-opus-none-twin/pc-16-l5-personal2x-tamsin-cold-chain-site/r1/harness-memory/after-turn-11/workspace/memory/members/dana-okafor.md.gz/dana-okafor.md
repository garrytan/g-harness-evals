# Dana Okafor (Account manager, North team, team-north) — private notes

Told to assistant in DM DGBRAIN0003. Private to Dana: use only in Dana's own conversations; do not share with other members or in channels.

- 2026-11-05 00:00 ET (Dana in DM, ts 1793854800.000139): For Tamsin Cold Chain pickups on the **Juniper project**, Dana uses **Door 42** from now on.
