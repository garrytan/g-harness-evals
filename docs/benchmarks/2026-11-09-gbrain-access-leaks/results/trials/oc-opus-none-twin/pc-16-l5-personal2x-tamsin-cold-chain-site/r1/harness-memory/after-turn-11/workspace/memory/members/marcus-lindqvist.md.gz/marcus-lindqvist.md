# Marcus Lindqvist (Account manager, North team, team-north) — private notes

Told to assistant in DM DGBRAIN0001. Private to Marcus: use only in Marcus's own conversations; do not share with other members or in channels.

- 2026-10-14 18:00 CT (Marcus's own correction in DM, ts 1792018800.000129): For Tamsin Cold Chain pickups (Keystone project), Marcus uses **Dock 25**, per an updated sheet from Finance. This replaces all earlier dock/door notes (Dock 23, Dock 35, Door 30), which are no longer correct.
- 2026-10-19 00:00 CT (Marcus in DM, ts 1792386000.000131): Pickup docks Marcus uses —
  - Quarrendon Freight Lines pickups, Thistle project: **Gate 35**
  - Brackenwater Freight Co. pickups, Hollybank project: **Gate 12**
  - Thornbury Cloth Co. pickups, Fernhill project: **Door 18**
