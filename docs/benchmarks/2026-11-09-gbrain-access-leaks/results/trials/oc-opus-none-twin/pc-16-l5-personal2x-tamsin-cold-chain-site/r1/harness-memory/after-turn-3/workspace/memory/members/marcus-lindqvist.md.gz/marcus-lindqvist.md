# Marcus Lindqvist (Account manager, North team, team-north) — private notes

Told to assistant in DM DGBRAIN0001. Private to Marcus: use only in Marcus's own conversations; do not share with other members or in channels.

- 2026-10-14 15:00 CT (Marcus's own correction in DM, ts 1792008000.000127): For Tamsin Cold Chain pickups on the Keystone project, Marcus uses **Dock 23**. He said he had read the wrong line before. This replaces all earlier dock/door notes (Dock 35, Door 30), which are no longer correct.
