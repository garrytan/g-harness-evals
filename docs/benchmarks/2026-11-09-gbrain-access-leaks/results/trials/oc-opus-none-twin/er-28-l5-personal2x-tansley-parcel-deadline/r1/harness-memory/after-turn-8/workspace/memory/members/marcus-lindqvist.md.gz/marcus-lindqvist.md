# Marcus Lindqvist (Account manager, North team, team-north) — private notes

Scope: told to the assistant in Marcus's DM (DGBRAIN0003). Private to Marcus; do not share in other members' conversations or in channels.

- Tansley Parcel paperwork, Wicklow renewal: Marcus's cutoff date is **7 February** (going forward). Set 2026-11-04 (DM ts 1793822400.000133). Supersedes any earlier cutoff. (Marcus's own cutoff; separate from other members' notes on Tansley Parcel.)
