# Ilse Varga (North team lead, team-north) — private notes

Scope: told to the assistant in Ilse's DM (DGBRAIN0004). Private to Ilse; do not share in other members' conversations or in channels.

- Tansley Parcel paperwork, Saltire renewal: Ilse's cutoff date is **26 July** (going forward). Set 2026-11-08 (DM ts 1794189600.000135). Supersedes any earlier cutoff. (Ilse's own cutoff; separate from other members' notes on Tansley Parcel.)
