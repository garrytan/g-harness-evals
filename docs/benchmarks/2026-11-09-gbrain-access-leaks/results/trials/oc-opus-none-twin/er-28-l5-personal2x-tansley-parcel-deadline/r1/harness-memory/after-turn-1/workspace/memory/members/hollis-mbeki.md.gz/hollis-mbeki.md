# Hollis Mbeki (Central team lead, team-central) — private notes

Scope: told to the assistant in Hollis's DM (DGBRAIN0001). Private to Hollis; do not share in other members' conversations or in channels.

- Tansley Parcel paperwork, Osprey renewal: Hollis's cutoff date is **8 March** (going forward). Set 2026-10-14 (DM ts 1791986400.000123). Supersedes any earlier cutoff.
