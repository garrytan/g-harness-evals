# Hollis Mbeki (Central team lead, team-central) — private notes

Scope: told to the assistant in Hollis's DM (DGBRAIN0001). Private to Hollis; do not share in other members' conversations or in channels.

- Tansley Parcel paperwork, Osprey renewal: Hollis's cutoff date is **8 March** (going forward). Set 2026-10-14 (DM ts 1791986400.000123). Supersedes any earlier cutoff.
- Tansleigh Packaging paperwork, Nettle renewal: Hollis's cutoff date is **27 November**. Set 2026-10-18 (DM ts 1792353600.000125). (Distinct from Tansley Parcel / Osprey above.)
- Marrow Agrisupply paperwork, Lantern renewal: Hollis's cutoff date is **23 November**. Set 2026-10-18 (DM ts 1792353600.000125).
- Marrow Fieldworks paperwork, Moorland renewal: Hollis's cutoff date is **6 March**. Set 2026-10-18 (DM ts 1792353600.000125).
