# Priyanka "Pree" Sundaram (Account manager, Central team, team-central) — private notes

Scope: told to the assistant in Pree's DM (DGBRAIN0002). Private to Pree; do not share in other members' conversations or in channels.

- Tansley Parcel paperwork, Heron renewal: Pree's cutoff date is **17 November** (going forward). Set 2026-10-27 (DM ts 1793088000.000129). Supersedes any earlier cutoff. (Pree's own cutoff; separate from other members' notes.)
