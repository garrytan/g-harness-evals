# Dana Okafor (Account manager, North team, team-north) — private DM notes

Told privately in DM DGBRAIN0002; use only in Dana's own conversations.

- Cutoff date for the Thornbury Cloth Co. paperwork on the Juniper renewal: **27 September** ("from now on"; given by Dana in DM DGBRAIN0002, ts 1793120400.000135, 2026-10-27T12:00-05:00).
