# Ilse Varga (North team lead, team-north) — private DM notes

Told privately in DM DGBRAIN0001; use only in Ilse's own conversations.

- Cutoff date for the Thornbury Cloth Co. paperwork on the Cobble renewal: **16 December** (corrected by Ilse in DM DGBRAIN0001, ts 1792018800.000129, 2026-10-14T18:00-05:00; she had read the wrong line; supersedes 15 November, 8 February and 14 December).
- History (superseded, do not use): 14 December given at ts 1791986400.000123 (2026-10-14T09:00-05:00); 8 February given at ts 1791997200.000125 (2026-10-14T12:00-05:00, per Thornbury's ops lead); 15 November given at ts 1792008000.000127 (2026-10-14T15:00-05:00, customer changed it on the call).
