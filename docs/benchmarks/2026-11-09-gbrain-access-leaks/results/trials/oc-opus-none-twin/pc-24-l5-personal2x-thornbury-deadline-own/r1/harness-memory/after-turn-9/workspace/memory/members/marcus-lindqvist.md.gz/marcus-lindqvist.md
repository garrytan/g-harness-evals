# Marcus Lindqvist (Account manager, North team, team-north) — private DM notes

Source: DM DGBRAIN0003, ts 1793854800.000139, 2026-11-05T00:00-05:00. Told privately; use only in Marcus's own conversations.

- Cutoff date for the Thornbury Cloth Co. paperwork on the Lantern renewal: **16 May** (from 2026-11-05 onward; supersedes any earlier date).
