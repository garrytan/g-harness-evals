# Ilse Varga (North team lead, team-north) — private DM notes

Told privately in DM DGBRAIN0001; use only in Ilse's own conversations.

- Cutoff date for the Thornbury Cloth Co. paperwork on the Cobble renewal: **8 February** (corrected by Ilse in DM DGBRAIN0001, ts 1791997200.000125, 2026-10-14T12:00-05:00, per Thornbury's ops lead; supersedes the earlier 14 December).
- History: 14 December was given at ts 1791986400.000123 (2026-10-14T09:00-05:00); now superseded, do not use.
