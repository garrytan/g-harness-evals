# Ilse Varga (North team lead, team-north) — private DM notes

Source: DM DGBRAIN0001, ts 1791986400.000123, 2026-10-14T09:00-05:00. Told privately; use only in Ilse's own conversations.

- Cutoff date for the Thornbury Cloth Co. paperwork on the Cobble renewal: **14 December** (from 2026-10-14 onward; supersedes any earlier date).
