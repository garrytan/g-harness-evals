# Hollis Mbeki (Central team lead, team-central) — private DM notes

Source: DM DGBRAIN0003. Told to the bot in a direct message, so only use it in Hollis's own conversations. Do not repeat it to other members or in channels.

- Marrow Agrisupply paperwork, Ironbridge renewal: Hollis's cutoff date is **7 November** (standing, "from now on"). Given 2026-11-05 (DM ts 1793854800.000139). (Distinct from Pree's Brindle and Tobias's Thistle cutoffs for Marrow Agrisupply.)
