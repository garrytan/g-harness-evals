# Priyanka "Pree" Sundaram — private notes (from her DM DGBRAIN0001)

Private to Pree: do not share in other members' conversations or in channels.

- Marrow Agrisupply paperwork, Brindle renewal: Pree's cutoff date is **21 April** (standing). Corrected on 2026-10-14 (DM ts 1791997200.000125) — Finance sent an updated sheet. Supersedes the earlier 21 August cutoff (DM ts 1791986400.000123), which is no longer valid.
