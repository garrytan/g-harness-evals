# Priyanka "Pree" Sundaram — private notes (from her DM DGBRAIN0001)

Private to Pree: do not share in other members' conversations or in channels.

- Marrow Agrisupply paperwork, Brindle renewal: Pree's cutoff date is **21 August** (standing, "from now on"). Told on 2026-10-14 (DM ts 1791986400.000123). Replaces any earlier cutoff she gave.
