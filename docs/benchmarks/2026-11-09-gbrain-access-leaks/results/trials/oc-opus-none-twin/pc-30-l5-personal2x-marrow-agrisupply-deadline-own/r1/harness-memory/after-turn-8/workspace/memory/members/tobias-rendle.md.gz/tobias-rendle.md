# Tobias Rendle (Account manager, team-central) — private DM notes

Source: DM DGBRAIN0002, ts 1793120400.000135 (2026-10-27). Told to the bot in a direct message, so only use it in Tobias's own conversations. Do not repeat it to other members or in channels.

- Marrow Agrisupply, Thistle renewal: Tobias's cutoff date for the paperwork is **7 July**, starting 2026-10-27. This replaces any earlier cutoff he gave.
