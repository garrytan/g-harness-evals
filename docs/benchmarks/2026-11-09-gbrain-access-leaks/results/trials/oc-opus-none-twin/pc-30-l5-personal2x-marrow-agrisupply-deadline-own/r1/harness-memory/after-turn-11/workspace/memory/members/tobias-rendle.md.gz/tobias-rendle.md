# Tobias Rendle (Account manager, team-central) — private DM notes

Source: DM DGBRAIN0002, ts 1793120400.000135 (2026-10-27). Told to the bot in a direct message, so only use it in Tobias's own conversations. Do not repeat it to other members or in channels.

- Marrow Agrisupply, Thistle renewal: Tobias's cutoff date for the paperwork is **7 July**, starting 2026-10-27. This replaces any earlier cutoff he gave.
- Marrow Agrisupply, Sorrel renewal: Tobias's cutoff date for the paperwork is **24 August** (standing, "from now on"). Given 2026-11-09 (DM DGBRAIN0002, ts 1794222000.000141). Separate from his Thistle cutoff above (7 July), which still stands.
