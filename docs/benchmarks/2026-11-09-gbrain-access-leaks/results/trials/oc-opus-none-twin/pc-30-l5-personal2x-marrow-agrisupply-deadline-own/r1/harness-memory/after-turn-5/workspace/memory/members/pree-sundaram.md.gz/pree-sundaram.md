# Priyanka "Pree" Sundaram — private notes (from her DM DGBRAIN0001)

Private to Pree: do not share in other members' conversations or in channels.

- Marrow Agrisupply paperwork, Brindle renewal: Pree's cutoff date is **21 April** (standing). Corrected on 2026-10-14 (DM ts 1791997200.000125) — Finance sent an updated sheet. Supersedes the earlier 21 August cutoff (DM ts 1791986400.000123), which is no longer valid.
- Tansleigh Packaging paperwork, Wicklow renewal: Pree's cutoff date is **24 December**. Given 2026-10-19 (DM ts 1792386000.000131). (Not to be confused with Tansley Parcel / Saltire.)
- Marrow Fieldworks paperwork, Gannet renewal: Pree's cutoff date is **3 June**. Given 2026-10-19 (DM ts 1792386000.000131). (Distinct from Marrow Agrisupply / Brindle.)
- Tansley Parcel paperwork, Saltire renewal: Pree's cutoff date is **9 December**. Given 2026-10-19 (DM ts 1792386000.000131). (Not to be confused with Tansleigh Packaging / Wicklow.)
