# Priyanka "Pree" Sundaram (Account manager, Central team, team-central)

PRIVATE: told to assistant in DM (DGBRAIN0001). Use only in Pree's own conversations; do not share with other members or in channels.

- Standing call with the Marrow Agrisupply team for the Thistle rollout: Fridays at 8:45 (America/Chicago, company time zone), going forward. Corrected 2026-10-14 (msg ts 1792008000.000127); the customer changed it on the call. Supersedes the earlier "Wednesdays at 11:30" note (msg ts 1791997200.000125) and the original "Tuesdays at 9:15" note (msg ts 1791986400.000123). No action requested, just remember.
