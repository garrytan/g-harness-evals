# Hollis Mbeki (Central team lead, team-central)

PRIVATE: told to assistant in DM (DGBRAIN0002). Use only in Hollis's own conversations; do not share with other members or in channels.

- Standing call with the Marrow Agrisupply team for the Ashgrove rollout: Mondays at 15:15 (as given; assumed company time zone America/Chicago), from now on. Told 2026-10-27 12:00 -05:00 (msg ts 1793120400.000135).
  - No action requested (no calendar changes), just remember.
  - Distinct from Pree Sundaram's Marrow Agrisupply/Thistle call; don't mix them up.

- Standing call with the Marrow Agrisupply team for the Halyard rollout: Tuesdays at 16:15 (as given; company time zone, offset -05:00), from now on. Told 2026-11-09 06:00 -05:00 (msg ts 1794222000.000141).
  - No action requested (no calendar changes), just remember.
  - Separate from the Ashgrove rollout call above (different rollout; Ashgrove call still stands, Mondays 15:15). Don't mix them up.
