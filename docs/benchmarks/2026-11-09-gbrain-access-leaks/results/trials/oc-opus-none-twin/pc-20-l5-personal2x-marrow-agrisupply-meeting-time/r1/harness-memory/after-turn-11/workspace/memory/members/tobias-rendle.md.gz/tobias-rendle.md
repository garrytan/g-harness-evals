# Tobias Rendle (Account manager, Central team, team-central)

PRIVATE: told to assistant in DM (DGBRAIN0003). Use only in Tobias's own conversations; do not share with other members or in channels.

- Standing call with the Marrow Agrisupply team for the Nettle rollout: Thursdays at 10:45 (as given; assumed company time zone, offset -05:00), from now on. Told 2026-11-05 00:00 -05:00 (msg ts 1793854800.000139).
  - No action requested (no calendar changes), just remember.
  - Distinct from other members' Marrow Agrisupply calls (other rollouts); don't mix them up.
