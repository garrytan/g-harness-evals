# Priyanka "Pree" Sundaram (Account manager, Central team, team-central)

PRIVATE: told to assistant in DM (DGBRAIN0001). Use only in Pree's own conversations; do not share with other members or in channels.

- Standing call with the Marrow Agrisupply team for the Thistle rollout: Wednesdays at 15:30 (America/Chicago, company time zone), going forward. Corrected 2026-10-14 18:00 (msg ts 1792018800.000129); their ops lead corrected her. This is the current time.
  - Superseded (do not use): Fridays at 8:45 (ts 1792008000.000127), Wednesdays at 11:30 (ts 1791997200.000125), Tuesdays at 9:15 (ts 1791986400.000123).
  - No action requested (no calendar changes), just remember.

- Added 2026-10-19 00:00 (msg ts 1792386000.000131), no action requested, just remember (times as given; assumed company time zone America/Chicago):
  - Standing call with the Marrow Fieldworks team for the Quillon rollout: Thursdays at 8:30. (Marrow Fieldworks is distinct from Marrow Agrisupply/Thistle above.)
  - Standing call with the Tansleigh Packaging team for the Merlin rollout: Mondays at 9:45.
  - Standing call with the Tansley Parcel team for the Fernhill rollout: Mondays at 13:30. (Tansley Parcel is distinct from Tansleigh Packaging; similar names, don't mix up.)
