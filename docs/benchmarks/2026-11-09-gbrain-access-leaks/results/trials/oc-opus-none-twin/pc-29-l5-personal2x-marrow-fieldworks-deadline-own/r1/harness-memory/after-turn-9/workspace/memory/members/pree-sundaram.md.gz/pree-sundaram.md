# Priyanka "Pree" Sundaram (private — from DM DGBRAIN0002; share only with Pree)

- Marrow Fieldworks paperwork (Petrel renewal) cutoff date: **25 December**.
  - Given 2026-10-27 12:00 -05:00 (ts 1793120400.000135), "from now on". No earlier value on record.
