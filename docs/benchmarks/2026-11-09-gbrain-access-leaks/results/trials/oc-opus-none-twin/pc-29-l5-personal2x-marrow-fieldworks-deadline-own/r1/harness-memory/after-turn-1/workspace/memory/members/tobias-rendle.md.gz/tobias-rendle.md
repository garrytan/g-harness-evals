# Tobias Rendle (Account manager, Central team, team-central) — private DM notes

Source: Tobias's direct message to assistant (DGBRAIN0001, ts 1791986400.000123, 2026-10-14). Shared privately in a DM: use only in conversations with Tobias. Do not repeat it in channels or to other members.

- Cutoff date for the Marrow Fieldworks paperwork on the Brindle renewal: **17 May** (applies from 2026-10-14 onward; replaces any earlier cutoff Tobias gave).
