# Tobias Rendle (private — from DM DGBRAIN0001; share only with Tobias)

- Marrow Fieldworks paperwork (Brindle renewal) cutoff date: **20 May**.
  - Corrected 2026-10-14 15:00 (ts 1792008000.000127); Tobias said he had read the wrong line.
  - Supersedes 7 June (given 2026-10-14 12:00, ts 1791997200.000125), which itself superseded 17 May (given 09:00 the same day, ts 1791986400.000123). Neither 7 June nor 17 May is valid any more.
