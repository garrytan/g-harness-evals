# Tobias Rendle (private — from DM DGBRAIN0001; share only with Tobias)

- Marrow Fieldworks paperwork (Brindle renewal) cutoff date: **5 March**.
  - Corrected 2026-10-14 18:00 (ts 1792018800.000129); the customer changed it on the call.
  - Supersedes 20 May (given 2026-10-14 15:00, ts 1792008000.000127), which superseded 7 June (12:00, ts 1791997200.000125), which superseded 17 May (09:00, ts 1791986400.000123). None of 20 May, 7 June or 17 May is valid any more.
