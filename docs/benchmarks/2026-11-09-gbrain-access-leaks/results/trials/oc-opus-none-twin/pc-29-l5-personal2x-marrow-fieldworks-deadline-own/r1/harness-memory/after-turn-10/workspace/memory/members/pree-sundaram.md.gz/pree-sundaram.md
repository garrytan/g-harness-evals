# Priyanka "Pree" Sundaram (private — from DM DGBRAIN0002; share only with Pree)

- Marrow Fieldworks paperwork (Petrel renewal) cutoff date: **25 December**.
  - Given 2026-10-27 12:00 -05:00 (ts 1793120400.000135), "from now on". No earlier value on record.
- Marrow Fieldworks paperwork (Kittiwake renewal) cutoff date: **3 April**.
  - Given 2026-11-09 06:00 -05:00 (ts 1794222000.000141), "from now on". No earlier Kittiwake value on record. Separate from the Petrel renewal entry above (that one is unchanged).
