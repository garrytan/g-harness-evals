# Hollis Mbeki (private — from DM DGBRAIN0003; share only with Hollis)

- Marrow Fieldworks paperwork (Bittern renewal) cutoff date: **22 January**.
  - Given 2026-11-05 00:00 -05:00 (ts 1793854800.000139), "from now on". No earlier value on record.
