# Tobias Rendle (private — from DM DGBRAIN0001; share only with Tobias)

- Marrow Fieldworks paperwork (Brindle renewal) cutoff date: **7 June**.
  - Corrected 2026-10-14 12:00 (ts 1791997200.000125); Marrow Fieldworks' ops lead corrected him.
  - Supersedes the earlier 17 May date he gave at 09:00 the same day (ts 1791986400.000123). 17 May is no longer valid.
