# Ilse Varga (North team lead, team-north) — private notes (from DM DGBRAIN0004)

Scope: told to the assistant in a direct message. Use only in conversations with Ilse herself; do not share into other members' conversations or channels.

- 2026-11-08 (DM ts 1794189600.000135): Ilse's go-to person at Tansleigh Packaging for escalations on the **Marlowe** rollout is **Idris Ashdown**, effective from this date ("from now on"). Supersedes any earlier contact. No action was requested.
  - Note: this is Ilse's Marlowe contact. Don't confuse with other members' Tansleigh Packaging contacts for other rollouts (e.g. Dana's Corvid contact), with similarly named people, or with Tansley Parcel (a distinct account).
