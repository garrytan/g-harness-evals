# Dana Okafor (Account manager, North team, team-north) — private notes (from DM DGBRAIN0003)

Scope: told to the assistant in a direct message. Use only in conversations with Dana herself; do not share into other members' conversations or channels.

- 2026-11-04 (DM ts 1793822400.000133): Dana's go-to person at Tansleigh Packaging for escalations on the **Corvid** rollout is **Maren Merriwether**, effective from this date ("from now on"). Supersedes any earlier contact. No action was requested.
  - Note: this is Dana's Corvid contact. Don't confuse with other members' Tansleigh Packaging contacts for other rollouts, with similarly named people (e.g. a Linnea Merriwether, a Maren Varno), or with Tansley Parcel (a distinct account).
