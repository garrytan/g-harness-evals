# Hollis Mbeki (Central team lead, team-central) — private notes (from DM DGBRAIN0002)

Scope: told to the assistant in a direct message. Use only in conversations with Hollis himself; do not share into other members' conversations or channels.

- 2026-10-27 (DM ts 1793088000.000129): Hollis's go-to person at Tansleigh Packaging for escalations on the **Thistle** rollout is **Linnea Merriwether**, effective from this date ("from now on"). Supersedes any earlier contact. No action was requested.
  - Note: this is Hollis's Thistle contact. Don't confuse with other members' Tansleigh Packaging contacts for other rollouts (e.g. a different Linnea on Saltire), or with Tansley Parcel (a distinct account).
