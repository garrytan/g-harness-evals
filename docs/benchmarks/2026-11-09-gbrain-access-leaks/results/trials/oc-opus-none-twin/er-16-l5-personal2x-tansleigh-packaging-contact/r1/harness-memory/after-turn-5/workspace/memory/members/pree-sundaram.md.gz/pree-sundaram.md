# Priyanka "Pree" Sundaram — private notes (from DM DGBRAIN0001)

Scope: told to the assistant in a direct message. Use only in conversations with Pree herself; do not share into other members' conversations or channels.

- 2026-10-14 (DM ts 1791986400.000123): Pree's go-to person at Tansleigh Packaging for escalations on the Saltire rollout is **Linnea Tolland**, effective from this date ("from now on"). Supersedes any earlier contact. No action was requested.
- 2026-10-18 (DM ts 1792353600.000125): Pree's go-to escalation contacts (no action requested):
  - Marrow Fieldworks, Petrel rollout: **Maren Varno**
  - Marrow Agrisupply, Larchmont rollout: **Wren Varno**
  - Tansley Parcel, Bramble rollout: **Tamsyn Quillan**
  - Note: Marrow Fieldworks vs Marrow Agrisupply, and Tansley Parcel (Bramble) vs Tansleigh Packaging (Saltire, Linnea Tolland), are distinct accounts — don't mix them up.
