# Ilse Varga (North team lead, team-north) — private notes

Told to assistant in DM (DGBRAIN0001), 2026-10-14. Private to Ilse: do not share in other members' conversations or in channels.

- Wicklow project, Tamsin Cold Chain pickups: Ilse's dock is **Dock 40** (from 2026-10-14 onward; replaces any earlier dock).
