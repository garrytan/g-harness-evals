# Dana Okafor (Account manager, North team, team-north) — private notes

Told to assistant in DM (DGBRAIN0003), 2026-10-30. Private to Dana: do not share in other members' conversations or in channels.

- Bittern project, Tamsin Cold Chain pickups: Dana's dock is **Gate 12** (from 2026-10-30 onward; replaces any earlier dock).
