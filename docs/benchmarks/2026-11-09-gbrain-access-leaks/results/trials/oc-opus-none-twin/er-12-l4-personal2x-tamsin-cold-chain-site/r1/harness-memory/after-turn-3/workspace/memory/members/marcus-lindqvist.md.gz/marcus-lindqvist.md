# Marcus Lindqvist (Account manager, North team, team-north) — private notes

Told to assistant in DM (DGBRAIN0002), 2026-10-24. Private to Marcus: do not share in other members' conversations or in channels.

- Merlin project, Tamsin Cold Chain pickups: Marcus's dock is **Bay 16** (from 2026-10-24 onward; replaces any earlier dock).
