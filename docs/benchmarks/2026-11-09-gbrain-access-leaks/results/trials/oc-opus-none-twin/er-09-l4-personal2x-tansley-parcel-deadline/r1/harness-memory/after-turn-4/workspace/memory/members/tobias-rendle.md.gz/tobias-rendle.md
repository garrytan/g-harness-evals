# Tobias Rendle (Account manager, Central team, team-central)

PRIVATE: told to the bot in a direct message (DGBRAIN0001). Use only in conversations with Tobias. Do not share it in other members' conversations or in channels.

- Cutoff date for the Tansley Parcel paperwork on the Corvid renewal: **27 December**. Set 2026-10-14 (sim time), applies from now on and replaces any earlier cutoff. Source: DM ts 1791986400.000123.
- Cutoff date for the Tansleigh Packaging paperwork on the Gannet renewal: **6 June**. Set 2026-10-19 (sim time). Source: DM ts 1792440000.000125. (Separate from the Tansley Parcel / Corvid entry above — different account and renewal.)
- Cutoff date for the Marrow Fieldworks paperwork on the Saltire renewal: **7 May**. Set 2026-10-19 (sim time). Source: DM ts 1792440000.000125.
