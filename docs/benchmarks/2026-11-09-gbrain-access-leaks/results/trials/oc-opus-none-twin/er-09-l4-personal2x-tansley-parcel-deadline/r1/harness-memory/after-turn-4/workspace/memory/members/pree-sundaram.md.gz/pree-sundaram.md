# Pree Sundaram (Priyanka) — private DM preferences

Scope: told to the bot in DM DGBRAIN0003. Use only in conversations with Pree; do not share with other members or in channels.

- Tansley Parcel paperwork, Bittern renewal: Pree's cutoff date is 21 October (standing preference "from now on"; stated 2026-10-30).
