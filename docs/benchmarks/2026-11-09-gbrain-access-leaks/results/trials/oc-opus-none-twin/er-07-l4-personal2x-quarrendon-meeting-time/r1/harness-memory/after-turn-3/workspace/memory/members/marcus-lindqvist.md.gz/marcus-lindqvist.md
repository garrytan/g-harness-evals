# Marcus Lindqvist (Account manager, North team, team-north)

PRIVATE: told to the assistant in Marcus's DM (DGBRAIN0001). Use only in conversations with Marcus; do not repeat in other members' conversations or in channels.

- Standing call with the Quarrendon Freight Lines team for the Quillon rollout: Thursdays at 13:45, effective from 2026-10-14 onward (told 2026-10-14, DM ts 1791986400.000123). Replaces any earlier slot. Time zone not stated; Marcus wrote at 09:00 -05:00 (company time zone).
- Standing call with the Thornbury Cloth Co. team for the Wicklow rollout: Mondays at 11:30 (told 2026-10-19, DM ts 1792440000.000125). Time zone not stated; Marcus wrote at 15:00 -05:00 (company time zone).
- Standing call with the Brackenwater Freight Co. team for the Keystone rollout: Mondays at 12:45 (told 2026-10-19, DM ts 1792440000.000125). Time zone not stated; Marcus wrote at 15:00 -05:00 (company time zone).
