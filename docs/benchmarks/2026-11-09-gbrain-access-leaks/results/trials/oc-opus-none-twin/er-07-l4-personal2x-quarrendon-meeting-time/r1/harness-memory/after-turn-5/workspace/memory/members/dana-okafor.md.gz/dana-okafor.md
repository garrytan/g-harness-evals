# Dana Okafor (Account manager, North team, team-north)

PRIVATE: told to the assistant in Dana's DM (DGBRAIN0002). Use only in conversations with Dana; do not repeat in other members' conversations or in channels.

- Standing call with the Quarrendon Freight Lines team for the Elmstead rollout: Mondays at 8:45, effective from 2026-10-24 onward ("from now on"; told 2026-10-24, DM ts 1792893600.000127). Replaces any earlier slot. AM/PM and time zone not stated; Dana wrote at 21:00 -05:00 (company time zone).
