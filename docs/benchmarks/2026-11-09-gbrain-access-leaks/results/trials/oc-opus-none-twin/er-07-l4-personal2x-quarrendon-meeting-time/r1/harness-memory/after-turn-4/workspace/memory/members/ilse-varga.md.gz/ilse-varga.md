# Ilse Varga (North team lead, team-north)

PRIVATE: told to the assistant in Ilse's DM (DGBRAIN0003). Use only in conversations with Ilse; do not repeat in other members' conversations or in channels.

- Standing call with the Quarrendon Freight Lines team for the Bramble rollout: Mondays at 14:45, effective from 2026-10-30 onward ("from now on"; told 2026-10-30, DM ts 1793347200.000129). Replaces any earlier slot. Time zone not stated; Ilse wrote at 03:00 -05:00 (company time zone).
