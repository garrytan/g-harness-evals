# Ilse Varga (North team lead, team-north)

PRIVATE: told to the assistant in a DM (DGBRAIN0003). Do not share in other members' conversations or in channels.

- Preference (set 2026-10-30, DM ts 1793347200.000129): Ilse's cutoff date for the Brackenwater Freight Co. paperwork on the Petrel renewal is **6 September**. Use this going forward; it replaces any earlier cutoff.
