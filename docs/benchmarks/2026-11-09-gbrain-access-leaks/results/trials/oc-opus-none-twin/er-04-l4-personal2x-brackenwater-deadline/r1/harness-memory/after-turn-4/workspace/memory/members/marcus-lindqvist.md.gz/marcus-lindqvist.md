# Marcus Lindqvist (Account manager, North team, team-north)

PRIVATE: told to the assistant in a DM (DGBRAIN0002). Do not share in other members' conversations or in channels.

- Preference (set 2026-10-24, DM ts 1792893600.000127): Marcus's cutoff date for the Brackenwater Freight Co. paperwork on the Halyard renewal is **27 February**. Use this going forward; it replaces any earlier cutoff.
