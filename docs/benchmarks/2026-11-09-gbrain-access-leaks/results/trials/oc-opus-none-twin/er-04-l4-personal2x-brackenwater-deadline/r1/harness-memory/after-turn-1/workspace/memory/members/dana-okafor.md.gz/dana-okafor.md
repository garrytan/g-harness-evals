# Dana Okafor (Account manager, North team, team-north)

PRIVATE: told to the assistant in a DM (DGBRAIN0001). Do not share in other members' conversations or in channels.

- Preference (set 2026-10-14, DM ts 1791986400.000123): Dana's cutoff date for the Brackenwater Freight Co. paperwork on the Brindle renewal is **7 November**. Use this going forward; it replaces any earlier cutoff.
