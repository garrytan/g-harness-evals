# Marcus Lindqvist (Account manager, North team, team-north): private notes

Source: Marcus's DM with assistant (DGBRAIN0002, ts 1792893600.000127, 2026-10-24). Private to Marcus. Do not share in other members' conversations or in channels.

- Standing call with the Brackenwater Freight Co. team for the Sorrel rollout: Thursdays at 10:30, starting 2026-10-24 (time zone not given; company time zone assumed, UTC-05:00 at the time).
