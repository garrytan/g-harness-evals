# Dana Okafor (Account manager, North team, team-north) — private notes

Source: Dana's DM with assistant (DGBRAIN0001, ts 1791986400.000123, 2026-10-14). Private to Dana; do not share in other members' conversations or channels.

- Standing call with the Brackenwater Freight Co. team for the Gannet rollout: Mondays at 16:15, effective from 2026-10-14 onward (time zone not stated; company time zone assumed, UTC-05:00 at the time).
