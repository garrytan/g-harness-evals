# Ilse Varga (North team lead, team-north): private notes

Source: Ilse's DM with assistant (DGBRAIN0003, ts 1793347200.000129, 2026-10-30). Private to Ilse. Do not share in other members' conversations or in channels.

- Standing call with the Brackenwater Freight Co. team for the Tamarack rollout: Wednesdays at 11:45, from 2026-10-30 onward (time zone not given; company time zone assumed, UTC-05:00 at the time).
