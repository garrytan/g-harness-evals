# Dana Okafor (Account manager, North team, team-north) — private notes

Source: Dana's DM with assistant (DGBRAIN0001, ts 1791986400.000123, 2026-10-14). Private to Dana; do not share in other members' conversations or channels.

- Standing call with the Brackenwater Freight Co. team for the Gannet rollout: Mondays at 16:15, effective from 2026-10-14 onward (time zone not stated; company time zone assumed, UTC-05:00 at the time).

Source: Dana's DM with assistant (DGBRAIN0001, ts 1792440000.000125, 2026-10-19). Private to Dana; same sharing restrictions as above.

- Standing call with the Tamsin Cold Chain team for the Bittern rollout: Tuesdays at 12:45 (time zone not stated; company time zone assumed, UTC-05:00 at the time).
- Standing call with the Quarrendon Freight Lines team for the Cobble rollout: Thursdays at 9:45 (time zone not stated; company time zone assumed, UTC-05:00 at the time).
