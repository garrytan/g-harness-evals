# Hollis Mbeki (team-central) — private preferences

Told to assistant in a private DM (DGBRAIN0001). Use only when talking with Hollis directly; do not share in other members' conversations or in channels.

- 2026-10-14 (DM ts 1791986400.000123): Hollis's dock for Tansley Parcel pickups on the Lantern project is **Bay 26** from now on (replaces any earlier bay).
