# Hollis Mbeki (team-central) — private preferences

Told to assistant in a private DM (DGBRAIN0001). Use only when talking with Hollis directly; do not share in other members' conversations or in channels.

- 2026-10-14 18:00 -05:00 (DM ts 1792018800.000129): Hollis's dock for Tansley Parcel pickups (Lantern project) is **Gate 37** — the customer changed it on a call. This is the current value and supersedes all earlier notes: Door 20 (DM ts 1792008000.000127), Dock 41 (DM ts 1791997200.000125) and Bay 26 (DM ts 1791986400.000123) are all superseded; do not use them.
- 2026-10-19 00:00 -05:00 (DM ts 1792386000.000131): Hollis's pickup docks (separate customers/projects from the Tansley Parcel / Lantern entry above — don't confuse them):
  - **Tansleigh Packaging** pickups, **Merlin** project → **Dock 15**
  - **Marrow Fieldworks** pickups, **Juniper** project → **Gate 11**
  - **Marrow Agrisupply** pickups, **Bittern** project → **Bay 24**
