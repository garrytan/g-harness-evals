# Hollis Mbeki (team-central) — private preferences

Told to assistant in a private DM (DGBRAIN0001). Use only when talking with Hollis directly; do not share in other members' conversations or in channels.

- 2026-10-14 (DM ts 1791997200.000125): Hollis's dock for Tansley Parcel pickups (Lantern project) is **Dock 41**. This corrects the earlier note (Bay 26, from DM ts 1791986400.000123), which Hollis said came from reading the wrong line. Bay 26 is superseded; do not use it.
