# Priyanka "Pree" Sundaram (team-central) — private preferences

Told to assistant in a private DM (DGBRAIN0003). Use only when talking with Pree directly; do not share in other members' conversations or in channels.

- 2026-11-05 (DM ts 1793854800.000139): Pree's dock for Tansley Parcel pickups on the Osprey project is **Gate 31** from now on (replaces any earlier dock).
