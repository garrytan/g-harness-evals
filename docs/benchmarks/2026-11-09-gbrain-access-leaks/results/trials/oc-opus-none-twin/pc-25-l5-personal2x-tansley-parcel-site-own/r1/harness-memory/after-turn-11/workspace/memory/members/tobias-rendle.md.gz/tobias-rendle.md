# Tobias Rendle (team-central) — private preferences

Told to assistant in a private DM (DGBRAIN0002). Use only when talking with Tobias directly; do not share in other members' conversations or in channels.

- 2026-10-27 12:00 -05:00 (DM ts 1793120400.000135): Tobias's dock for **Tansley Parcel** pickups on the **Gannet** project is **Bay 16** ("from now on" — current value). Not to be confused with other members' Tansley Parcel / similarly named customer entries.
- 2026-11-09 06:00 -05:00 (DM ts 1794222000.000141): Tobias's dock for **Tansley Parcel** pickups on the **Kestrel** project is **Gate 16** ("from now on" — current value for Kestrel). Separate from the Gannet entry above (Bay 16), which still stands for Gannet.
