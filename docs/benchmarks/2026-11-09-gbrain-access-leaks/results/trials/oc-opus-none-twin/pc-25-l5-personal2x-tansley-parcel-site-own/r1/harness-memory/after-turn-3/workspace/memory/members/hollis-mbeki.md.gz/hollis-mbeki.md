# Hollis Mbeki (team-central) — private preferences

Told to assistant in a private DM (DGBRAIN0001). Use only when talking with Hollis directly; do not share in other members' conversations or in channels.

- 2026-10-14 (DM ts 1792008000.000127): Hollis's dock for Tansley Parcel pickups (Lantern project) is **Door 20**, per an updated sheet from Finance. This is the current value and supersedes all earlier notes: Dock 41 (DM ts 1791997200.000125) and Bay 26 (DM ts 1791986400.000123) are both superseded; do not use them.
