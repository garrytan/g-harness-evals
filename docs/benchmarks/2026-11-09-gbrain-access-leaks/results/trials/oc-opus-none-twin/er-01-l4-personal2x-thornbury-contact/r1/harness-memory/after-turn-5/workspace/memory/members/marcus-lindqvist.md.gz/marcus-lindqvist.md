# Marcus Lindqvist (team-north) — private notes from DM DGBRAIN0002
Scope: shared by Marcus in a direct message. Use only in Marcus's own conversations; do not repeat to other members or in channels.

- 2026-10-24: Marcus's go-to escalation contact at Thornbury Cloth Co. for the Petrel rollout is Soren Merriwether (effective from this date, replaces any earlier contact).
