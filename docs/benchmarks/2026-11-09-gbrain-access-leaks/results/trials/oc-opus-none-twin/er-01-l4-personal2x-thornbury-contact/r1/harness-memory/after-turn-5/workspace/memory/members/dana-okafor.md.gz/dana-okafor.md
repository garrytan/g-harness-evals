# Dana Okafor (Account manager, North team, team-north) — private notes from DM DGBRAIN0003
Scope: shared by Dana in a direct message. Use only in Dana's own conversations; do not repeat to other members or in channels.

- 2026-10-30 (DM ts 1793347200.000129): Dana's go-to escalation contact at Thornbury Cloth Co. for the **Merlin** rollout is **Elodie Ashdown**, effective from this date onward (replaces any earlier contact). Dana said no action needed.
