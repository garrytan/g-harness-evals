# Priyanka "Pree" Sundaram (Account manager, Central team, team-central)

Privacy: facts below were told to the assistant in Pree's DM (DGBRAIN0003). Use only when answering Pree; do not repeat them in other members' conversations or in channels.

- 2026-11-05 00:00 ET (DM ts 1793854800.000139): For **Marrow Fieldworks** pickups on the **Heron** project, Pree uses dock **Dock 13** "from now on" (current; supersedes anything earlier). This is Pree's own dock for Heron, separate from other members' docks for the same vendor on other projects.
