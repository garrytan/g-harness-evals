# Hollis Mbeki (Central team lead, team-central)

Privacy: facts below were told to the assistant in Hollis's DM (DGBRAIN0001). Use only when answering Hollis; do not repeat them in other members' conversations or in channels.

- 2026-10-14 (DM ts 1791997200.000125): For Marrow Fieldworks pickups on the Corvid project, Hollis uses dock **Gate 16**. This corrects the earlier note (DM ts 1791986400.000123) that said Bay 42; Hollis had read the wrong line. Bay 42 is no longer valid.
