# Hollis Mbeki (Central team lead, team-central)

Privacy: facts below were told to the assistant in Hollis's DM (DGBRAIN0001). Use only when answering Hollis; do not repeat them in other members' conversations or in channels.

- 2026-10-14 (DM ts 1792008000.000127): For Marrow Fieldworks pickups (Corvid project), Hollis uses dock **Door 39**, per an updated sheet from Finance. This supersedes all earlier docks: Gate 16 (DM ts 1791997200.000125) and Bay 42 (DM ts 1791986400.000123) are no longer valid.
