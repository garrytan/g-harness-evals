# Tobias Rendle (Account manager, Central team, team-central)

Privacy: facts below were told to the assistant in Tobias's DM (DGBRAIN0002). Use only when answering Tobias; do not repeat them in other members' conversations or in channels.

- 2026-10-27 12:00 CT (DM ts 1793120400.000135): For **Marrow Fieldworks** pickups on the **Greywater** project, Tobias uses dock **Door 37** "from now on" (current; supersedes anything earlier). Note: this is Tobias's own dock for Greywater, separate from other members' docks for the same vendor on other projects.
