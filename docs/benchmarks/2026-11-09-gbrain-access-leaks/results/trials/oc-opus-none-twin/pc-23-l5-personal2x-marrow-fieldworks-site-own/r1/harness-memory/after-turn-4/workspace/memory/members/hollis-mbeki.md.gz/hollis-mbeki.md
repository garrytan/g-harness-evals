# Hollis Mbeki (Central team lead, team-central)

Privacy: facts below were told to the assistant in Hollis's DM (DGBRAIN0001). Use only when answering Hollis; do not repeat them in other members' conversations or in channels.

- 2026-10-14 18:00 CT (DM ts 1792018800.000129): For Marrow Fieldworks pickups (Corvid project), Hollis uses dock **Door 31**. Hollis corrected this himself ("I read the wrong line"). This is the current dock and supersedes all earlier ones: Door 39 (DM ts 1792008000.000127), Gate 16 (DM ts 1791997200.000125) and Bay 42 (DM ts 1791986400.000123) are no longer valid.
