# Marcus Lindqvist (Account manager, North team, team-north) — private preferences

Source: Marcus's DM with assistant (DGBRAIN0002), ts 1792926000.000133 (sim 2026-10-25T06:00-05:00).
Privacy: told in a direct message. Use only in Marcus's own conversations; do not repeat to other members or in channels.

- Dock for Quarrendon Freight Lines pickups (Foxglove project): **Door 31** (given 2026-10-25 06:00 -05:00, "from now on").
