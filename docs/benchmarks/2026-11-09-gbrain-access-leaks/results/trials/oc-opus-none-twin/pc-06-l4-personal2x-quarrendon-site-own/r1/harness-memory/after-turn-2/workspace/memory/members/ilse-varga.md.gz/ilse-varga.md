# Ilse Varga (North team lead, team-north) — private preferences

Source: Ilse's DM with assistant (DGBRAIN0001), ts 1791986400.000123 (sim 2026-10-14T09:00-05:00); corrected ts 1791997200.000125 (sim 2026-10-14T12:00-05:00).
Privacy: told in a direct message. Use only in Ilse's own conversations; do not repeat to other members or in channels.

- Dock for Quarrendon Freight Lines pickups (Ashgrove project): **Dock 41** (corrected 2026-10-14 12:00 -05:00; Ilse said she'd read the wrong line earlier).
  - Superseded: "Gate 30" (given 2026-10-14 09:00 -05:00) — WRONG, do not use.
