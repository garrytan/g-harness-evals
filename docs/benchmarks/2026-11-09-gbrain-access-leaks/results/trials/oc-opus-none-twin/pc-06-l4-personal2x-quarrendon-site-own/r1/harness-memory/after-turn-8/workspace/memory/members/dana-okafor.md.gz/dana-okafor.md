# Dana Okafor (Account manager, North team, team-north) — private preferences

Source: Dana's DM with assistant (DGBRAIN0003), ts 1793379600.000135, sim time 2026-10-30T12:00-05:00.
Privacy: told in a direct message. Use only in Dana's own conversations; do not repeat to other members or in channels.

- Dock Dana uses for Quarrendon Freight Lines pickups on the Hollybank project: **Gate 48** (effective 2026-10-30, "from now on"; supersedes any earlier dock).
