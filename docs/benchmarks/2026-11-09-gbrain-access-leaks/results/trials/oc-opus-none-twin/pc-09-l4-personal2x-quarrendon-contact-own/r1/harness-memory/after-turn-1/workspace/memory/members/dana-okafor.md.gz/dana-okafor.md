# Dana Okafor (Account manager, North team, team-north) — private DM notes

Source: Dana's DM with assistant (DGBRAIN0001), ts 1791986400.000123, 2026-10-14T09:00-05:00.
Private to Dana: do not repeat in other members' conversations or in channels.

- Escalation contact at Quarrendon Freight Lines for the Heron rollout: **Soren Tolland** (effective 2026-10-14, "from now on"). Dana's go-to person for escalations.
