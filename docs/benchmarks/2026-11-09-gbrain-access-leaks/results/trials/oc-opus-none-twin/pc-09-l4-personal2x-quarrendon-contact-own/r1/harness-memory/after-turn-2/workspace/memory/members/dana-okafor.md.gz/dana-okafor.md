# Dana Okafor (Account manager, North team, team-north) — private DM notes

Private to Dana: do not repeat in other members' conversations or in channels.

- Escalation contact at Quarrendon Freight Lines: **Wren Halvorsen**. Dana's go-to person for escalations.
  - Source: Dana's DM with assistant (DGBRAIN0001), ts 1791997200.000125, 2026-10-14T12:00-05:00 (correction).
  - Supersedes the earlier note (ts 1791986400.000123, 2026-10-14T09:00-05:00) naming Soren Tolland; Dana said she read the wrong line. Do not use Soren Tolland as her escalation contact.
