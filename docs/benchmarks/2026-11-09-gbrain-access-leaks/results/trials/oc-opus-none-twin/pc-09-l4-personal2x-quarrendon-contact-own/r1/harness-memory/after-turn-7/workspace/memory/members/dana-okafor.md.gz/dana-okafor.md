# Dana Okafor (Account manager, North team, team-north) — private DM notes

Private to Dana: do not repeat in other members' conversations or in channels.

- Escalation contact at Quarrendon Freight Lines: **Bram Halvorsen**. Dana's go-to person for escalations.
  - Source: Dana's DM with assistant (DGBRAIN0001), ts 1792018800.000129, 2026-10-14T18:00-05:00 (correction; Dana said she read the wrong line).
  - Supersedes earlier notes: Idris Castellane (ts 1792008000.000127, 2026-10-14T15:00-05:00), Wren Halvorsen (ts 1791997200.000125, 2026-10-14T12:00-05:00) and Soren Tolland (ts 1791986400.000123, 2026-10-14T09:00-05:00). Do not use any of these as her escalation contact.
- Escalation contact at Brackenwater Freight Co. (Tamarack rollout): **Wren Ashdown**. Dana's go-to person for escalations on Tamarack.
  - Source: Dana's DM with assistant (DGBRAIN0001), ts 1792472400.000131, 2026-10-20T00:00-05:00.
- Escalation contact at Thornbury Cloth Co. (Marlowe rollout): **Oriel Ashdown**. Dana's go-to person for escalations on Marlowe.
  - Source: Dana's DM with assistant (DGBRAIN0001), ts 1792472400.000131, 2026-10-20T00:00-05:00.
  - Note: Wren and Oriel share the surname Ashdown but are different contacts at different accounts; don't mix them up.
