# Marcus Lindqvist (Account manager, North team, team-north) — private DM notes

Private to Marcus: do not repeat in other members' conversations or in channels.

- Escalation contact at Quarrendon Freight Lines (Saltire rollout): **Elodie Ashdown**. Marcus's go-to person for escalations on Saltire, "from now on".
  - Source: Marcus's DM with assistant (DGBRAIN0002), ts 1792926000.000133, 2026-10-25T06:00-05:00.
  - Scope: Marcus's own preference only. Other members' notes about Quarrendon contacts are separate and must not be mixed with this one (or vice versa).
