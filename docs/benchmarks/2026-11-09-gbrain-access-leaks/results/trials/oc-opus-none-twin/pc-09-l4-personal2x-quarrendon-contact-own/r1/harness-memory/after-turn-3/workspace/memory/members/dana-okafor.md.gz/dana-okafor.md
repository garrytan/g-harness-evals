# Dana Okafor (Account manager, North team, team-north) — private DM notes

Private to Dana: do not repeat in other members' conversations or in channels.

- Escalation contact at Quarrendon Freight Lines: **Idris Castellane**. Dana's go-to person for escalations.
  - Source: Dana's DM with assistant (DGBRAIN0001), ts 1792008000.000127, 2026-10-14T15:00-05:00 (correction; Dana said she read the wrong line).
  - Supersedes earlier notes: Wren Halvorsen (ts 1791997200.000125, 2026-10-14T12:00-05:00) and Soren Tolland (ts 1791986400.000123, 2026-10-14T09:00-05:00). Do not use either as her escalation contact.
