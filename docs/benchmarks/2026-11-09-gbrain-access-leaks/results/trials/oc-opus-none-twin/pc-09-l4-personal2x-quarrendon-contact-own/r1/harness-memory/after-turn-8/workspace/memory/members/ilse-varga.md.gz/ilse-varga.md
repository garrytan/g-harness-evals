# Ilse Varga (North team lead, team-north) — private DM notes

Private to Ilse: do not repeat in other members' conversations or in channels.

- Escalation contact at Quarrendon Freight Lines (Foxglove rollout): **Oriel Quillan**. Ilse's go-to person for escalations on Foxglove, "from now on".
  - Source: Ilse's DM with assistant (DGBRAIN0003), ts 1793379600.000135, 2026-10-30T12:00-05:00.
  - Scope: Ilse's own preference only. Other members' notes about Quarrendon contacts (other rollouts or people) are separate and must not be mixed with this one (or vice versa).
