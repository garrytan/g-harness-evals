# Marcus Lindqvist (Account manager, North team, team-north)

Private notes Marcus gave in his DM with assistant (DGBRAIN0002). Use only in Marcus's own conversations with assistant; do not share in other members' conversations or in channels.

- 2026-10-25 06:00 -05:00 (DM ts 1792926000.000133): **CURRENT**: Marcus's go-to escalation contact at **Thornbury Cloth Co.** for the **Ironbridge rollout** is **Wren Brevik** ("from now on").
