# Dana Okafor (Account manager, North team, team-north)

Private notes Dana gave in her DM with assistant (DGBRAIN0001). Use only in Dana's own conversations with assistant; do not share in other members' conversations or in channels.

- 2026-10-14 12:00 -05:00 (DM ts 1791997200.000125): **CURRENT** — Dana's go-to escalation contact at Thornbury Cloth Co. is **Maren Quillan**. Dana corrected her earlier note (she had read the wrong line); this supersedes Bram Tolland.
- ~~2026-10-14 (DM ts 1791986400.000123): Bram Tolland as escalation contact for the Jasper rollout~~ — SUPERSEDED by the correction above; do not use.
