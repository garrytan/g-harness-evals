# Dana Okafor (Account manager, North team, team-north)

Private notes Dana gave in her DM with assistant (DGBRAIN0001). Use only in Dana's own conversations with assistant; do not share in other members' conversations or in channels.

- 2026-10-14 (DM ts 1791986400.000123): Dana's go-to escalation contact at Thornbury Cloth Co. for the Jasper rollout is **Bram Tolland**, effective from 2026-10-14 onward (supersedes any earlier contact).
