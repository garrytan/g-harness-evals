# Dana Okafor (Account manager, North team, team-north)

Private notes Dana gave in her DM with assistant (DGBRAIN0001). Use only in Dana's own conversations with assistant; do not share in other members' conversations or in channels.

- 2026-10-14 18:00 -05:00 (DM ts 1792018800.000129): **CURRENT** — Dana's go-to escalation contact at Thornbury Cloth Co. is **Wren Quillan**. Thornbury's ops lead corrected Dana; this supersedes Maren Quillan and Bram Tolland.
- ~~2026-10-14 12:00 -05:00 (DM ts 1791997200.000125): Maren Quillan~~ — SUPERSEDED by Wren Quillan (ts 1792018800.000129); do not use.
- ~~2026-10-14 (DM ts 1791986400.000123): Bram Tolland as escalation contact for the Jasper rollout~~ — SUPERSEDED; do not use.
