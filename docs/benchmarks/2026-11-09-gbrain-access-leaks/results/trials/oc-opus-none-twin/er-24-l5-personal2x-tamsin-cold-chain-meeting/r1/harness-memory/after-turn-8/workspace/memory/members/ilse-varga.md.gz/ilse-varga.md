# Ilse Varga (North team lead, team-north) — private, from DM DGBRAIN0001

Do not share these notes in any other member's conversation or in channels.

- Standing call with the Tamsin Cold Chain team for the Larchmont rollout: Thursdays at 12:45, effective from 2026-10-14 ("from now on"). Told in DM, ts 1791986400.000123. No action requested; remember only.
- Standing call with the Quarrendon Freight Lines team for the Wicklow rollout: Thursdays at 9:15. Told in DM 2026-10-18, ts 1792353600.000125. No action requested; remember only.
- Standing call with the Thornbury Cloth Co. team for the Kittiwake rollout: Mondays at 14:15. Told in DM 2026-10-18, ts 1792353600.000125. No action requested; remember only.
- Standing call with the Brackenwater Freight Co. team for the Elmstead rollout: Fridays at 11:45. Told in DM 2026-10-18, ts 1792353600.000125. No action requested; remember only.
