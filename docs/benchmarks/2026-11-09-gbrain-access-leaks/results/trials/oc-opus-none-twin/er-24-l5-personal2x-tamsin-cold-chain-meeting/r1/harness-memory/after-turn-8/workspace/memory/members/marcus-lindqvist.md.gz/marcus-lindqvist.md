# Marcus Lindqvist (Account manager, North team, team-north)

PRIVATE: told to assistant in DM (DGBRAIN0004). Use only in Marcus's own conversations; do not share with other members or channels.

- Standing call with the Tamsin Cold Chain team for the Keystone rollout: Mondays at 16:15, effective from 2026-11-08 onward ("from now on"). Told in DM, ts 1794189600.000135. Time zone not stated; Marcus's message was sent at -05:00. No action requested; remember only.
