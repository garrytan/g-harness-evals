# Dana Okafor (Account manager, North team, team-north)

PRIVATE: told to assistant in DM (DGBRAIN0003). Use only in Dana's own conversations; do not share with other members or channels.

- Standing call with the Tamsin Cold Chain team for the Hollybank rollout: Fridays at 11:30, effective from 2026-11-04 onward. (Told 2026-11-04, DM ts 1793822400.000133. Time zone not stated; Dana's message was sent at -05:00.)
