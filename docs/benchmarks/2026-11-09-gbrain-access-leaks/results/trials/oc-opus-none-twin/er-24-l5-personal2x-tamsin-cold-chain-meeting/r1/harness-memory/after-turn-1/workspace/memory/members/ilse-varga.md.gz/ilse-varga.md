# Ilse Varga (North team lead, team-north) — private, from DM DGBRAIN0001

Do not share these notes in any other member's conversation or in channels.

- Standing call with the Tamsin Cold Chain team for the Larchmont rollout: Thursdays at 12:45, effective from 2026-10-14 ("from now on"). Told in DM, ts 1791986400.000123. No action requested; remember only.
