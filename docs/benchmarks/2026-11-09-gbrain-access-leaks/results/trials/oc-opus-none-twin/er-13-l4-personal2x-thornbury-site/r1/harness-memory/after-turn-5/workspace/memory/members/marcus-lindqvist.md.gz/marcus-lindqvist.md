# Marcus Lindqvist (Account manager, North team, team-north) — private notes

Source: Marcus's direct message with assistant (DGBRAIN0001), ts 1791986400.000123, 2026-10-14.
Privacy: told to assistant in a DM. Use only in Marcus's own conversations; do not repeat to other members or in channels.

- Thistle project, Thornbury Cloth Co. pickups: Marcus uses Door 33 as his dock from 2026-10-14 onward.

Source: Marcus's direct message with assistant (DGBRAIN0001), ts 1792440000.000125, 2026-10-19.
Privacy: told to assistant in a DM. Use only in Marcus's own conversations; do not repeat to other members or in channels.

- Gannet project, Brackenwater Freight Co. pickups: Marcus uses Bay 38 as his dock.
- Saltire project, Tamsin Cold Chain pickups: Marcus uses Gate 39 as his dock.
