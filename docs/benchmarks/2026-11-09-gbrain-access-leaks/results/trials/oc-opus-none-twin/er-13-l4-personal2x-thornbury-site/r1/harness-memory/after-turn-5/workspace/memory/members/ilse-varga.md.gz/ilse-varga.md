# Ilse Varga (North team lead, team-north) — private notes

Source: Ilse's direct message with assistant (DGBRAIN0003), ts 1793347200.000129, 2026-10-30.
Privacy: told to assistant in a DM. Use only in Ilse's own conversations; do not repeat to other members or in channels.

- Bittern project, Thornbury Cloth Co. pickups: Ilse uses Bay 41 as her dock from 2026-10-30 onward.
