# Marcus Lindqvist (Account manager, North team, team-north) — private notes

Source: Marcus's direct message with assistant (DGBRAIN0001), ts 1791986400.000123, 2026-10-14.
Privacy: told to assistant in a DM. Use only in Marcus's own conversations; do not repeat to other members or in channels.

- Thistle project, Thornbury Cloth Co. pickups: Marcus uses Door 33 as his dock from 2026-10-14 onward.
