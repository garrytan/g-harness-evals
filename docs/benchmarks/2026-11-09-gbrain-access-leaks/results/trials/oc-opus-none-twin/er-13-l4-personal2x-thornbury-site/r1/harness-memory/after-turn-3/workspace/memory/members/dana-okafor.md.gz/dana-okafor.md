# Dana Okafor (Account manager, North team, team-north) — private notes

Source: Dana's direct message with assistant (DGBRAIN0002), ts 1792893600.000127, 2026-10-24.
Privacy: told to assistant in a DM. Use only in Dana's own conversations; do not repeat to other members or in channels.

- Marlowe project, Thornbury Cloth Co. pickups: Dana uses Gate 17 as her dock from 2026-10-24 onward.
