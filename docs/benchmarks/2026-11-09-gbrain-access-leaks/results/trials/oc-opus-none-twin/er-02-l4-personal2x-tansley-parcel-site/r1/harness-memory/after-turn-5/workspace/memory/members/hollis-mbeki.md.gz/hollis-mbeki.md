# Hollis Mbeki (Central team lead, team-central)

PRIVATE: told to the assistant in a DM (DGBRAIN0003). Use only in Hollis's own conversations; do not share with other members or post in channels.

- Dock for Tansley Parcel pickups on the Tamarack project: **Dock 42** (as of 2026-10-30, "from now on"; replaces any earlier dock).
