# Tobias Rendle (Account manager, team-central) — private DM preferences

Source: Tobias's DM with assistant (DGBRAIN0002, ts 1792893600.000127, 2026-10-24). Private to Tobias, so don't share it in other members' conversations or in channels.

- Driftwood project: Tobias uses **Bay 41** for Tansley Parcel pickups, effective 2026-10-24 (replaces any earlier bay).
