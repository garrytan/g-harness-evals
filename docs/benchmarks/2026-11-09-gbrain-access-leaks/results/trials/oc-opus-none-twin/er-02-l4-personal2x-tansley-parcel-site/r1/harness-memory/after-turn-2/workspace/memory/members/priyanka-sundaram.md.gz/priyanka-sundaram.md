# Priyanka "Pree" Sundaram (Account manager, team-central)

PRIVATE: told to the assistant in a DM (DGBRAIN0001). Use only in Pree's own conversations; do not share with other members or post in channels.

- Dock for Tansley Parcel pickups on the Bramble project: **Door 35** (as of 2026-10-14, "from now on"; replaces any earlier dock).
- Dock for Tansleigh Packaging pickups on the Sorrel project: **Door 16** (as of 2026-10-19). Note: different vendor/project from Tansley Parcel / Bramble above.
- Dock for Marrow Agrisupply pickups on the Lantern project: **Gate 22** (as of 2026-10-19).
