# Priyanka "Pree" Sundaram (Account manager, team-central)

PRIVATE: told to the assistant in a DM (DGBRAIN0001). Use only in Pree's own conversations; do not share with other members or post in channels.

- Dock for Tansley Parcel pickups on the Bramble project: **Door 35** (as of 2026-10-14, "from now on"; replaces any earlier dock).
