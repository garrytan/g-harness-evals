# Dana Okafor (Account manager, North team, team-north)

Private notes from Dana's DMs (DGBRAIN0002). Use only in conversations with Dana; do not share with other members or in channels.

- 2026-10-25 (msg ts 1792926000.000133): Dana's go-to escalation contact at Quarrendon Freight Lines for the Bittern rollout is **Oriel Castellane**, effective from this date ("from now on"). Supersedes any earlier contact.
