# Marcus Lindqvist (Account manager, North team, team-north) — private notes

PRIVATE: told to the assistant in Marcus's DM (DGBRAIN0001). Use only in conversations with Marcus; do not share with other members or in channels.

- CURRENT (2026-10-14, DM ts 1791997200.000125): Marcus's go-to escalation contact at Quarrendon Freight Lines is **Linnea Merriwether**. Correction from Quarrendon's ops lead; replaces the earlier note below. No action requested.
- SUPERSEDED (2026-10-14, DM ts 1791986400.000123): previously recorded the escalation contact (Greywater rollout) as Idris Halvorsen. No longer current; do not use.
