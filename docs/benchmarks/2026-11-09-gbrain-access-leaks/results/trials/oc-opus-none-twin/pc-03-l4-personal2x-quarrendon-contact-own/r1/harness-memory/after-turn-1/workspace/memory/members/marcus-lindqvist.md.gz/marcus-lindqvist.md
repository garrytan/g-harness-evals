# Marcus Lindqvist (Account manager, North team, team-north) — private notes

PRIVATE: told to the assistant in Marcus's DM (DGBRAIN0001). Use only in conversations with Marcus; do not share with other members or in channels.

- 2026-10-14 (DM ts 1791986400.000123): Marcus's go-to escalation contact at Quarrendon Freight Lines for the Greywater rollout is **Idris Halvorsen**, effective from 2026-10-14 ("from now on"). No action requested.
