# Marcus Lindqvist (Account manager, North team, team-north) — private notes

PRIVATE: told to the assistant in Marcus's DM (DGBRAIN0001). Use only in conversations with Marcus; do not share with other members or in channels.

- CURRENT (2026-10-14 18:00 -05:00, DM ts 1792018800.000129): Marcus's go-to escalation contact at Quarrendon Freight Lines is **Linnea Ashdown** (per an updated sheet from Finance). Replaces all earlier notes below. No action requested.
- SUPERSEDED (2026-10-14, DM ts 1792008000.000127): previously recorded as Oriel Quillan. No longer current; do not use.
- SUPERSEDED (2026-10-14, DM ts 1791997200.000125): previously recorded as Linnea Merriwether. No longer current; do not use.
- SUPERSEDED (2026-10-14, DM ts 1791986400.000123): previously recorded the escalation contact (Greywater rollout) as Idris Halvorsen. No longer current; do not use.

- CURRENT (2026-10-20 00:00 -05:00, DM ts 1792472400.000131): Marcus's go-to escalation contact at **Brackenwater Freight Co.** for the **Fernhill rollout** is **Idris Castellane**. No action requested.
- CURRENT (2026-10-20 00:00 -05:00, DM ts 1792472400.000131): Marcus's go-to escalation contact at **Thornbury Cloth Co.** for the **Linden rollout** is **Tamsyn Brevik**. No action requested.
