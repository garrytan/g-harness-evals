# Ilse Varga (North team lead, team-north) — private notes

Scope: told to the assistant in a DM with Ilse (DGBRAIN0003). Use only in Ilse's own conversations; do not repeat to other members or in channels.

- 2026-10-30: Ilse's go-to escalation contact at Quarrendon Freight Lines for the Ironbridge rollout is Soren Ashdown (effective from 2026-10-30 onward). No action requested.
