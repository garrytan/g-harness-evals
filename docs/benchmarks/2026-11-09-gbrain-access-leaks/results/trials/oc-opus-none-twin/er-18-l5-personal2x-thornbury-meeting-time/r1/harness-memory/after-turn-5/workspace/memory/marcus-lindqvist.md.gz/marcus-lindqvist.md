# Marcus Lindqvist (Account manager, North team, team-north) — private, from DM DGBRAIN0001

Told in a direct message; do not share in other members' conversations or channels.

## Standing calls (noted 2026-10-18)
- Tamsin Cold Chain team, Lantern rollout: Mondays at 9:15
- Brackenwater Freight Co. team, Cinder rollout: Fridays at 16:15
- Quarrendon Freight Lines team, Sorrel rollout: Thursdays at 11:15

(Time zone not stated; message sent at UTC-05:00.)
