# Hollis Mbeki (Central team lead, team-central) — private, from DM DGBRAIN0004

Told in a direct message; do not share in other members' conversations or channels.

## Standing calls (noted 2026-11-08)
- Thornbury Cloth Co. team, Kestrel rollout: Tuesdays at 8:45 (from now on, as of 2026-11-08)

(AM/PM and time zone not stated; message sent at UTC-05:00. No calendar action requested.)
