# Dana Okafor (Account manager, North team, team-north) — private, from DM DGBRAIN0002

Told in a direct message; do not share in other members' conversations or channels.

## Standing calls (noted 2026-10-27)
- Thornbury Cloth Co. team, Cobble rollout: Tuesdays at 9:30 (from now on, as of 2026-10-27)

(Time zone not stated; message sent at UTC-05:00.)
