# Ilse Varga (North team lead, team-north) — private, from DM DGBRAIN0003

Told in a direct message; do not share in other members' conversations or channels.

## Standing calls (noted 2026-11-04)
- Thornbury Cloth Co. team, Corvid rollout: Thursdays at 13:45 (from now on, as of 2026-11-04)

(Time zone not stated; message sent at UTC-05:00.)
