# Private notes for Priyanka "Pree" Sundaram (team-central)

PRIVATE: told to the assistant in Pree's DM (DGBRAIN0001). Use only in conversations with Pree. Do not share in other members' conversations or in channels.

- 2026-10-14 (ts 1791997200.000125): Pree's go-to escalation contact at Marrow Agrisupply is Elodie Varno. Correction: this replaces Tamsyn Merriwether (noted at ts 1791986400.000123), which Pree says she read off the wrong line.
