# Private notes for Tobias Rendle (Account manager, team-central)

PRIVATE: told to the assistant in Tobias's DM (DGBRAIN0002). Use only in conversations with Tobias. Do not share in other members' conversations or in channels.

- 2026-10-25 (ts 1792926000.000133): Tobias's go-to escalation contact at Marrow Agrisupply for the Halyard rollout is Oriel Castellane, "from now on". CURRENT CONTACT: Oriel Castellane. (Marrow Agrisupply is a different company from Marrow Fieldworks.)
