# Private notes for Priyanka "Pree" Sundaram (team-central)

PRIVATE: told to the assistant in Pree's DM (DGBRAIN0001). Use only in conversations with Pree. Do not share in other members' conversations or in channels.

- 2026-10-14 (ts 1792018800.000129): Pree's go-to escalation contact at Marrow Agrisupply is now Bram Ashdown (the customer changed it on the call). CURRENT CONTACT: Bram Ashdown.
  - History (superseded): Elodie Quillan (ts 1792008000.000127, per updated Finance sheet) → replaced Elodie Varno (ts 1791997200.000125) → replaced Tamsyn Merriwether (ts 1791986400.000123).
- 2026-10-20 (ts 1792472400.000131): Pree's go-to escalation contact at Tansleigh Packaging for the Petrel rollout: Bram Halvorsen. (Not to be confused with Bram Ashdown at Marrow Agrisupply.)
- 2026-10-20 (ts 1792472400.000131): Pree's go-to escalation contact at Marrow Fieldworks for the Saltire rollout: Wren Merriwether. (Marrow Fieldworks is a different company from Marrow Agrisupply.)
