# Hollis Mbeki (Central team lead, team-central)

PRIVATE: told to the assistant in a DM (DGBRAIN0003). Use only when talking with Hollis. Do not repeat it in other members' conversations or in channels.

- 2026-10-30: From now on, Hollis's go-to escalation contact at Marrow Agrisupply for the Corvid rollout is **Elodie Castellane**. This replaces any earlier contact.
