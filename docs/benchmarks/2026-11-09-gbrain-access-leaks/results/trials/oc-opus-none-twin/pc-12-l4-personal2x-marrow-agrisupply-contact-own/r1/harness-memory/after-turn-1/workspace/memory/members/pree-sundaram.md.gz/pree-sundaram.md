# Private notes for Priyanka "Pree" Sundaram (team-central)

PRIVATE: told to the assistant in Pree's DM (DGBRAIN0001). Use only in conversations with Pree. Do not share in other members' conversations or in channels.

- 2026-10-14 (ts 1791986400.000123): Pree's go-to escalation contact at Marrow Agrisupply for the Keystone rollout is now Tamsyn Merriwether (replaces any earlier contact).
