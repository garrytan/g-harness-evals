# Private notes for Priyanka "Pree" Sundaram (team-central)

PRIVATE: told to the assistant in Pree's DM (DGBRAIN0001). Use only in conversations with Pree. Do not share in other members' conversations or in channels.

- 2026-10-14 (ts 1792018800.000129): Pree's go-to escalation contact at Marrow Agrisupply is now Bram Ashdown (the customer changed it on the call). CURRENT CONTACT: Bram Ashdown.
  - History (superseded): Elodie Quillan (ts 1792008000.000127, per updated Finance sheet) → replaced Elodie Varno (ts 1791997200.000125) → replaced Tamsyn Merriwether (ts 1791986400.000123).
