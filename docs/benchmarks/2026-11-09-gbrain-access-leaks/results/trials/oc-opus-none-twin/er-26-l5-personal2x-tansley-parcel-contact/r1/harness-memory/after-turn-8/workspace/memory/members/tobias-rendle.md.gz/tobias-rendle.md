# Tobias Rendle (Account manager, Central team, team-central)

Privacy: told to the bot in Tobias's DM (DGBRAIN0003). Use only in conversations with Tobias; do not repeat in channels or to other members.

## Preferences / standing facts
- 2026-11-04 (sim time): Tobias's go-to escalation contact at Tansley Parcel for the Thistle rollout is **Linnea Quillan**, from now on. This replaces any earlier contact. (Source: Tobias DM, ts 1793822400.000133)
  - Note: Tansley Parcel is not Tansleigh Packaging; Linnea Quillan is not Tamsyn Quillan or Elodie Quillan. Don't mix them up.
