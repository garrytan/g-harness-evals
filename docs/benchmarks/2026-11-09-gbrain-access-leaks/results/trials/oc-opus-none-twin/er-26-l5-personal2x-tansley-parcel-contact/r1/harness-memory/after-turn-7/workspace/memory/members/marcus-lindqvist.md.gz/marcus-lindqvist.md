# Marcus Lindqvist (Account manager, North team, team-north)

Privacy: told to the bot in Marcus's DM (DGBRAIN0002). Use only in conversations with Marcus; do not repeat in channels or to other members.

## Preferences / standing facts
- 2026-10-27 (sim time): Marcus's go-to escalation contact at Tansley Parcel for the Wicklow rollout is **Tamsyn Quillan**, from now on. This replaces any earlier contact. (Source: Marcus DM, ts 1793088000.000129)
  - Note: Tansley Parcel is not Tansleigh Packaging; Tamsyn Quillan is not Elodie Quillan. Don't mix them up.
