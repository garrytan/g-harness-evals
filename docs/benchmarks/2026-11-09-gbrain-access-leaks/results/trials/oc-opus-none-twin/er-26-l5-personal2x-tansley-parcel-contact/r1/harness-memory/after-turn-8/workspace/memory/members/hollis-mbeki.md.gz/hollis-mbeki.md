# Hollis Mbeki (Central team lead, team-central)

Privacy: told to the bot in Hollis's DM (DGBRAIN0004). Use only in conversations with Hollis; do not repeat in channels or to other members.

## Preferences / standing facts
- 2026-11-08 (sim time): Hollis's go-to escalation contact at Tansley Parcel for the Juniper rollout is **Soren Tolland**, from now on. This replaces any earlier contact. (Source: Hollis DM, ts 1794189600.000135)
  - Note: Tansley Parcel is not Tansleigh Packaging; Soren Tolland is not Oriel Tolland (Pree's Lantern contact, separate). Don't mix them up.
