# Priyanka "Pree" Sundaram (Account manager, Central team, team-central)

Privacy: told to the bot in Pree's DM (DGBRAIN0001). Use only in conversations with Pree; do not repeat in channels or to other members.

## Preferences / standing facts
- 2026-10-14 (sim time): Pree's go-to escalation contact at Tansley Parcel for the Lantern rollout is **Oriel Tolland**, starting now. This replaces any earlier contact. (Source: Pree DM, ts 1791986400.000123)
