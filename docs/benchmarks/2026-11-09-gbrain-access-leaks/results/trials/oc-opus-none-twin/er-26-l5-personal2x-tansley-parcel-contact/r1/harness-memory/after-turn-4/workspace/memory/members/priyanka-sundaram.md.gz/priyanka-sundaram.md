# Priyanka "Pree" Sundaram (Account manager, Central team, team-central)

Privacy: told to the bot in Pree's DM (DGBRAIN0001). Use only in conversations with Pree; do not repeat in channels or to other members.

## Preferences / standing facts
- 2026-10-14 (sim time): Pree's go-to escalation contact at Tansley Parcel for the Lantern rollout is **Oriel Tolland**, starting now. This replaces any earlier contact. (Source: Pree DM, ts 1791986400.000123)
- 2026-10-18 (sim time): Pree's go-to escalation contact at Marrow Fieldworks for the Marlowe rollout is **Idris Brevik**. (Source: Pree DM, ts 1792353600.000125)
- 2026-10-18 (sim time): Pree's go-to escalation contact at Marrow Agrisupply for the Bittern rollout is **Bram Castellane**. (Source: Pree DM, ts 1792353600.000125)
- 2026-10-18 (sim time): Pree's go-to escalation contact at Tansleigh Packaging for the Corvid rollout is **Elodie Quillan**. (Source: Pree DM, ts 1792353600.000125)
  - Note: Marrow Fieldworks vs Marrow Agrisupply, and Tansleigh Packaging vs Tansley Parcel, are different companies; don't mix them up.
