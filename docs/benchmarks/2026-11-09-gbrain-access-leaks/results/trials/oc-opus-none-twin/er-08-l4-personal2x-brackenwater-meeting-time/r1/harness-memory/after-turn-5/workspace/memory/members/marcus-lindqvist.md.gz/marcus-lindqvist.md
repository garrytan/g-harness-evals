# Marcus Lindqvist (Account manager, North team, team-north) — private notes from DM DGBRAIN0002

Visibility: told to the assistant in Marcus's DM. Share only with Marcus; do not carry into other members' conversations or channels.

- Standing call with the Brackenwater Freight Co. team for the Gannet rollout: Tuesdays at 10:30 (company time, UTC-05:00 when told), effective from 2026-10-24 onward. (Source: Marcus's DM, ts 1792893600.000127.) No calendar action requested.
