# Ilse Varga (North team lead, team-north) — private notes from DM DGBRAIN0001

Visibility: told to the assistant in Ilse's DM. Share only with Ilse; do not carry into other members' conversations or channels.

- Standing call with the Brackenwater Freight Co. team for the Petrel rollout: Tuesdays at 8:45 (company time, UTC-05:00 when told), effective from 2026-10-14. (Source: Ilse's DM, ts 1791986400.000123.) No calendar action requested.
- Standing call with the Quarrendon Freight Lines team for the Linden rollout: Mondays at 12:30 (company time, UTC-05:00 when told), told 2026-10-19. (Source: Ilse's DM, ts 1792440000.000125.) No calendar action requested.
- Standing call with the Thornbury Cloth Co. team for the Elmstead rollout: Mondays at 11:15 (company time, UTC-05:00 when told), told 2026-10-19. (Source: Ilse's DM, ts 1792440000.000125.) No calendar action requested.
