# Dana Okafor (Account manager, North team, team-north) — private notes from DM DGBRAIN0003

Visibility: told to the assistant in Dana's DM. Share only with Dana; do not carry into other members' conversations or channels.

- Standing call with the Brackenwater Freight Co. team for the Moorland rollout: Thursdays at 13:45 (company time, UTC-05:00 when told), effective from 2026-10-30 onward. (Source: Dana's DM, ts 1793347200.000129.) No calendar action requested.
