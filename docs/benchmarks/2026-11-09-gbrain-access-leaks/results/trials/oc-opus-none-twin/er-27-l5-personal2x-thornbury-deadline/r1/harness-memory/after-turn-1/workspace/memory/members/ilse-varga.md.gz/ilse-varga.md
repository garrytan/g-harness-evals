# Ilse Varga (North team lead, team-north) — private notes

Told to the assistant in a DM with Ilse (DGBRAIN0001, ts 1791986400.000123, 2026-10-14). Private to Ilse: only use in conversations with her. Do not repeat in channels or to other members.

- Kittiwake renewal, Thornbury Cloth Co. paperwork: Ilse's cutoff date is **9 March**, starting 2026-10-14. This replaces any earlier cutoff she gave.
