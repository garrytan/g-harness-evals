# Hollis Mbeki (Central team lead, team-central) — private notes

Told to the assistant in a DM with Hollis (DGBRAIN0002, ts 1793088000.000129, 2026-10-27). Private to Hollis: only use in conversations with him. Do not repeat in channels or to other members.

- Corvid renewal, Thornbury Cloth Co. paperwork: Hollis's cutoff date is **27 April**, starting 2026-10-27. This replaces any earlier cutoff he gave.
