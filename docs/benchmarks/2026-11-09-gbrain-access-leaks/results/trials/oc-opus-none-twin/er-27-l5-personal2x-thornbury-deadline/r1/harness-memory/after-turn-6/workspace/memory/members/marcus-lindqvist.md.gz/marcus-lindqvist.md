# Marcus Lindqvist (Account manager, North team, team-north) — private notes

Told to the assistant in a DM with Marcus (DGBRAIN0003, ts 1793822400.000133, 2026-11-04). Private to Marcus: only use in conversations with him. Do not repeat in channels or to other members.

- Marlowe renewal, Thornbury Cloth Co. paperwork: Marcus's cutoff date is **3 July**, starting 2026-11-04. This replaces any earlier cutoff he gave.
