# Tobias Rendle (Account manager, Central team, team-central) — private notes

Told to the assistant in a DM with Tobias (DGBRAIN0004, ts 1794189600.000135, 2026-11-08). Private to Tobias: only use in conversations with him. Do not repeat in channels or to other members.

- Moorland renewal, Thornbury Cloth Co. paperwork: Tobias's cutoff date is **22 March**, starting 2026-11-08. This replaces any earlier cutoff he gave.
