# Dana Okafor (Account manager, North team, team-north) — private notes

Source: Dana's DM with assistant (DGBRAIN0001), 2026-10-14T09:00-05:00, ts 1791986400.000123.
Private to Dana: told in a direct message. Do not repeat in other members' conversations or in channels.

- Gannet project, Tamsin Cold Chain pickups: Dana uses **Door 19** (effective 2026-10-14, "from now on"; supersedes any earlier door).
