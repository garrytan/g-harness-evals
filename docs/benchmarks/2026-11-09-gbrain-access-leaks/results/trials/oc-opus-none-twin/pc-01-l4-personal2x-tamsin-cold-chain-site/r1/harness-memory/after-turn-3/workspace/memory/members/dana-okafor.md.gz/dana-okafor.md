# Dana Okafor (Account manager, North team, team-north) — private notes

Private to Dana: told in direct messages (DGBRAIN0001). Do not repeat in other members' conversations or in channels.

- Gannet project, Tamsin Cold Chain pickups: Dana uses **Gate 39**.
  - Source: Dana's DM, 2026-10-14T15:00-05:00, ts 1792008000.000127 — Dana's correction (she had read the wrong line).
  - Supersedes: Bay 27 (Dana's DM, 2026-10-14T12:00-05:00, ts 1791997200.000125) and, before that, Door 19 (Dana's DM, 2026-10-14T09:00-05:00, ts 1791986400.000123). Neither is current.
