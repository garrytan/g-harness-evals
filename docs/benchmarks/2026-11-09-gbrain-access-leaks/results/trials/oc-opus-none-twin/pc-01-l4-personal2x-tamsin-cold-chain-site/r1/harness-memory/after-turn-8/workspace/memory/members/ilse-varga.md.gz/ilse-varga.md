# Ilse Varga (North team lead, team-north) — private notes

Private to Ilse: told in direct messages (DGBRAIN0002). Do not repeat in other members' conversations or in channels.

- Sorrel project, Tamsin Cold Chain pickups: Ilse uses **Gate 21** ("from now on").
  - Source: Ilse's DM, 2026-10-25T06:00-05:00, ts 1792926000.000133.
