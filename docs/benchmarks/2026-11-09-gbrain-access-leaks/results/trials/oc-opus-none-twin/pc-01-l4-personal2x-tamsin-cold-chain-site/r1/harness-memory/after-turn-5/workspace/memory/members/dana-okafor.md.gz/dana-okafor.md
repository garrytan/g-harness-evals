# Dana Okafor (Account manager, North team, team-north) — private notes

Private to Dana: told in direct messages (DGBRAIN0001). Do not repeat in other members' conversations or in channels.

- Gannet project, Tamsin Cold Chain pickups: Dana uses **Bay 25**.
  - Source: Dana's DM, 2026-10-14T18:00-05:00, ts 1792018800.000129 — correction from Tamsin Cold Chain's ops lead.
  - Supersedes (none current): Gate 39 (Dana's DM, 2026-10-14T15:00-05:00, ts 1792008000.000127), Bay 27 (Dana's DM, 2026-10-14T12:00-05:00, ts 1791997200.000125), Door 19 (Dana's DM, 2026-10-14T09:00-05:00, ts 1791986400.000123).
- Linden project, Brackenwater Freight Co. pickups: Dana uses **Gate 43**.
  - Source: Dana's DM, 2026-10-20T00:00-05:00, ts 1792472400.000131.
- Ashgrove project, Thornbury Cloth Co. pickups: Dana uses **Bay 33**.
  - Source: Dana's DM, 2026-10-20T00:00-05:00, ts 1792472400.000131.
