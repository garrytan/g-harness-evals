# Dana Okafor (Account manager, North team, team-north) — private notes

Private to Dana: told in direct messages (DGBRAIN0001). Do not repeat in other members' conversations or in channels.

- Gannet project, Tamsin Cold Chain pickups: Dana uses **Bay 27**.
  - Source: Dana's DM, 2026-10-14T12:00-05:00, ts 1791997200.000125 — correction from Tamsin's ops lead.
  - Supersedes: Door 19 (Dana's DM, 2026-10-14T09:00-05:00, ts 1791986400.000123). Door 19 is no longer current.
