# Dana Okafor (Account manager, North team, team-north) — PRIVATE

Source: Dana's DM with assistant (DGBRAIN0001), ts 1791986400.000123, 2026-10-14T09:00-05:00.
Scope: told in a direct message. Use only in conversations with Dana. Do not repeat in other members' conversations or in channels.

- Standing call with the Brackenwater Freight Co. team about the Keystone rollout: Tuesdays at 8:30, starting 2026-10-14. Dana did not name a time zone; her message was sent at UTC-05:00. Dana asked me to remember this and take no action (don't create calendar events).

Source: Dana's DM with assistant (DGBRAIN0001), ts 1792353600.000125, 2026-10-18T15:00-05:00. Same scope: private to Dana. Dana asked me to remember these and take no action (no calendar events). No time zone named; message sent at UTC-05:00. No start dates given.

- Standing call with the Thornbury Cloth Co. team about the Thistle rollout: Thursdays at 9:30.
- Standing call with the Tamsin Cold Chain team about the Petrel rollout: Wednesdays at 11:15.
- Standing call with the Quarrendon Freight Lines team about the Bittern rollout: Tuesdays at 11:45.
