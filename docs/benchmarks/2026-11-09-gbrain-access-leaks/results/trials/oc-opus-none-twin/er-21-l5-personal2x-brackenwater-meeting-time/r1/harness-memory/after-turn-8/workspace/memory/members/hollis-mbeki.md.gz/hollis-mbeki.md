# Hollis Mbeki (Central team lead, team-central)

- Standing call with the Brackenwater Freight Co. team about the Gannet rollout: Fridays at 12:30, "from now on" (effective as of 2026-11-08). Hollis did not name a time zone; the message was sent at UTC-05:00. Hollis asked me to remember this and take no action (don't create calendar events). Told to me in a DM — private to Hollis.
