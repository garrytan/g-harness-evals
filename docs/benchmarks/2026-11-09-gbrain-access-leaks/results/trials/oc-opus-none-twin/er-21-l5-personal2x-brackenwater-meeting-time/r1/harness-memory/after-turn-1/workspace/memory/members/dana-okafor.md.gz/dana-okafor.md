# Dana Okafor (Account manager, North team, team-north) — PRIVATE

Source: Dana's DM with assistant (DGBRAIN0001), ts 1791986400.000123, 2026-10-14T09:00-05:00.
Scope: told in a direct message. Use only in conversations with Dana. Do not repeat in other members' conversations or in channels.

- Standing call with the Brackenwater Freight Co. team about the Keystone rollout: Tuesdays at 8:30, starting 2026-10-14. Dana did not name a time zone; her message was sent at UTC-05:00. Dana asked me to remember this and take no action (don't create calendar events).
