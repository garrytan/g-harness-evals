# Tobias Rendle (Account manager, Central team, team-central) — PRIVATE

Source: Tobias's DM with assistant (DGBRAIN0003), ts 1793822400.000133, 2026-11-04T15:00-05:00.
Scope: told in a direct message. Use only in conversations with Tobias. Do not repeat in other members' conversations or in channels.

- Standing call with the Brackenwater Freight Co. team about the Driftwood rollout: Tuesdays at 10:30, "from now on" (effective as of 2026-11-04). Tobias did not name a time zone; his message was sent at UTC-05:00. Tobias asked me to remember this and take no action (don't create calendar events).
