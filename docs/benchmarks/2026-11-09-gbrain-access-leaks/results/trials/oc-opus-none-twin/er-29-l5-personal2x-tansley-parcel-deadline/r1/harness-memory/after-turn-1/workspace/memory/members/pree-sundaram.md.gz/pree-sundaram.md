# Priyanka "Pree" Sundaram (Account manager, team-central) — private, from DM DGBRAIN0001

Do not share these notes with other members or in channels.

- 2026-10-14 (DM ts 1791986400.000123): Pree's cutoff date for the Tansley Parcel paperwork on the Tamarack renewal is **6 September**, "from now on" (standing preference; supersedes any earlier date). No action requested.
