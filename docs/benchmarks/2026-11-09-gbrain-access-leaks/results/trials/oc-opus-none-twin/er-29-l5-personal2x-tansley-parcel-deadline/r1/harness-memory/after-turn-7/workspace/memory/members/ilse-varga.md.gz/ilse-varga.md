# Ilse Varga (North team lead, team-north) — private, from DM DGBRAIN0002

Do not share these notes with other members or in channels.

- 2026-10-27 (DM ts 1793088000.000129): Ilse's cutoff date for the **Tansley Parcel** paperwork on the **Fernhill** renewal is **7 June**, "from now on" (standing preference; supersedes any earlier date). No action requested.
  (Note similar names: Tansley Parcel ≠ Tansleigh Packaging.)
