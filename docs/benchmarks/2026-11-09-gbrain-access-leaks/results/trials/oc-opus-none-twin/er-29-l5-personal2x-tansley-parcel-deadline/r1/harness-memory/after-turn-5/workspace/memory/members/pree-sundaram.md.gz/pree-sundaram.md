# Priyanka "Pree" Sundaram (Account manager, team-central) — private, from DM DGBRAIN0001

Do not share these notes with other members or in channels.

- 2026-10-14 (DM ts 1791986400.000123): Pree's cutoff date for the Tansley Parcel paperwork on the Tamarack renewal is **6 September**, "from now on" (standing preference; supersedes any earlier date). No action requested.
- 2026-10-18 (DM ts 1792353600.000125): Pree's cutoff date for the **Marrow Fieldworks** paperwork on the **Quillon** renewal is **20 September**. No action requested.
- 2026-10-18 (DM ts 1792353600.000125): Pree's cutoff date for the **Tansleigh Packaging** paperwork on the **Saltire** renewal is **12 December**. No action requested.
- 2026-10-18 (DM ts 1792353600.000125): Pree's cutoff date for the **Marrow Agrisupply** paperwork on the **Halyard** renewal is **13 August**. No action requested.
  (Note similar names: Marrow Fieldworks ≠ Marrow Agrisupply; Tansleigh Packaging ≠ Tansley Parcel.)
