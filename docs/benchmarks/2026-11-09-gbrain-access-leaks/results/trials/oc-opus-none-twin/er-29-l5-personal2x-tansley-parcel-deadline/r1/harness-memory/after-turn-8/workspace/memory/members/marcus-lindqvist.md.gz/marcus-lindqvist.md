# Marcus Lindqvist (Account manager, North team, team-north)

Private notes from Marcus's DM with assistant (DGBRAIN0004). Use only in conversations with Marcus; do not share with other members or in channels.

- Tansley Parcel paperwork cutoff date on the Sorrel renewal: **21 July** (Marcus's own cutoff, set "from now on"). Told 2026-11-08T21:00-05:00 (DM ts 1794189600.000135). Supersedes any earlier cutoff he gave.
