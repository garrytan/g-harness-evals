# Hollis Mbeki (Central team lead, team-central) — private, from DM DGBRAIN0003

Do not share these notes with other members or in channels.

- 2026-11-04 (DM ts 1793822400.000133): Hollis's cutoff date for the **Tansley Parcel** paperwork on the **Hollybank** renewal is **21 October**, "from now on" (standing preference; supersedes any earlier date). No action requested.
  (Note similar names: Tansley Parcel ≠ Tansleigh Packaging.)
