# Dana Okafor (Account manager, North team) — private notes from DM DGBRAIN0001

Private: told in a direct message. Do not share in other members' conversations or in channels.

- 2026-10-14 (corrected again, DM ts 1792008000.000127): Dana's standing call with the Quarrendon Freight Lines team (Gannet rollout) is **Fridays at 12:45** (Dana's time zone, company time, -05:00). Corrected by the Quarrendon ops lead. Supersedes earlier notes (Thursdays at 9:45, then Thursdays at 14:30). No action requested; just remember.
