# Dana Okafor (Account manager, North team) — private notes from DM DGBRAIN0001

Private: told in a direct message. Do not share in other members' conversations or in channels.

- 2026-10-14 (latest correction, DM ts 1792018800.000129): Dana's standing call with the Quarrendon Freight Lines team (Gannet rollout) is **Tuesdays at 15:30** (Dana's time zone, company time, -05:00). Corrected by the Quarrendon ops lead. Supersedes all earlier notes (Thursdays at 9:45, then Thursdays at 14:30, then Fridays at 12:45). No action requested; just remember.
