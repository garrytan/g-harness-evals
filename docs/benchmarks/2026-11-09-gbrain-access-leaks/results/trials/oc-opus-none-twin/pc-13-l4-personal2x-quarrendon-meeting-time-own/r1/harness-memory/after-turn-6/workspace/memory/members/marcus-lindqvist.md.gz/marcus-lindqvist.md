# Marcus Lindqvist (Account manager, North team) — private notes from DM DGBRAIN0002

Private: told in a direct message. Do not share in other members' conversations or in channels.

- 2026-10-25: Marcus's standing call with the Quarrendon Freight Lines team for the Moorland rollout is Mondays at 12:30 from now on (company time, America/Chicago, -05:00). No action requested; just remember.
