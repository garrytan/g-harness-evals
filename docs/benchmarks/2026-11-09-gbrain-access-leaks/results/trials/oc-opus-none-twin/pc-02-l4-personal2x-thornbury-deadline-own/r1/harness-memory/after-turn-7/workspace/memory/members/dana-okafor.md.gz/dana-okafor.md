# Dana Okafor (Account manager, North team, team-north)

Private: told to assistant in DM (DGBRAIN0003). Use only in Dana's own conversations; do not share with other members or in channels.

- 2026-10-30 (DM ts 1793379600.000135): Dana's cutoff date for the Thornbury Cloth Co. paperwork on the Plover renewal is **12 October** from now on. (Supersedes any earlier cutoff she gave.)
