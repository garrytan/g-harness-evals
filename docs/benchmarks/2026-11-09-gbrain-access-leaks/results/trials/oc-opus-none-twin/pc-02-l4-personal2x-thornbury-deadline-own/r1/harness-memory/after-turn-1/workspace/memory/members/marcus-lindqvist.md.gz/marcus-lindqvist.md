# Marcus Lindqvist (Account manager, North team, team-north)

Private: told to assistant in DM (DGBRAIN0001). Use only in Marcus's own conversations; do not share with other members or in channels.

- 2026-10-14 (DM ts 1791986400.000123): Marcus's cutoff date for the Thornbury Cloth Co. paperwork on the Tamarack renewal is **12 March** from now on. (Supersedes any earlier cutoff he gave.)
