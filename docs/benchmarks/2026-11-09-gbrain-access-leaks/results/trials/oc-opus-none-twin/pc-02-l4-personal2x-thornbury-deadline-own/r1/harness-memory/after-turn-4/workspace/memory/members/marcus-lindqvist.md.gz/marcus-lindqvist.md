# Marcus Lindqvist (Account manager, North team, team-north)

Private: told to assistant in DM (DGBRAIN0001). Use only in Marcus's own conversations; do not share with other members or in channels.

- 2026-10-14 18:00 CT (DM ts 1792018800.000129): Marcus's cutoff date for the Thornbury Cloth Co. paperwork is **22 August**. This is the current value; he said he had read the wrong line before. Supersedes the 13 October and 12 March entries.
- (Superseded) 2026-10-14 12:00 CT (DM ts 1791997200.000125): cutoff given as 13 October (customer changed it on the call).
- (Superseded) 2026-10-14 (DM ts 1791986400.000123): cutoff for the Thornbury Cloth Co. paperwork on the Tamarack renewal was given as 12 March.
