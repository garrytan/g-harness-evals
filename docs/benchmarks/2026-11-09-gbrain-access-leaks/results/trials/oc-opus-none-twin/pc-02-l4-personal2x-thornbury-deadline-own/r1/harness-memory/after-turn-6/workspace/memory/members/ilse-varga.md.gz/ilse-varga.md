# Ilse Varga (North team lead, team-north): private notes

PRIVATE: told to the assistant in Ilse's DM (DGBRAIN0002). Use only in conversations with Ilse. Do not repeat in other members' conversations or in channels.

- Bramble renewal: Ilse's cutoff date for the Thornbury Cloth Co. paperwork is **27 December**. Effective from 2026-10-25, when she set it ("from now on"); replaces any earlier cutoff.
