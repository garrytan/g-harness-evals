# Marcus Lindqvist (Account manager, North team, team-north)

Private: told to assistant in DM (DGBRAIN0001). Use only in Marcus's own conversations; do not share with other members or in channels.

- 2026-10-14 12:00 CT (DM ts 1791997200.000125): Marcus's cutoff date for the Thornbury Cloth Co. paperwork is **13 October** (customer changed it on the call). This is the current value and supersedes the earlier 12 March entry.
- (Superseded) 2026-10-14 (DM ts 1791986400.000123): cutoff for the Thornbury Cloth Co. paperwork on the Tamarack renewal was given as 12 March.
