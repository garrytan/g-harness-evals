# Tobias Rendle — private notes (from his DMs; do not share with other members or in channels)

- **Current:** 2026-10-14 15:00 CT (DM DGBRAIN0001, ts 1792008000.000127): For Marrow Agrisupply pickups, Tobias uses **Gate 23**. He said he had read the wrong line before. This replaces the Dock 45 note below.
- ~~2026-10-14 12:00 CT (DM DGBRAIN0001, ts 1791997200.000125): For Marrow Agrisupply pickups, Tobias uses Dock 45 (per updated sheet from Finance).~~ Replaced by Gate 23 above.
- ~~2026-10-14 (DM DGBRAIN0001): For Marrow Agrisupply pickups on the Cobble project, Tobias uses Door 23 from now on.~~ Replaced, first by Dock 45 and then by Gate 23.
