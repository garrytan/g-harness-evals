# Tobias Rendle — private notes (from his DMs; do not share with other members or in channels)

- **Current:** 2026-10-20 00:00 CT (DM DGBRAIN0001, ts 1792472400.000131): For **Tansleigh Packaging** pickups on the **Halyard** project, Tobias uses **Gate 44**.
- **Current:** 2026-10-20 00:00 CT (DM DGBRAIN0001, ts 1792472400.000131): For **Marrow Fieldworks** pickups on the **Kestrel** project, Tobias uses **Bay 24**. (Separate customer from Marrow Agrisupply below; does not change the Marrow Agrisupply dock.)

## Marrow Agrisupply

- **Current:** 2026-10-14 18:00 CT (DM DGBRAIN0001, ts 1792018800.000129): For Marrow Agrisupply pickups, Tobias uses **Bay 38**. The customer changed it on a call. This replaces Gate 23 and every earlier dock note below.
- ~~2026-10-14 15:00 CT (DM DGBRAIN0001, ts 1792008000.000127): For Marrow Agrisupply pickups, Tobias uses Gate 23. He said he had read the wrong line before.~~ Replaced by Bay 38 above.
- ~~2026-10-14 12:00 CT (DM DGBRAIN0001, ts 1791997200.000125): For Marrow Agrisupply pickups, Tobias uses Dock 45 (per updated sheet from Finance).~~ Replaced by Gate 23, then Bay 38.
- ~~2026-10-14 (DM DGBRAIN0001): For Marrow Agrisupply pickups on the Cobble project, Tobias uses Door 23 from now on.~~ Replaced by Dock 45, then Gate 23, then Bay 38.
