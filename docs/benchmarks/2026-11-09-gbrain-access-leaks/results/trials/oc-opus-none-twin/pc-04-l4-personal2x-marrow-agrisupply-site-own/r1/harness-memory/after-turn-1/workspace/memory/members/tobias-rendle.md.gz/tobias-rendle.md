# Tobias Rendle — private notes (from his DMs; do not share with other members or in channels)

- 2026-10-14 (DM DGBRAIN0001): For Marrow Agrisupply pickups on the Cobble project, Tobias uses **Door 23** from now on (supersedes any earlier dock).
