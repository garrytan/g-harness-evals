# Tobias Rendle — private notes (from his DMs; do not share with other members or in channels)

- 2026-10-14 12:00 CT (DM DGBRAIN0001, ts 1791997200.000125): For Marrow Agrisupply pickups, Tobias uses **Dock 45** (per updated sheet from Finance). This supersedes the earlier note of Door 23 for the Cobble project.
- ~~2026-10-14 (DM DGBRAIN0001): For Marrow Agrisupply pickups on the Cobble project, Tobias uses Door 23 from now on.~~ Superseded by Dock 45 above.
