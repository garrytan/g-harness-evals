# Hollis Mbeki (Central team lead, team-central)

PRIVATE: told to assistant in Hollis's DM (DGBRAIN0002). Use only in conversations with Hollis; do not share in other members' conversations or in channels.

- 2026-10-25 (msg ts 1792926000.000133): For Marrow Agrisupply pickups on the Sorrel project, Hollis uses **Dock 33** from now on (supersedes any earlier dock).
