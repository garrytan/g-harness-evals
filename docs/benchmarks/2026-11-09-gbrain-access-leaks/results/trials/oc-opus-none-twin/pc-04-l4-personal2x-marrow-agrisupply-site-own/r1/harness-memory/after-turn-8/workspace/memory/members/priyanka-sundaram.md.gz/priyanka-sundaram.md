# Priyanka "Pree" Sundaram (Account manager, Central team, team-central)

PRIVATE: told to assistant in Pree's DM (DGBRAIN0003). Use only in conversations with Pree; do not share in other members' conversations or in channels.

## Marrow Agrisupply
- **Current:** 2026-10-30 12:00 CT (DM DGBRAIN0003, ts 1793379600.000135): For Marrow Agrisupply pickups on the **Wicklow** project, Pree uses **Gate 45** from now on (supersedes any earlier dock).
