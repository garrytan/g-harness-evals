# Hollis Mbeki (Central team lead, team-central) — private preferences

Source: Hollis's DM with assistant (DGBRAIN0001), ts 1791986400.000123, 2026-10-14.
Visibility: told to assistant in a private DM. Use only when helping Hollis; do not share with other members or post in channels.

- Marrow Agrisupply pickups on the Larchmont project: Hollis uses **Door 29** (effective 2026-10-14, "from now on"; supersedes any earlier door).

Source: Hollis's DM with assistant (DGBRAIN0001), ts 1792440000.000125, 2026-10-19. Same visibility (private, Hollis only).

- Tansleigh Packaging pickups on the Ashgrove project: Hollis uses **Door 17**.
- Marrow Fieldworks pickups on the Cinder project: Hollis uses **Dock 48**. (Note: Marrow Fieldworks/Cinder is distinct from Marrow Agrisupply/Larchmont above.)
