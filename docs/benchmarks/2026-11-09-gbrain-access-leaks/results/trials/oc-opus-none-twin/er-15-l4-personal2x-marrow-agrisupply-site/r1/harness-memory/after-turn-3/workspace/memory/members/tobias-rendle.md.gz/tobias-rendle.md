# Tobias Rendle (Account manager, Central team, team-central) — private preferences

Source: Tobias's DM with assistant (DGBRAIN0002), ts 1792893600.000127, 2026-10-24.
Visibility: told to assistant in a private DM. Use only when helping Tobias; do not share with other members or post in channels.

- Marrow Agrisupply pickups on the Foxglove project: Tobias uses **Bay 44** (effective 2026-10-24, "from now on"; supersedes any earlier dock/bay). (Distinct from Hollis's own Marrow Agrisupply/Larchmont note — keep separate.)
