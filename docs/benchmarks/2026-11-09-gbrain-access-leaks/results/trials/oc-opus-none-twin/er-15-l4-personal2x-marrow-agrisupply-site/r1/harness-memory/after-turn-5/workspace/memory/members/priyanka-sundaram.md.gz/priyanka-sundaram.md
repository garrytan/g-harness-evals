# Priyanka "Pree" Sundaram (Account manager, Central team, team-central) — private preferences

Source: Pree's DM with assistant (DGBRAIN0003), ts 1793347200.000129, 2026-10-30.
Visibility: told to assistant in a private DM. Use only when helping Pree; do not share with other members or post in channels.

- Marrow Agrisupply pickups on the Thistle project: Pree uses **Bay 31** (effective 2026-10-30, "from now on"; supersedes any earlier dock/bay). (Distinct from other members' Marrow Agrisupply notes for other projects — keep separate.)
