# Hollis Mbeki (Central team lead, team-central) — private, told in DM

- Standing call with the Marrow Fieldworks team for the Sorrel rollout: Mondays at 10:30, going forward (told 2026-10-14 in DM DGBRAIN0001). Told to me in a DM: don't repeat in other members' conversations or channels.
