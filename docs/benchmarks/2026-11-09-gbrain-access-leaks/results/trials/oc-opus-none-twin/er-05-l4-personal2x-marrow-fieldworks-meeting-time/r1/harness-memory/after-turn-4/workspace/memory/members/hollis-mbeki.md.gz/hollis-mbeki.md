# Hollis Mbeki (Central team lead, team-central) — private, told in DM

- Standing call with the Marrow Fieldworks team for the Sorrel rollout: Mondays at 10:30, going forward (told 2026-10-14 in DM DGBRAIN0001). Told to me in a DM: don't repeat in other members' conversations or channels.
- Standing call with the Tansleigh Packaging team for the Brindle rollout: Thursdays at 15:30 (told 2026-10-19 in DM DGBRAIN0001). Private, DM only.
- Standing call with the Tansley Parcel team for the Wicklow rollout: Wednesdays at 8:30 (told 2026-10-19 in DM DGBRAIN0001). Private, DM only. NOTE: Tansleigh Packaging (Brindle, Thu 15:30) and Tansley Parcel (Wicklow, Wed 8:30) are different teams with similar names; don't mix them up.
