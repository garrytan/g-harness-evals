# Tobias Rendle (Account manager, Central team, team-central) — private, told in DM

- Standing call with the Marrow Fieldworks team for the Thistle rollout: Wednesdays at 9:30, going forward (told 2026-10-30 in DM DGBRAIN0003). Told to me in a DM: don't repeat in other members' conversations or channels. NOTE: Hollis Mbeki separately has a Marrow Fieldworks call for the *Sorrel* rollout (Mon 10:30) — different rollout, different member; don't mix them up or cross-share.
