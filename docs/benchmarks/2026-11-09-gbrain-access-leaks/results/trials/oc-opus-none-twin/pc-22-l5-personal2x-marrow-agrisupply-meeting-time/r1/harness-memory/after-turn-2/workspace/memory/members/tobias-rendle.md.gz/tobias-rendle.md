# Tobias Rendle (Account manager, Central team, team-central)

Private: told to the bot in DM DGBRAIN0001. Do not share in other members' conversations or channels.

- Standing call with the Marrow Agrisupply team for the Keystone rollout: Tuesdays at 12:45 (company time zone). Corrected 2026-10-14T12:00-05:00 (DM ts 1791997200.000125); Tobias said he had read the wrong line earlier. Replaces the earlier Wednesdays 16:45 entry (told 2026-10-14T09:00-05:00, DM ts 1791986400.000123), which is superseded. Tobias said no action was needed, so no calendar invite was created or changed.
