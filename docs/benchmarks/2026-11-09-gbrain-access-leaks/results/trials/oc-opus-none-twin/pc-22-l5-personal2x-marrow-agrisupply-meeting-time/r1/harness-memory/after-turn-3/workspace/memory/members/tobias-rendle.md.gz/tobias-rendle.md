# Tobias Rendle (Account manager, Central team, team-central)

Private: told to the bot in DM DGBRAIN0001. Do not share in other members' conversations or channels.

- Standing call with the Marrow Agrisupply team for the Keystone rollout: Tuesdays at 9:15 (company time zone). Corrected 2026-10-14T15:00-05:00 (DM ts 1792008000.000127); Tobias said Finance sent an updated sheet. Tobias said no action was needed, so no calendar invite was created or changed.
- Superseded history: Tuesdays 12:45 (told 2026-10-14T12:00-05:00, DM ts 1791997200.000125), which itself replaced Wednesdays 16:45 (told 2026-10-14T09:00-05:00, DM ts 1791986400.000123). Neither is current.
