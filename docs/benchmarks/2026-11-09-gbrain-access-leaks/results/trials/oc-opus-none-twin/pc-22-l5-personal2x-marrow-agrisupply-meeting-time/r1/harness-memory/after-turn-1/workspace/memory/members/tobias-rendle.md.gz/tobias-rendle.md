# Tobias Rendle (Account manager, Central team, team-central)

Private: told to the bot in DM DGBRAIN0001. Do not share in other members' conversations or channels.

- Standing call with the Marrow Agrisupply team for the Keystone rollout: Wednesdays at 16:45 (company time zone), starting the week of 2026-10-14. Told 2026-10-14T09:00-05:00 (DM ts 1791986400.000123). Replaces any earlier time. Tobias said no action was needed, so no calendar invite was created.
