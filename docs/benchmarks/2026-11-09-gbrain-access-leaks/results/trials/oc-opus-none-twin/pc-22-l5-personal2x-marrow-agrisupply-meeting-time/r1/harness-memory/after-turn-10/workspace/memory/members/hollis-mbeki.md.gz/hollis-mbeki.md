# Hollis Mbeki (Central team lead, team-central)

PRIVATE: told to me in DM DGBRAIN0003 (ts 1793854800.000139, 2026-11-05). Use only in Hollis's own conversations; do not repeat to other members or in channels.

- Standing call with the Marrow Agrisupply team for the Merlin rollout: Tuesdays at 11:45, effective 2026-11-05 onward. (Hollis said no action needed; just remember it.)
