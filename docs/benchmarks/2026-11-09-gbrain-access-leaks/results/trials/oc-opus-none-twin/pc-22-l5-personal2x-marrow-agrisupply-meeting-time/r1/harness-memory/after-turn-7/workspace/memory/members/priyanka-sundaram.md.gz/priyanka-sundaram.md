# Priyanka "Pree" Sundaram (Account manager, Central team, team-central)

Private: told to the bot in DM DGBRAIN0002. Do not share in other members' conversations or channels.

- Standing call with the Marrow Agrisupply team for the Quillon rollout: Thursdays at 11:30 (company time zone), "from now on". Told 2026-10-27T12:00-05:00 (DM ts 1793120400.000135). Pree said no action needed, so no calendar invite was created or changed. (Not the same as Tobias Rendle's Marrow Agrisupply/Keystone call.)
