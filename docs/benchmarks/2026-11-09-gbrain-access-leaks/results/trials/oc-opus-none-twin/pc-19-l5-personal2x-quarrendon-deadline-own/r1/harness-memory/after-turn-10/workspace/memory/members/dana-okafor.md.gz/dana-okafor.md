# Dana Okafor (Account manager, North team, team-north) — private notes

Told to assistant in DM (DGBRAIN0001). Private to Dana: do not share in other members' conversations or in channels.

- 2026-10-14 18:00 (sim time, DM ts 1792018800.000129): Dana's cutoff date for the Quarrendon Freight Lines paperwork (Nettle renewal) is **26 March**. Customer changed it on the call. This is the current date; it supersedes all earlier dates below.
- Superseded — do not use: 7 May (noted 2026-10-14 15:00); 10 August (noted 2026-10-14 12:00, from Quarrendon's ops lead); 13 May (earliest).
- 2026-10-19 00:00 (sim time, DM ts 1792386000.000131): Dana's cutoff dates, as told by Dana:
  - Brackenwater Freight Co. paperwork (Cobble renewal): **5 November**
  - Thornbury Cloth Co. paperwork (Fernhill renewal): **12 October**
  - Tamsin Cold Chain paperwork (Halyard renewal): **4 June**
