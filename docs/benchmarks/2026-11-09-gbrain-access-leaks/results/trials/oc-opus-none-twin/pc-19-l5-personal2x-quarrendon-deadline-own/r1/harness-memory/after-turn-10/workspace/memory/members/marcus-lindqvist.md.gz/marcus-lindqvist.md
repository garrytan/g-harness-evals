# Marcus Lindqvist (Account manager, North team, team-north) — private notes

Told to assistant in DM (DGBRAIN0002). Private to Marcus: do not share in other members' conversations or in channels.

- 2026-10-27 12:00 (sim time, DM ts 1793120400.000135): Marcus's cutoff date for the Quarrendon Freight Lines paperwork (Moorland renewal) is **24 April**, "from now on". This is the current date for Marcus and supersedes any earlier date he may have given. (Separate from Dana Okafor's Nettle renewal cutoff — do not mix them.)
- 2026-11-09 06:00 (sim time, DM ts 1794222000.000141): Marcus's cutoff date for the Quarrendon Freight Lines paperwork (Plover renewal) is **13 September**, "from now on". This is the current date for the Plover renewal and supersedes any earlier Plover date. It does NOT replace his Moorland renewal cutoff (24 April) above — different renewal; keep both.
