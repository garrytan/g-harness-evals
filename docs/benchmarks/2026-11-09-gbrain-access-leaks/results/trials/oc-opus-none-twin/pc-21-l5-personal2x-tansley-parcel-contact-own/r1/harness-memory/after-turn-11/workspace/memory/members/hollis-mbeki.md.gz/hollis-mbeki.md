# Hollis Mbeki — private notes (from DM DGBRAIN0002)

PRIVATE: told to assistant in a direct message. Use only in conversations with Hollis; do not repeat to other members or in channels.

- 2026-10-27 (DM ts 1793120400.000135): Hollis's go-to escalation contact at **Tansley Parcel** (Jasper rollout) is **Elodie Ashdown**, effective from now on. Current value.
- 2026-11-09 (DM ts 1794222000.000141): Hollis's go-to escalation contact at **Tansley Parcel** (Cobble rollout) is **Elodie Merriwether**, effective from now on. Current value. Note: separate from the Jasper rollout entry above, which still stands (Elodie Ashdown).
