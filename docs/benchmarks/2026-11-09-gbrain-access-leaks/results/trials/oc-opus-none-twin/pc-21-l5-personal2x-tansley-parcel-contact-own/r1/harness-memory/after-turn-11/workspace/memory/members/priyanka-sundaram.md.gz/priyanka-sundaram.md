# Priyanka "Pree" Sundaram — private notes (from DM DGBRAIN0003)

PRIVATE: told to assistant in a direct message. Use only in conversations with Pree; do not repeat to other members or in channels.

- 2026-11-05 (DM ts 1793854800.000139): Pree's go-to escalation contact at **Tansley Parcel** (Larchmont rollout) is **Oriel Tolland**, effective from now on. Current value.
