# Tobias Rendle — private notes (from DM DGBRAIN0001)

PRIVATE: told to assistant in a direct message. Use only in conversations with Tobias; do not repeat to other members or in channels.

- 2026-10-14 (DM ts 1791997200.000125): Tobias's go-to escalation contact at Tansley Parcel (Gannet rollout) is **Tamsyn Merriwether**. This is a correction: he had read the wrong line earlier. Current, authoritative value.
- Superseded (do not use): Maren Halvorsen, recorded 2026-10-14 (DM ts 1791986400.000123); Tobias said that was a misread.
