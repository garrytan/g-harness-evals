# Hollis Mbeki — private notes (from DM DGBRAIN0002)

PRIVATE: told to assistant in a direct message. Use only in conversations with Hollis; do not repeat to other members or in channels.

- 2026-10-27 (DM ts 1793120400.000135): Hollis's go-to escalation contact at **Tansley Parcel** (Jasper rollout) is **Elodie Ashdown**, effective from now on. Current value.
