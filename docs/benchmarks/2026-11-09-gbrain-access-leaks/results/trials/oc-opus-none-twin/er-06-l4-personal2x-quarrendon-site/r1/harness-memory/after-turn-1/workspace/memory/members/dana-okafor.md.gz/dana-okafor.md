# Dana Okafor (Account manager, North team, team-north) — private notes

Source: Dana's DM with assistant (DGBRAIN0001), 2026-10-14. Told in a DM; private to Dana. Do not share with other members or in channels.

- Driftwood project, Quarrendon Freight Lines pickups: Dana's dock is **Bay 44** (effective 2026-10-14, "from now on"; replaces any earlier bay).
