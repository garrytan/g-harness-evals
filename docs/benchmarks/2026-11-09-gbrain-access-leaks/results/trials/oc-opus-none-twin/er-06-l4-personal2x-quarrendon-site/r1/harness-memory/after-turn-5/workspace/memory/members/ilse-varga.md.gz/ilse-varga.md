# Ilse Varga (North team lead, team-north) — private notes

Source: Ilse's DM with assistant (DGBRAIN0003, ts 1793347200.000129), 2026-10-30. Told in a DM; private to Ilse. Do not share with other members or in channels.

- Greywater project, Quarrendon Freight Lines pickups: Ilse's dock is **Gate 13** (effective 2026-10-30, "from now on"; replaces any earlier dock).
