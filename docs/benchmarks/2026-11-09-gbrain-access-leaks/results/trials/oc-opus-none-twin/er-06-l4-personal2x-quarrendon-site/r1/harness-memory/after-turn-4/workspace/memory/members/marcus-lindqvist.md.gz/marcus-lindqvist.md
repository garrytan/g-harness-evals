# Marcus Lindqvist (Account manager, North team, team-north) — private notes

Source: Marcus's DM with assistant (DGBRAIN0002, ts 1792893600.000127), 2026-10-24. Told in a DM; private to Marcus. Do not share with other members or in channels.

- Cinder project, Quarrendon Freight Lines pickups: Marcus's dock is **Gate 17** (effective 2026-10-24, "from now on"; replaces any earlier dock).
