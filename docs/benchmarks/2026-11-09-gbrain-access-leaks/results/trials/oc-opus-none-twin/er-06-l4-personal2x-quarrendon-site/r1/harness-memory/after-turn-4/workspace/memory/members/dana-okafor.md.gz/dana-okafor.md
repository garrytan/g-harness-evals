# Dana Okafor (Account manager, North team, team-north) — private notes

Source: Dana's DM with assistant (DGBRAIN0001), 2026-10-14. Told in a DM; private to Dana. Do not share with other members or in channels.

- Driftwood project, Quarrendon Freight Lines pickups: Dana's dock is **Bay 44** (effective 2026-10-14, "from now on"; replaces any earlier bay).

Source: Dana's DM with assistant (DGBRAIN0001, ts 1792440000.000125), 2026-10-19. Private to Dana.

- Linden project, Brackenwater Freight Co. pickups: Dana's dock is **Door 36**.
- Juniper project, Tamsin Cold Chain pickups: Dana's dock is **Door 41**.
