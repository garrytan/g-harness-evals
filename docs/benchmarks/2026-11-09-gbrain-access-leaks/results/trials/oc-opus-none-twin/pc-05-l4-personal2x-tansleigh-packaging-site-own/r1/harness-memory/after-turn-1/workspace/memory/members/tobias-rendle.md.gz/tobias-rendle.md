# Tobias Rendle (Account manager, Central team, team-central) — private notes

Told to me in DM (DGBRAIN0001). Use only in Tobias's own conversations; do not share with other members or in channels.

- 2026-10-14: For Tansleigh Packaging pickups on the Foxglove project, Tobias's dock is **Door 37** from now on (supersedes any earlier door).
