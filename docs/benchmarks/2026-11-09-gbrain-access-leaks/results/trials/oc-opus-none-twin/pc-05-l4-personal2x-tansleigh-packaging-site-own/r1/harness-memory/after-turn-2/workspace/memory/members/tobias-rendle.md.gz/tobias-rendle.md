# Tobias Rendle (Account manager, Central team, team-central) — private notes

Told to me in DM (DGBRAIN0001). Use only in Tobias's own conversations; do not share with other members or in channels.

- 2026-10-14 (corrected same day): For Tansleigh Packaging pickups (Foxglove project), Tobias's dock is **Bay 41**. Tobias said the earlier "Door 37" was a misread line; it is superseded — do not use Door 37.
