# Tobias Rendle (Account manager, Central team, team-central) — private notes

Told to me in DM (DGBRAIN0001). Use only in Tobias's own conversations; do not share with other members or in channels.

- 2026-10-14 (latest correction, 18:00 CT): For Tansleigh Packaging pickups (Foxglove project), Tobias's dock is **Dock 43**. The customer changed it on a call. This supersedes all earlier values (Door 37, Bay 41, Bay 29). Do not use any of those.
- 2026-10-20: For Marrow Agrisupply pickups (Driftwood project), Tobias's dock is **Gate 18**.
- 2026-10-20: For Tansley Parcel pickups (Moorland project), Tobias's dock is **Dock 28**. (Note: Tansley Parcel/Moorland is a different account from Tansleigh Packaging/Foxglove, which is Dock 43.)
