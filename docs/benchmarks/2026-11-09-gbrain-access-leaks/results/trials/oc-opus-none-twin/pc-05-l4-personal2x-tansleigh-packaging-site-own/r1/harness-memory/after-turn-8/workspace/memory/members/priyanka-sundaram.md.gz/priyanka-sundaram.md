# Priyanka "Pree" Sundaram (Account manager, Central team, team-central) — private notes

Told to me in DM (DGBRAIN0003). Use only in Pree's own conversations; do not share with other members or in channels.

- 2026-10-30: For Tansleigh Packaging pickups on the Osprey project, Pree's dock is **Gate 27** from now on (supersedes any earlier value).
