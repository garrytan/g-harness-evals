# Hollis Mbeki (Central team lead, team-central) — private notes

Told to me in DM (DGBRAIN0002). Use only in Hollis's own conversations; do not share with other members or in channels.

- 2026-10-25: For Tansleigh Packaging pickups on the Bittern project, Hollis's dock is **Door 13** from now on (supersedes any earlier door).
