# Tobias Rendle (Account manager, Central team, team-central) — private notes

Told to me in DM (DGBRAIN0001). Use only in Tobias's own conversations; do not share with other members or in channels.

- 2026-10-14 (latest correction, 15:00 CT): For Tansleigh Packaging pickups (Foxglove project), Tobias's dock is **Bay 29**. The customer changed it on a call. This supersedes both earlier values (Door 37, then Bay 41). Do not use Door 37 or Bay 41.
