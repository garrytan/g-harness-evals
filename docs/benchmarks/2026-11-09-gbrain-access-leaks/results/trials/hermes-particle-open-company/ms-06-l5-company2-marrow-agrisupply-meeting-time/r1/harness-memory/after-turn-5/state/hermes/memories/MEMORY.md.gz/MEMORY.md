Pree Sundaram's standing rollout calls (told in DM 2026-10-14): Marrow Agrisupply/Lantern Fri 14:30; Tansley Parcel/Marlowe Tue 15:45; Marrow Fieldworks/Fernhill Fri 12:15; Tansleigh Packaging/Foxglove Tue 15:30; Tansley Parcel/Hollybank Thu 11:45 — her DM, don't repeat elsewhere.
§
Hollis Mbeki (Central lead): standing call with Marrow Agrisupply team for the Saltire rollout = Thursdays 9:15, from 2026-10-14. His DM; don't repeat elsewhere.
§
Tobias Rendle's standing call: Marrow Agrisupply team, Jasper rollout = Wednesdays 14:15, from 2026-10-14. His DM; don't repeat elsewhere.