Ilse Varga's go-to escalation contacts (from her DM 2026-10-14): Thornbury Cloth Co. / Linden = Linnea Varno; Quarrendon Freight Lines / Cobble = Maren Tolland; Tamsin Cold Chain / Bramble = Oriel Castellane; Brackenwater Freight Co. / Gannet = Elodie Quillan; Quarrendon Freight Lines / Elmstead = Oriel Varno. Private to Ilse — do not share in channels.
§
Marcus Lindqvist's go-to escalation contact at Thornbury Cloth Co. for the Marlowe rollout is Soren Merriwether (told in DM 2026-10-14). Private to Marcus — do not share in channels.
§
Dana Okafor's go-to escalation contact at Thornbury Cloth Co. for the Quillon rollout is Idris Varno (told in DM 2026-10-14, effective from then on). Private to Dana — do not share in channels.