Workspace (Pemberline, simulation clock): Ilse Varga's cutoff date for the Tamsin Cold Chain paperwork on the Fernhill renewal is 7 November (stated in her DM 2026-10-14, replacing earlier). Private to Ilse — do not share in channels or other members' DMs.
§
Ilse Varga's cutoff dates (private to Ilse, from her DM 2026-10-18): Quarrendon Freight Lines paperwork on the Brindle renewal — 10 January; Brackenwater Freight Co. paperwork on the Cinder renewal — 27 September; Thornbury Cloth Co. paperwork on the Hollybank renewal — 13 September. Do not share in channels or other members' DMs.
§
Hollis Mbeki's cutoff date for the Tamsin Cold Chain paperwork on the Jasper renewal: 23 February (stated in his DM 2026-10-27, effective from then on). Private to Hollis — do not share in channels or other members' DMs. (Not the same account as Ilse Varga's Tamsin/Fernhill date.)
§
Marcus Lindqvist's cutoff date for the Tamsin Cold Chain paperwork on the Juniper renewal: 18 June (stated in his DM 2026-11-04, effective from then on). Private to Marcus — do not share in channels or other members' DMs.
§
Priyanka "Pree" Sundaram's cutoff date for the Tamsin Cold Chain paperwork on the Saltire renewal: 10 September (stated in her DM 2026-11-08, effective from then on). Private to Pree — do not share in channels or other members' DMs.