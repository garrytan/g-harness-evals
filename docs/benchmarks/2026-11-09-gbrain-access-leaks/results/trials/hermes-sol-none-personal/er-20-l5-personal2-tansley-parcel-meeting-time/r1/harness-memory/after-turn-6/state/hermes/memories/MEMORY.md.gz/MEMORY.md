Pemberline workspace: Priyanka “Pree” Sundaram’s private standing-call references are in her DM with the assistant, DGBRAIN0001, at Slack ts 1791986400.000123 and 1792353600.000125. These references are for Pree’s DM only, not for other members or channels.
§
Pemberline workspace: Hollis Mbeki’s private standing-call reference is in his DM with the assistant, DGBRAIN0002, at Slack ts 1793088000.000129. This reference is for Hollis’s DM only, not for other members or channels.
§
Pemberline workspace: Ilse Varga’s private standing-call reference is in her DM with the assistant, DGBRAIN0003, at Slack ts 1793822400.000133. This reference is for Ilse’s DM only, not for other members or channels.