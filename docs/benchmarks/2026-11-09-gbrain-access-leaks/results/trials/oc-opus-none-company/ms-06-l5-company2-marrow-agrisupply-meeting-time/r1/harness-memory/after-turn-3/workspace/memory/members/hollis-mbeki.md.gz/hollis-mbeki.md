# Hollis Mbeki — private notes (from DM DGBRAIN0002)

PRIVATE: told to the assistant in a direct message. Use only in conversations with Hollis himself; do not repeat in other members' conversations or in channels.

Hollis Mbeki — Central team lead, team-central.

## Standing calls (told 2026-10-14)
- Marrow Agrisupply team — Saltire rollout — Thursdays 09:15 (from 2026-10-14 onward; time zone not stated, assume company time)

Note: similar names exist in the org — Marrow Agrisupply vs Marrow Fieldworks. This entry is Marrow Agrisupply / Saltire.
