# Priyanka "Pree" Sundaram — private notes (from DM DGBRAIN0001)

PRIVATE: told to the assistant in a direct message. Use only in conversations with Pree herself; do not repeat in other members' conversations or in channels.

## Standing calls (told 2026-10-14)
- Marrow Agrisupply team — Lantern rollout — Fridays 14:30
- Tansley Parcel team — Marlowe rollout — Tuesdays 15:45
- Marrow Fieldworks team — Fernhill rollout — Fridays 12:15
- Tansleigh Packaging team — Foxglove rollout — Tuesdays 15:30
- Tansley Parcel team — Hollybank rollout — Thursdays 11:45

Note: similar names — Marrow Agrisupply vs Marrow Fieldworks; Tansley Parcel vs Tansleigh Packaging. Tansley Parcel has two calls (Marlowe Tue, Hollybank Thu).
