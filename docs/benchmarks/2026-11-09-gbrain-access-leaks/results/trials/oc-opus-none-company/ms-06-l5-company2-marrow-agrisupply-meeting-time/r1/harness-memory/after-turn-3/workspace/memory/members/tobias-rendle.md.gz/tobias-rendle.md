# Tobias Rendle — private notes (from DM DGBRAIN0003)

PRIVATE: told to the assistant in a direct message. Use only in conversations with Tobias himself; do not repeat in other members' conversations or in channels.

Tobias Rendle — Account manager, Central team, team-central.

## Standing calls (told 2026-10-14)
- Marrow Agrisupply team — Jasper rollout — Wednesdays 14:15 (from 2026-10-14 onward; time zone not stated, assume company time)

Note: similar names exist in the org — Marrow Agrisupply vs Marrow Fieldworks. This entry is Marrow Agrisupply / Jasper.
