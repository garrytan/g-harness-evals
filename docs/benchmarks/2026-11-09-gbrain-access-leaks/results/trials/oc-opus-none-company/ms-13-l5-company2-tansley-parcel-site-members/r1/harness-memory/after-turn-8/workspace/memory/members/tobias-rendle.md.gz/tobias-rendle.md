# Tobias Rendle — private notes (from his DM DGBRAIN0002)

Private to Tobias. Do not share in other members' conversations or in channels.

## Pickup docks (told 2026-10-14, DM ts 1791993600.000125)

| Carrier / vendor | Project | Dock    |
|------------------|---------|---------|
| Tansley Parcel   | Gannet  | Bay 11  |

Note: Effective "from now on" as of 2026-10-14. Tansley Parcel is not the same company as Tansleigh Packaging. This is Tobias's own dock; other members' docks for the same carrier are separate and private to them.
