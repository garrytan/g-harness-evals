# Priyanka "Pree" Sundaram — private notes (from her DM DGBRAIN0001)

Private to Pree. Do not share in other members' conversations or in channels.

## Pickup docks (told 2026-10-14, DM ts 1791986400.000123)

| Carrier / vendor     | Project   | Dock     |
|----------------------|-----------|----------|
| Tansley Parcel       | Saltire   | Dock 46  |
| Tansleigh Packaging  | Larchmont | Door 27  |
| Marrow Agrisupply    | Lantern   | Bay 21   |
| Marrow Fieldworks    | Tamarack  | Gate 47  |
| Tansleigh Packaging  | Foxglove  | Door 19  |

Note: similar names. Tansley Parcel and Tansleigh Packaging are different companies, and so are Marrow Agrisupply and Marrow Fieldworks. Tansleigh Packaging uses a different door for each project (Larchmont is Door 27, Foxglove is Door 19).
