# Hollis Mbeki — private notes (from his DM DGBRAIN0003)

Private to Hollis. Do not share in other members' conversations or in channels.

## Pickup docks (told 2026-10-14, DM ts 1792000800.000127)

| Carrier / vendor | Project   | Dock    |
|------------------|-----------|---------|
| Tansley Parcel   | Kittiwake | Gate 11 |

Note: Effective "from now on" as of 2026-10-14. Tansley Parcel is not the same company as Tansleigh Packaging. This is Hollis's own dock; other members' docks for the same carrier are separate and private to them.
