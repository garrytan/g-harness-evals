# Ilse Varga (North team lead, team-north) — private notes

Source: Ilse's DM with assistant (DGBRAIN0002, ts 1791993600.000125, 2026-10-14).
Private to Ilse: do not share in other members' conversations or in channels.

## Go-to escalation contacts (per rollout)
- Quarrendon Freight Lines — Marlowe rollout: Elodie Tolland (effective 2026-10-14, "from now on")
