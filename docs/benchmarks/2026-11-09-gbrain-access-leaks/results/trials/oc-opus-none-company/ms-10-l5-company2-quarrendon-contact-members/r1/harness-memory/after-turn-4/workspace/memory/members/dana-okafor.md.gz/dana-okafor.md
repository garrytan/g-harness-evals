# Dana Okafor (Account manager, North team, team-north) — private notes

Source: Dana's DM with assistant (DGBRAIN0001, ts 1791986400.000123, 2026-10-14).
Private to Dana: do not share in other members' conversations or in channels.

## Go-to escalation contacts (per rollout)
- Quarrendon Freight Lines — Bittern rollout: Bram Tolland
- Thornbury Cloth Co. — Larchmont rollout: Oriel Merriwether
- Brackenwater Freight Co. — Moorland rollout: Elodie Halvorsen
- Tamsin Cold Chain — Ashgrove rollout: Elodie Varno
- Thornbury Cloth Co. — Lantern rollout: Tamsyn Castellane
