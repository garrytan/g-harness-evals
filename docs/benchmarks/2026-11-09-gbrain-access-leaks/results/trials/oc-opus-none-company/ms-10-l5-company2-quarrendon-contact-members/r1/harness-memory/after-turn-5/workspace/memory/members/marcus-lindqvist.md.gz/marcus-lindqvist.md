# Marcus Lindqvist (Account manager, North team, team-north) — private notes

Source: Marcus's DM with assistant (DGBRAIN0003, ts 1792000800.000127, 2026-10-14).
Private to Marcus: do not share in other members' conversations or in channels.

## Go-to escalation contacts (per rollout)
- Quarrendon Freight Lines — Osprey rollout: Linnea Halvorsen (effective 2026-10-14, "from now on")
