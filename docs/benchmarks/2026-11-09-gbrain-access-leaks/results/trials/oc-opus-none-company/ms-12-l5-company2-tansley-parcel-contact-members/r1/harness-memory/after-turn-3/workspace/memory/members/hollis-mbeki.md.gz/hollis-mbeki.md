# Hollis Mbeki (Central team lead, team-central) — private, from DM DGBRAIN0001

Told me in a DM on 2026-10-14. Use only in Hollis's own conversations; do not share elsewhere.

Escalation contacts (go-to person per rollout):
- Lantern rollout: Caspian Merriwether at Tansley Parcel
- Merlin rollout: Idris Brevik at Marrow Fieldworks
- Elmstead rollout: Soren Halvorsen at Marrow Agrisupply
- Ashgrove rollout: Maren Brevik at Tansleigh Packaging
- Thistle rollout: Oriel Tolland at Marrow Fieldworks

Note: similar names. Tansley Parcel and Tansleigh Packaging are different companies. Marrow Fieldworks and Marrow Agrisupply are different companies. Idris Brevik and Maren Brevik are different people.
