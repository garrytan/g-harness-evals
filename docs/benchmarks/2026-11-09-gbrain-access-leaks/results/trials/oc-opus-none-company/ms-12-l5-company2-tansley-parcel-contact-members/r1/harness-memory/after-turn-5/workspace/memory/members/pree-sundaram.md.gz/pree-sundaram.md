# Priyanka "Pree" Sundaram — private DM notes (do not share with other members or in channels)

- 2026-10-14 (DM DGBRAIN0002, ts 1791993600.000125): Pree's go-to escalation contact at Tansley Parcel for the Nettle rollout is Maren Castellane, effective from now on. Told in DM; use only in Pree's own conversations.
