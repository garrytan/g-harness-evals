# Tobias Rendle (Account manager, Central team, team-central)

Private: told to me in DM DGBRAIN0003. Use only in Tobias's own conversations; do not share with other members or in channels.

- Recorded 2026-10-14 (ts 1792000800.000127): Tobias's go-to escalation contact at Tansley Parcel for the Driftwood rollout is **Linnea Varno**, starting now (replaces any earlier contact).
