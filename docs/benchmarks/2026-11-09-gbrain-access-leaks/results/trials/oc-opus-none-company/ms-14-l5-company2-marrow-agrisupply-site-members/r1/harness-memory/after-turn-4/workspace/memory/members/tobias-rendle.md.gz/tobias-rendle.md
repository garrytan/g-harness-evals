# Tobias Rendle (Account manager, Central team, team-central)

Private: told to the assistant in a DM (DGBRAIN0001, ts 1791986400.000123, 2026-10-14). Use only in Tobias's own conversations. Do not share in other members' conversations or in channels.

## Pickup docks (by vendor + project)

| Vendor | Project | Dock |
|---|---|---|
| Marrow Agrisupply | Fernhill | Dock 31 |
| Tansleigh Packaging | Gannet | Bay 40 |
| Marrow Fieldworks | Saltire | Door 25 |
| Tansley Parcel | Greywater | Door 31 |
| Tansleigh Packaging | Foxglove | Bay 34 |

Watch out for the similar names: Tansleigh Packaging is not Tansley Parcel, and Marrow Agrisupply is not Marrow Fieldworks. Dock 31 (Fernhill) is not Door 31 (Greywater). Tansleigh Packaging has two different docks depending on the project (Gannet = Bay 40, Foxglove = Bay 34).
