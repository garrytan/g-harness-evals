# Hollis Mbeki (Central team lead, team-central)

Private: told to the assistant in a DM (DGBRAIN0002, ts 1791993600.000125, 2026-10-14). Use only in Hollis's own conversations. Do not share in other members' conversations or in channels.

## Pickup docks (by vendor + project)

| Vendor | Project | Dock | Since |
|---|---|---|---|
| Marrow Agrisupply | Merlin | Gate 38 | 2026-10-14 ("from now on") |

Note: this is Hollis's own dock. Other members' dock notes (e.g. Tobias's Marrow Agrisupply / Fernhill = Dock 31) are separate and must not be mixed in. Marrow Agrisupply is not Marrow Fieldworks.
