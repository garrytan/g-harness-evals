# Priyanka "Pree" Sundaram (Account manager, Central team, team-central)

Private: told to the assistant in a DM (DGBRAIN0003, ts 1792000800.000127, 2026-10-14). Use only in Pree's own conversations. Do not share in other members' conversations or in channels.

## Pickup docks (by vendor + project)

| Vendor | Project | Dock | Since |
|---|---|---|---|
| Marrow Agrisupply | Nettle | Door 13 | 2026-10-14 ("from now on") |

Note: this is Pree's own dock. Other members' dock notes (Tobias, Hollis) are separate and must not be mixed in. Marrow Agrisupply is not Marrow Fieldworks.
