# Hollis Mbeki (Central team lead, team-central): private notes (from his DM DGBRAIN0002)

Scope: Hollis told me this privately in a direct message (ts 1791993600.000125, 2026-10-14). Use it only in conversations with Hollis. Do not repeat it in other members' conversations or in channels (workspace rule 2).

## Hollis's go-to escalation contacts, by rollout
| Rollout | Customer | Go-to escalation contact | Since |
|---|---|---|---|
| Corvid | Marrow Agrisupply | Elodie Varno | 2026-10-14 ("from now on") |

Watch for look-alike names: Marrow Agrisupply is not Marrow Fieldworks. Elodie Varno is not Elodie Ashdown (Tansley Parcel) and is not Bram Varno (Tansleigh Packaging).
