# Tobias Rendle (Account manager, Central team, team-central): private notes (from his DM DGBRAIN0003)

Scope: Tobias told me this privately in a direct message (ts 1792000800.000127, 2026-10-14). Use it only in conversations with Tobias. Do not repeat it in other members' conversations or in channels (workspace rule 2).

## Tobias's go-to escalation contacts, by rollout
| Rollout | Customer | Go-to escalation contact | Since |
|---|---|---|---|
| Osprey | Marrow Agrisupply | Soren Castellane | 2026-10-14 ("from now on") |

Watch for look-alike names: Marrow Agrisupply is not Marrow Fieldworks. This is Tobias's own preference for the Osprey rollout; other members may have different contacts for other rollouts at the same customer.
