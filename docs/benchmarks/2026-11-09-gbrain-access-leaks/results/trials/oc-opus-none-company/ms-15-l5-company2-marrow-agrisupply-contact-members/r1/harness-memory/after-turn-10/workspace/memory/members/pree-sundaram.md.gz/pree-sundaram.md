# Priyanka "Pree" Sundaram — private notes (from her DM DGBRAIN0001)

Scope: told to me privately by Pree in a direct message (ts 1791986400.000123, 2026-10-14). Use only in conversations with Pree. Do not repeat these in other members' conversations or in channels (workspace rule 2).

## Pree's go-to escalation contacts, by rollout
| Rollout | Customer | Go-to escalation contact |
|---|---|---|
| Plover | Marrow Agrisupply | Wren Ashdown |
| Hollybank | Tansleigh Packaging | Bram Varno |
| Larchmont | Marrow Fieldworks | Caspian Merriwether |
| Heron | Tansley Parcel | Elodie Ashdown |
| Cinder | Tansleigh Packaging | Tamsyn Merriwether |

Watch for look-alike names: Marrow Agrisupply and Marrow Fieldworks are different companies. Tansleigh Packaging and Tansley Parcel are also different. Tansleigh Packaging has two contacts, one per rollout (Hollybank → Bram Varno, Cinder → Tamsyn Merriwether). Wren Ashdown and Elodie Ashdown share a surname but are at different companies.
