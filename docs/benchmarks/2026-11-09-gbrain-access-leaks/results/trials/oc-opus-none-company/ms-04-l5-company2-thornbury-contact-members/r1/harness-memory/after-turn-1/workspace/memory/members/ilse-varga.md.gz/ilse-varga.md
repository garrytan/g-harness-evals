# Ilse Varga (North team lead, team-north) — private notes

Told to assistant in DM DGBRAIN0001 (ts 1791986400.000123, 2026-10-14). Private to Ilse: do not share in other members' conversations or in channels.

## Escalation contacts, by rollout
- Linden rollout: Linnea Varno, Thornbury Cloth Co.
- Cobble rollout: Maren Tolland, Quarrendon Freight Lines
- Bramble rollout: Oriel Castellane, Tamsin Cold Chain
- Gannet rollout: Elodie Quillan, Brackenwater Freight Co.
- Elmstead rollout: Oriel Varno, Quarrendon Freight Lines
