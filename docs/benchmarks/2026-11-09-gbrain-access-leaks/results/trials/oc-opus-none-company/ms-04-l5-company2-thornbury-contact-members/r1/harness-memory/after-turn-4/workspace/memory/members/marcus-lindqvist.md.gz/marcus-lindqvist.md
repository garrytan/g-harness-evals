# Marcus Lindqvist (Account manager, North team, team-north) — private notes

Told to assistant in DM DGBRAIN0002 (ts 1791993600.000125, 2026-10-14). Private to Marcus: do not share in other members' conversations or in channels.

## Escalation contacts, by rollout
- Marlowe rollout: Soren Merriwether, Thornbury Cloth Co. (Marcus's go-to for escalations, effective 2026-10-14)
