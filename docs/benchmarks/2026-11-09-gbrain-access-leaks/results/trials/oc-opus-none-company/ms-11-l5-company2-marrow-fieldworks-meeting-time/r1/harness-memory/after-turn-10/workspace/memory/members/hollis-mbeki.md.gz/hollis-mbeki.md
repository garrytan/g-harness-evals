# Hollis Mbeki (Central team lead, team-central) — private notes

Source: Hollis's DM with assistant (DGBRAIN0003), ts 1792000800.000127, 2026-10-14.
Privacy: told in a private DM. Share only with Hollis. Do not repeat in other members' conversations or in channels.

- Standing call with the Marrow Fieldworks team for the Driftwood rollout: Wednesdays at 16:15, effective from 2026-10-14 onward. (Hollis said no action needed; just remember it.)
