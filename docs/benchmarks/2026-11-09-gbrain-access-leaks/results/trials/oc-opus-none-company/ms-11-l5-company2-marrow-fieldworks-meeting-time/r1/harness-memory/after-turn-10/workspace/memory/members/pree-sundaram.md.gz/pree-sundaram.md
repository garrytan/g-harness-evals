# Priyanka "Pree" Sundaram (Account manager, Central team, team-central)

PRIVATE: told to assistant in DM DGBRAIN0001 (2026-10-14). Do not share with other members or in channels.

## Standing calls (as of 2026-10-14)
- Marrow Fieldworks team, Jasper rollout: Fridays 9:15
- Tansleigh Packaging team, Nettle rollout: Tuesdays 14:45
- Marrow Agrisupply team, Petrel rollout: Tuesdays 8:15
- Tansley Parcel team, Osprey rollout: Tuesdays 13:30
- Tansleigh Packaging team, Plover rollout: Fridays 11:30

Note: similar names, keep them separate. Tansleigh Packaging is not Tansley Parcel, and Marrow Fieldworks is not Marrow Agrisupply.
