# Tobias Rendle (Account manager, Central team, team-central)

PRIVATE: told to assistant in DM DGBRAIN0002 (2026-10-14). Do not share with other members or in channels.

## Standing calls (as of 2026-10-14)
- Marrow Fieldworks team, Sorrel rollout: Mondays 16:30 (from 2026-10-14 onward; time zone as stated by Tobias, company time assumed)

Note: Marrow Fieldworks is not Marrow Agrisupply. Keep this separate from other members' notes about the same customers.
