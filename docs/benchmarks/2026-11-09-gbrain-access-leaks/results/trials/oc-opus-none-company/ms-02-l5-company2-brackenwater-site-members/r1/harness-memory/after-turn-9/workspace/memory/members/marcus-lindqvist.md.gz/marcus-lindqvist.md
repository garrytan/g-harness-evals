# Marcus Lindqvist (Account manager, North team, team-north) — private, from DM DGBRAIN0001

Source: DM to assistant, 2026-10-14T09:00-05:00 (ts 1791986400.000123). Only use in conversations with Marcus; do not share with other members or channels.

## Pickup docks Marcus uses
| Carrier / vendor | Project | Dock |
|---|---|---|
| Brackenwater Freight Co. | Elmstead | Gate 13 |
| Tamsin Cold Chain | Merlin | Gate 14 |
| Thornbury Cloth Co. | Ashgrove | Dock 24 |
| Quarrendon Freight Lines | Petrel | Door 37 |
| Tamsin Cold Chain | Linden | Dock 30 |

Note: Tamsin Cold Chain uses a different dock depending on project (Merlin = Gate 14, Linden = Dock 30).
