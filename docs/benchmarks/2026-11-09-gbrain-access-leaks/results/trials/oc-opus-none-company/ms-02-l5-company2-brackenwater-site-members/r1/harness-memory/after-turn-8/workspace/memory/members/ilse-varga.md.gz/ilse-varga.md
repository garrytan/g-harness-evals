# Ilse Varga (North team lead, team-north) — private, from DM DGBRAIN0002

Source: DM to assistant, 2026-10-14T11:00-05:00 (ts 1791993600.000125). Only use in conversations with Ilse; do not share with other members or channels.

## Pickup docks Ilse uses
| Carrier / vendor | Project | Dock |
|---|---|---|
| Brackenwater Freight Co. | Halyard | Door 42 (effective 2026-10-14, "from now on") |
