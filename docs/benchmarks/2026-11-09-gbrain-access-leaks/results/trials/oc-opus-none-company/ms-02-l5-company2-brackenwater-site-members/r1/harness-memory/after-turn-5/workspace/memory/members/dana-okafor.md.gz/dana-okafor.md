# Dana Okafor (Account manager, North team) — private DM preferences

Scope: told to the bot in Dana's DM (DGBRAIN0003). Use only when answering Dana; do not share in other members' conversations or channels.

- 2026-10-14: Dock for Brackenwater Freight Co. pickups on the Wicklow project is **Bay 28** from now on (Dana's stated preference/arrangement).
