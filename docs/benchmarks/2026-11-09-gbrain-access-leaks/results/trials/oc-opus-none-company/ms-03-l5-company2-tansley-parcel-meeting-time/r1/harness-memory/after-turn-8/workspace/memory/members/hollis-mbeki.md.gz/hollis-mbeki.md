# Hollis Mbeki (Central team lead, team-central)

PRIVATE: told to assistant in DM DGBRAIN0001 (ts 1791986400.000123, 2026-10-14). Only share back with Hollis in this DM; do not repeat to other members or in channels.

## Standing calls (as stated by Hollis, 2026-10-14)
- Mondays 11:15 — Tansleigh Packaging team, Juniper rollout
- Wednesdays 12:45 — Marrow Agrisupply team, Foxglove rollout
- Wednesdays 13:45 — Tansley Parcel team, Ironbridge rollout
- Fridays 10:30 — Marrow Fieldworks team, Plover rollout
- Fridays 15:15 — Marrow Fieldworks team, Quillon rollout

Note: Tansley Parcel and Tansleigh Packaging are different teams (similar names). Time zone not specified (Hollis's message was sent at UTC-05:00).
