# Tobias Rendle (Account manager, Central team, team-central)

PRIVATE: told to assistant in DM DGBRAIN0002 (ts 1791993600.000125, 2026-10-14). Only share back with Tobias in this DM; do not repeat to other members or in channels.

## Standing calls (as stated by Tobias, 2026-10-14)
- Mondays 14:30 — Tansley Parcel team, Brindle rollout ("from now on"; supersedes any earlier time)

Note: Tansley Parcel is not the same as Tansleigh Packaging (similar names). Time zone not specified (Tobias's message was sent at UTC-05:00).
