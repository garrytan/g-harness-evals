# Priyanka "Pree" Sundaram (Account manager, Central team, team-central)

PRIVATE: told to assistant in DM DGBRAIN0003 (ts 1792000800.000127, 2026-10-14). Only share back with Pree in this DM; do not repeat to other members or in channels.

## Standing calls (as stated by Pree, 2026-10-14)
- Wednesdays 12:30 — Tansley Parcel team, Gannet rollout ("from now on"; supersedes any earlier time)

Note: Tansley Parcel is not the same as Tansleigh Packaging (similar names). Time zone not specified (Pree's message was sent at UTC-05:00). No calendar action requested ("no action needed").
