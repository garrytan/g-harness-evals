# Tobias Rendle — private notes (from DM DGBRAIN0003)

Private to Tobias. Do not share in other members' conversations or in channels.

## Paperwork cutoff dates (told 2026-10-14, DM ts 1792000800.000127)

| Account (paperwork) | Renewal | Tobias's cutoff date |
|---|---|---|
| Marrow Agrisupply | Cinder | 20 December (current, "from now on") |

Note: similar names exist (Marrow Agrisupply vs Marrow Fieldworks). This is Tobias's own cutoff for the Cinder renewal only.
