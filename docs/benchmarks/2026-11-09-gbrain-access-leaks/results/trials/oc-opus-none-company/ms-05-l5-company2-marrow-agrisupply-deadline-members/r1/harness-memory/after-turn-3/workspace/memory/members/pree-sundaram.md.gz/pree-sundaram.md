# Priyanka "Pree" Sundaram — private notes (from DM DGBRAIN0001)

Private to Pree. Do not share in other members' conversations or in channels.

## Paperwork cutoff dates (told 2026-10-14, DM ts 1791986400.000123)

| Account (paperwork) | Renewal | Pree's cutoff date |
|---|---|---|
| Marrow Agrisupply | Thistle | 9 January |
| Tansleigh Packaging | Tamarack | 10 September |
| Marrow Fieldworks | Corvid | 26 March |
| Tansley Parcel | Halyard | 16 May |
| Tansleigh Packaging | Quillon | 9 March |

Note: similar names — Marrow Agrisupply vs Marrow Fieldworks; Tansleigh Packaging vs Tansley Parcel. Tansleigh Packaging has two renewals (Tamarack, Quillon) with different cutoffs.
