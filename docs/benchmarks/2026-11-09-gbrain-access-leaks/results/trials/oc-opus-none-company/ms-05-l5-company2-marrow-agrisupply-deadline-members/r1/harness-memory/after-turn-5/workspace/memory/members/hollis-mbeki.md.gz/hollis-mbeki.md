# Hollis Mbeki — private notes (from DM DGBRAIN0002)

Private to Hollis (Central team lead, team-central). Do not share in other members' conversations or in channels.

## Paperwork cutoff dates (told 2026-10-14, DM ts 1791993600.000125)

| Account (paperwork) | Renewal | Hollis's cutoff date |
|---|---|---|
| Marrow Agrisupply | Keystone | 3 June ("from now on") |

Note: similar account names exist (e.g. Marrow Agrisupply vs Marrow Fieldworks). This entry is Marrow Agrisupply / Keystone only.
