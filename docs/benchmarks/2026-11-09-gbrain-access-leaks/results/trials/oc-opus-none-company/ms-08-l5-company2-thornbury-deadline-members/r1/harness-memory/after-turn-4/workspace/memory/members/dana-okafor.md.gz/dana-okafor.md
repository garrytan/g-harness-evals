# Dana Okafor (Account manager, North team, team-north) — private notes

PRIVATE: told to the assistant in Dana's DM (DGBRAIN0002, ts 1791993600.000125, 2026-10-14).
Only share back with Dana herself, in her DM. Do not repeat in other members' conversations or in channels.

## Personal paperwork cutoff dates (renewals)
| Customer | Renewal | Dana's paperwork cutoff |
|---|---|---|
| Thornbury Cloth Co. | Jasper | 9 January (from 2026-10-14 onward; year not stated) |

Note: this is Dana's own cutoff for the Jasper renewal; it is separate from any other member's cutoffs for other Thornbury Cloth Co. renewals.
