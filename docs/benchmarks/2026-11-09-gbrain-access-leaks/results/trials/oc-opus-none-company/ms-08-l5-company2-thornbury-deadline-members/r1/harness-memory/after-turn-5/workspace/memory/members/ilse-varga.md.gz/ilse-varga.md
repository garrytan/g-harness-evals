# Ilse Varga (North team lead, team-north) — private notes

PRIVATE: told to the assistant in Ilse's DM (DGBRAIN0003, ts 1792000800.000127, 2026-10-14).
Only share back with Ilse herself, in her DM. Do not repeat in other members' conversations or in channels.

## Personal paperwork cutoff dates (renewals)
| Customer | Renewal | Ilse's paperwork cutoff |
|---|---|---|
| Thornbury Cloth Co. | Marlowe | 15 April (from 2026-10-14 onward; year not stated) |

Note: this is Ilse's own cutoff for the Marlowe renewal; it is separate from any other member's cutoffs for other Thornbury Cloth Co. renewals.
