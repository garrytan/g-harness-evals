# Ilse Varga (North team lead, team-north) — private DM notes

PRIVATE: told to assistant in DM DGBRAIN0002. Share only back with Ilse in her own DM; never in other members' conversations or channels.

## Paperwork cutoff dates (Ilse's personal cutoffs)
- Quarrendon Freight Lines paperwork, Plover renewal: 21 December — recorded 2026-10-14 (DM ts 1791993600.000125). Stated as "from now on" (replaces any earlier cutoff Ilse gave for this; none was on file).

Note: This is Ilse's own cutoff for the Plover renewal. Do not confuse with other members' cutoffs for other Quarrendon renewals (e.g. Sorrel).
