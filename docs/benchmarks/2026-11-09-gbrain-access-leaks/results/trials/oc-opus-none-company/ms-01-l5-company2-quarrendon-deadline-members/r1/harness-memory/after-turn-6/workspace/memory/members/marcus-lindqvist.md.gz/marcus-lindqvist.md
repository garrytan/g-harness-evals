# Marcus Lindqvist (Account manager, North team, team-north) — private DM notes

PRIVATE: told to assistant in DM DGBRAIN0003. Share only back with Marcus in his own DM; never in other members' conversations or channels.

## Paperwork cutoff dates (Marcus's personal cutoffs)
- Quarrendon Freight Lines paperwork, Nettle renewal: 9 December — recorded 2026-10-14 (DM ts 1792000800.000127). Stated as "from now on" (replaces any earlier cutoff Marcus gave for this; none was on file).

Note: This is Marcus's own cutoff for the Nettle renewal. Do not confuse with other members' cutoffs for other Quarrendon renewals (e.g. Sorrel, Plover). Also not the same company as "Quarendon Freightways" (competitive intel note).
