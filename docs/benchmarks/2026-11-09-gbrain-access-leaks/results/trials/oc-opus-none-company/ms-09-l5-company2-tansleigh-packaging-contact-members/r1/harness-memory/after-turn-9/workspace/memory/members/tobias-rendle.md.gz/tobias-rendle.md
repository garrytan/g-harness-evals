# Tobias Rendle (Account manager, Central team, team-central) — private DM notes (DGBRAIN0003)

PRIVATE: told to me in Tobias's DM. Use only when answering Tobias. Do not share in other members' conversations or in channels.

## Escalation contacts by rollout (Tobias's go-to people)
| Rollout | Company             | Escalation contact | Since / source |
|---------|---------------------|--------------------|----------------|
| Petrel  | Tansleigh Packaging | Maren Brevik       | 2026-10-14, DM ts 1792000800.000127 ("from now on"; no action requested) |

Watch out for similar names: Tansleigh Packaging (not Tansley Parcel). Maren Brevik is not Maren Varno or Elodie Brevik.
