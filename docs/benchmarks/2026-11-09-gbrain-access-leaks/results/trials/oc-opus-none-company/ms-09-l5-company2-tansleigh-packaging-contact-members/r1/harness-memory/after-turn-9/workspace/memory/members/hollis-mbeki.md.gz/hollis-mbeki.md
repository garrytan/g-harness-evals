# Hollis Mbeki (Central team lead, team-central) — private notes

PRIVATE: told to me in Hollis's DM (DGBRAIN0001, ts 1791986400.000123, 2026-10-14).
Use only when answering Hollis. Do not share in other members' conversations or in channels.

## Escalation contacts by rollout (Hollis's go-to people)
| Rollout    | Company             | Escalation contact  |
|------------|---------------------|---------------------|
| Kittiwake  | Tansleigh Packaging | Soren Merriwether   |
| Keystone   | Marrow Agrisupply   | Caspian Castellane  |
| Driftwood  | Marrow Fieldworks   | Bram Merriwether    |
| Hollybank  | Tansley Parcel      | Elodie Brevik       |
| Quillon    | Marrow Agrisupply   | Maren Varno         |

Watch out for similar names: Tansleigh Packaging vs Tansley Parcel; Marrow Agrisupply vs Marrow Fieldworks;
Soren and Bram are both Merriwether; Marrow Agrisupply has two different contacts (Keystone = Caspian, Quillon = Maren).
