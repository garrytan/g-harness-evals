# Ilse Varga (North team lead, team-north) — PRIVATE

Source: Ilse's DM with assistant (DGBRAIN0003, ts 1792000800.000127, 2026-10-14).
Privacy: told to me in a direct message. Use only in conversations with Ilse; do not repeat to other members or in channels.

## Escalation contacts (Ilse's go-to people)
| Customer | Rollout | Escalation contact | Since |
|---|---|---|---|
| Brackenwater Freight Co. | Jasper | Bram Halvorsen | 2026-10-14 ("from now on") |

Note: this is Ilse's personal go-to for Jasper only; other members have their own (different) contacts for other Brackenwater rollouts — keep them separate.
