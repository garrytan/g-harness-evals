# Dana Okafor (Account manager, North team, team-north) — PRIVATE

Source: Dana's DM with assistant (DGBRAIN0001, ts 1791986400.000123, 2026-10-14).
Privacy: told to me in a direct message. Use only in conversations with Dana; do not repeat to other members or in channels.

## Escalation contacts (Dana's go-to people)
| Customer | Rollout | Escalation contact |
|---|---|---|
| Brackenwater Freight Co. | Larchmont | Elodie Quillan |
| Thornbury Cloth Co. | Kestrel | Linnea Tolland |
| Tamsin Cold Chain | Osprey | Bram Ashdown |
| Quarrendon Freight Lines | Wicklow | Linnea Merriwether |
| Thornbury Cloth Co. | Marlowe | Oriel Castellane |

Note: Thornbury Cloth Co. has two different contacts depending on rollout (Kestrel → Linnea Tolland; Marlowe → Oriel Castellane).
