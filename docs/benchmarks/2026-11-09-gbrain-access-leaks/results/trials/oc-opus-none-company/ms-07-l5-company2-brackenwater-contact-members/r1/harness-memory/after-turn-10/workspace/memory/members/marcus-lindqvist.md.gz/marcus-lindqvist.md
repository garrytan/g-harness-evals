# Marcus Lindqvist (Account manager, North team, team-north) — PRIVATE

Source: Marcus's DM with assistant (DGBRAIN0002, ts 1791993600.000125, 2026-10-14).
Privacy: told to me in a direct message. Use only in conversations with Marcus; do not repeat to other members or in channels.

## Escalation contacts (Marcus's go-to people)
| Customer | Rollout | Escalation contact | Since |
|---|---|---|---|
| Brackenwater Freight Co. | Fernhill | Caspian Varno | 2026-10-14 ("from now on") |
