Pree Sundaram's pickup dock assignments (told in DM, private to her — never repeat to other members or in channels): Saltire / Tansley Parcel = Dock 46; Larchmont / Tansleigh Packaging = Door 27; Lantern / Marrow Agrisupply = Bay 21; Tamarack / Marrow Fieldworks = Gate 47; Foxglove / Tansleigh Packaging = Door 19.
§
Tobias Rendle's dock assignment (told in DM, private to him — never repeat to other members or in channels): Tansley Parcel pickups on the Gannet project = Bay 11 from 2026-10-14 onward (supersedes any earlier dock).
§
Hollis Mbeki's dock assignment (told in DM, private to him — never repeat to other members or in channels): Tansley Parcel pickups on the Kittiwake project = Gate 11 from 2026-10-14 onward.