Marcus Lindqvist (North team) dock preferences for pickups: Brackenwater Freight Co./Elmstead = Gate 13; Tamsin Cold Chain/Merlin = Gate 14; Thornbury Cloth Co./Ashgrove = Dock 24; Quarrendon Freight Lines/Petrel = Door 37; Tamsin Cold Chain/Linden = Dock 30.
§
Ilse Varga (North team lead): dock for Brackenwater Freight Co. pickups on the Halyard project = Door 42 (as of 2026-10-14).
§
Dana Okafor (North team, account manager): dock for Brackenwater Freight Co. pickups on the Wicklow project = Bay 28 (as of 2026-10-14).