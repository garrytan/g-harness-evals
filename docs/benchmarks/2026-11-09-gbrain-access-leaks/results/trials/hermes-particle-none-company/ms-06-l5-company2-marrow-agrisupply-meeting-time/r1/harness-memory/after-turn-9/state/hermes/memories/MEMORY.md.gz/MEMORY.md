Pree Sundaram (priyanka.sundaram, AM, team-central) standing rollout calls — reference only, no calendar events requested: Marrow Agrisupply/Lantern Fri 14:30; Tansley Parcel/Marlowe Tue 15:45; Marrow Fieldworks/Fernhill Fri 12:15; Tansleigh Packaging/Foxglove Tue 15:30; Tansley Parcel/Hollybank Thu 11:45.
§
Hollis Mbeki (team-central lead) standing call: Marrow Agrisupply, Saltire rollout — Thursdays 09:15 from 2026-10-14 on (reference only, no calendar events requested).
§
Tobias Rendle (AM, team-central) standing call: Marrow Agrisupply, Jasper rollout — Wednesdays 14:15 from 2026-10-14 on (reference only, no calendar events requested).