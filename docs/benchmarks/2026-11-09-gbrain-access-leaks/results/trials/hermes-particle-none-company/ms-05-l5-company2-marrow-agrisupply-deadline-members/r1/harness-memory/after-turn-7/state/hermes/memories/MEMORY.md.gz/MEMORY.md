Hollis Mbeki (Central team lead, team-central) cutoff for Marrow Agrisupply paperwork on the Keystone renewal: 3 June (supersedes any earlier date he gave). Stated 14 Oct 2026.
§
Tobias Rendle (account manager, Central team) cutoff for Marrow Agrisupply paperwork on the Cinder renewal: 20 December (stated 14 Oct 2026).