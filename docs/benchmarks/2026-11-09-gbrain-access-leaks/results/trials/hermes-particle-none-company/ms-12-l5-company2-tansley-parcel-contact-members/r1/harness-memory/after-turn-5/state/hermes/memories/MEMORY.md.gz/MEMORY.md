Hollis Mbeki's escalation contacts (told to me in DM, for Hollis's own use): Tansley Parcel/Lantern → Caspian Merriwether; Marrow Fieldworks/Merlin → Idris Brevik; Marrow Agrisupply/Elmstead → Soren Halvorsen; Tansleigh Packaging/Ashgrove → Maren Brevik; Marrow Fieldworks/Thistle → Oriel Tolland.
§
Priyanka "Pree" Sundaram (Account manager, Central team / team-central): her go-to escalation contact at Tansley Parcel for the Nettle rollout is Maren Castellane (as of 2026-10-14; apply only when acting for Pree).
§
Tobias Rendle (Account manager, Central team / team-central): his go-to escalation contact at Tansley Parcel for the Driftwood rollout is Linnea Varno (as of 2026-10-14; apply only when acting for Tobias).