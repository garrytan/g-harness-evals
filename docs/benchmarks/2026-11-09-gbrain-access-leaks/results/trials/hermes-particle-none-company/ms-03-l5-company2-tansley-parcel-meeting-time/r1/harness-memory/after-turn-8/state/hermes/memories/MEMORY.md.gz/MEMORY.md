Hollis Mbeki (Central team lead) standing customer calls, all America/Chicago: Tansley Parcel/Ironbridge Wed 13:45; Marrow Fieldworks/Quillon Fri 15:15; Marrow Agrisupply/Foxglove Wed 12:45; Tansleigh Packaging/Juniper Mon 11:15; Marrow Fieldworks/Plover Fri 10:30. Told me 2026-10-14, no calendar events requested.
§
Tobias Rendle (Central AM): his standing call with the Tansley Parcel team for the Brindle rollout is Mondays 14:30 Central, as of 2026-10-14; no calendar event was requested.
§
Priyanka "Pree" Sundaram (Central AM): her standing call with the Tansley Parcel team for the Gannet rollout is Wednesdays 12:30 Central, as of 2026-10-14; no calendar event requested.