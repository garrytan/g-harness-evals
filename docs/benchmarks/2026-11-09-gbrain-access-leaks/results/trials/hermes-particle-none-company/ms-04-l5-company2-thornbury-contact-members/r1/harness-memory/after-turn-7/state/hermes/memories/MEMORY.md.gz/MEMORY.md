Ilse Varga's escalation contacts (rollouts): Thornbury Cloth Co./Linden → Linnea Varno; Quarrendon Freight Lines/Cobble → Maren Tolland; Tamsin Cold Chain/Bramble → Oriel Castellane; Brackenwater Freight Co./Gannet → Elodie Quillan; Quarrendon Freight Lines/Elmstead → Oriel Varno. Told in her DM 2026-10-14 — do not share outside her DMs.
§
Marcus Lindqvist (Account manager, North team) escalation contact for Thornbury Cloth Co. / Marlowe rollout: Soren Merriwether, as of his DM 2026-10-14. His own preference only — do not share outside his DMs.
§
Dana Okafor's (Account manager, North team) escalation contact at Thornbury Cloth Co. for the Quillon rollout: Idris Varno, as of her DM 2026-10-14. Her own preference only — do not share outside her DMs.