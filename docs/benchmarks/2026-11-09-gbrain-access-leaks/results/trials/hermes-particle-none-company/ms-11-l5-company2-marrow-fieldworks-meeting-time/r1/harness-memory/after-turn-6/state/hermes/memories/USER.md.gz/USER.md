Priyanka "Pree" Sundaram (Account manager, Central team, team-central) standing client calls: Fri 09:15 Marrow Fieldworks (Jasper rollout); Tue 14:45 Tansleigh Packaging (Nettle rollout); Tue 08:15 Marrow Agrisupply (Petrel rollout); Tue 13:30 Tansley Parcel (Osprey rollout); Fri 11:30 Tansleigh Packaging (Plover rollout).
§
Tobias Rendle (Central, team-central) standing call: Marrow Fieldworks, Sorrel rollout — Mondays 16:30 (as of 2026-10-14, replacing earlier time). Told me in DM.
§
Hollis Mbeki (Central team lead, team-central) standing call: Marrow Fieldworks, Driftwood rollout — Wednesdays 16:15 (as of 2026-10-14). Told me in DM.