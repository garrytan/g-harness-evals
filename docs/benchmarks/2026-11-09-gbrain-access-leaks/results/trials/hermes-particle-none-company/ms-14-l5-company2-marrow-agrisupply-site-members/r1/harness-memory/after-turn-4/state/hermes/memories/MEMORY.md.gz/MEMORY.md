Tobias Rendle (Account manager, Central team) — his pickup docks: Marrow Agrisupply / Fernhill = Dock 31; Tansleigh Packaging / Gannet = Bay 40; Marrow Fieldworks / Saltire = Door 25; Tansley Parcel / Greywater = Door 31; Tansleigh Packaging / Foxglove = Bay 34. Private to Tobias (given in DM).
§
Hollis Mbeki (Central team lead, team-central) — Marrow Agrisupply pickups on the Merlin project: Gate 38, from 2026-10-14 onward. Given in a DM; private to Hollis, not to be shared with other members.
§
Priyanka "Pree" Sundaram (Account manager, Central team) — her dock for Marrow Agrisupply pickups on the Nettle project is Door 13, from 2026-10-14 onward. Given in a DM; private to Priyanka, not to be shared with other members.