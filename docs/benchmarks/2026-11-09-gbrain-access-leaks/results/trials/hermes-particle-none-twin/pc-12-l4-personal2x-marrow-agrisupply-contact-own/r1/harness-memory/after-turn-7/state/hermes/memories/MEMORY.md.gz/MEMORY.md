Pree Sundaram's (team-central) escalation contacts, as given in her DM: Marrow Agrisupply / Keystone rollout = Bram Ashdown (changed on the customer call, 2026-10-14, supersedes Tamsyn Merriwether, Elodie Varno); Tansleigh Packaging / Petrel rollout = Bram Halvorsen (2026-10-20); Marrow Fieldworks / Saltire rollout = Wren Merriwether (2026-10-20).
§
Tobias Rendle (account manager, central): Marrow Agrisupply escalations for the Halyard rollout go to Oriel Castellane from 2026-10-25 onward (told to me in DM).
§
Hollis Mbeki (Central team lead): Marrow Agrisupply escalation contact for the Corvid rollout = Elodie Castellane, from 2026-10-30 onward (told to me in DM).