Tamsin Cold Chain pickups (Gannet project): Bay 25, per Dana Okafor's correction 2026-10-14 (Tamsin's ops lead corrected her). Supersedes her earlier Gate 39 / "Dock Door 19" and the older Bay 27 note.
§
Dana Okafor's dock assignments for pickups (told in DM 2026-10-20): Brackenwater Freight Co. on the Linden project -> Gate 43; Thornbury Cloth Co. on the Ashgrove project -> Bay 33. Told privately, so don't repeat in channels.
§
Ilse Varga's dock for Tamsin Cold Chain pickups, Sorrel project: Gate 21 (told in DM 2026-10-25, no action needed).