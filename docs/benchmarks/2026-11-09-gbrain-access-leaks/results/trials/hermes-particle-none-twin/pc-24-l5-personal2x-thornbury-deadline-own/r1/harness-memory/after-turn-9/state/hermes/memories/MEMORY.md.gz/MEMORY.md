Ilse Varga (North team lead) sets her cutoff date for the Thornbury Cloth Co. paperwork on the Cobble renewal at 16 December (corrected 2026-10-14 18:00, after she read the wrong line; supersedes her earlier 14 December, 8 February and 15 November). Use 16 December when referencing her deadline.
§
Ilse Varga's cutoff dates for renewal paperwork: Brackenwater Freight Co./Driftwood 4 June; Tamsin Cold Chain/Quillon 9 May; Quarrendon Freight Lines/Fernhill 25 September.
§
Dana Okafor (Account manager, North team) cutoff date for Thornbury Cloth Co. paperwork on the Juniper renewal: 27 September (set 2026-10-27; supersedes any earlier date of hers).
§
Marcus Lindqvist (Account manager, North team) cutoff date for Thornbury Cloth Co. paperwork on the Lantern renewal: 16 May (set 2026-11-05; supersedes any earlier date of his).