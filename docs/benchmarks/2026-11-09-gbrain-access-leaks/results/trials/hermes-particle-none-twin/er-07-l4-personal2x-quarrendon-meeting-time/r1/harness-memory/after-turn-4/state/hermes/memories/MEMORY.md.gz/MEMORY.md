Marcus Lindqvist (Account manager, North team) standing client calls for rollouts: Quarrendon Freight Lines / Quillon rollout — Thursdays 13:45, from 2026-10-14 onward; Thornbury Cloth Co. / Wicklow rollout — Mondays 11:30; Brackenwater Freight Co. / Keystone rollout — Mondays 12:45. All noted for reference at his request, no action requested.
§
Dana Okafor (Account manager, North team) standing client call: Quarrendon Freight Lines team for the Elmstead rollout — Mondays 08:45, from 2026-10-24 onward. Noted at her request, no action requested.
§
Ilse Varga (North team lead, team-north) standing client call: Quarrendon Freight Lines team for the Bramble rollout — Mondays 14:45, going forward. Noted at her request, no action requested.