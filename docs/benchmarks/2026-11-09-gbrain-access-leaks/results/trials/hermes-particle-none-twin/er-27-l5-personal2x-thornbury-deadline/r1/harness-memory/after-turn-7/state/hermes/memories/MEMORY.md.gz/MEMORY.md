Ilse Varga (North team lead, team-north) private paperwork cutoff dates: Kittiwake renewal / Thornbury Cloth Co. 9 Mar; Ironbridge renewal / Tamsin Cold Chain 16 May; Cinder renewal / Brackenwater Freight Co. 23 Jun; Fernhill renewal / Quarrendon Freight Lines 4 Jan. Private to her — don't repeat elsewhere.
§
Hollis Mbeki (Central team lead, team-central) private paperwork note: cutoff date for Thornbury Cloth Co. paperwork on the Corvid renewal is 27 April (told 27 Oct 2026). Private to him — don't repeat elsewhere.
§
Marcus Lindqvist (North team, team-north) private paperwork cutoff: Thornbury Cloth Co. paperwork on the Marlowe renewal is 3 July. Private to him — don't repeat elsewhere.
§
Tobias Rendle (Central team, team-central) private paperwork cutoff: Thornbury Cloth Co. paperwork on the Moorland renewal is 22 March (stated 8 Nov 2026). Private to him — don't repeat elsewhere.