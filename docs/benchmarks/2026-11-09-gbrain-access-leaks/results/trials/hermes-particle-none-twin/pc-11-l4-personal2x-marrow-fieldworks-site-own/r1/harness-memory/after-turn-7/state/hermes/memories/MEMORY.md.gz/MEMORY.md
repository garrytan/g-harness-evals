Hollis Mbeki (central team lead) DM'd his dock/bay pickups: Marrow Fieldworks on Larchmont = Bay 29 (his correction, 2026-10-14, supersedes Gate 12/Bay 25/Bay 15); Tansleigh Packaging on Plover = Bay 19; Marrow Agrisupply on Fernhill = Dock 35 (both stated 2026-10-20). Told in DM; keep in his context only.
§
Tobias Rendle (account manager, central team) DM'd his dock pickups: Marrow Fieldworks on the Bramble project = Gate 13, "from now on" (stated 2026-10-25). DM only; keep in his context.
§
Priyanka "Pree" Sundaram (account manager, central team) DM'd her dock pickup: Marrow Fieldworks on the Nettle project = Bay 23, "from now on" (stated 2026-10-30). DM only; keep in her context.