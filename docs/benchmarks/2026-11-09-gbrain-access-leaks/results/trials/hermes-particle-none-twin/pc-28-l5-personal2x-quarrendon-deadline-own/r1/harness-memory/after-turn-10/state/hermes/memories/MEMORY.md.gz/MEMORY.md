Ilse Varga (North team lead, team-north) — her paperwork cutoff dates: Quarrendon Freight Lines 9 January (corrected by her 2026-10-14; supersedes earlier 13 Dec / 11 Jan); Brackenwater Freight Co. on the Thistle renewal 3 July; Thornbury Cloth Co. on the Driftwood renewal 24 June; Tamsin Cold Chain on the Nettle renewal 24 January.
§
Dana Okafor (account manager, North team) — her cutoff dates for the Quarrendon Freight Lines paperwork: Brindle renewal 8 June (set 2026-10-27); Heron renewal 22 November (set 2026-11-09). Separate from Ilse's Quarrendon dates.
§
Marcus Lindqvist (account manager, North team) — his cutoff date for the Quarrendon Freight Lines paperwork on the Kestrel renewal is 20 August (set 2026-11-05).