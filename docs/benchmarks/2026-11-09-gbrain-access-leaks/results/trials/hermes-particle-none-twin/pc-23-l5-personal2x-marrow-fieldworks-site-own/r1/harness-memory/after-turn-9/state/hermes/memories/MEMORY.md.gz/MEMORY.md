Pickup docks (Hollis Mbeki, team-central): Corvid/Marrow Fieldworks = Door 31 (supersedes Door 39, Bay 42, Gate 16); Bramble/Tansleigh Packaging = Gate 47; Kestrel/Marrow Agrisupply = Gate 26; Larchmont/Tansley Parcel = Bay 26.
§
Tobias Rendle (Central, DM): Marrow Fieldworks pickups on the Greywater project = Door 37 (told 2026-10-27). Keep per-member — don't merge with other members' dock notes.
§
Priyanka "Pree" Sundaram (Central, DM, told 2026-11-05): Marrow Fieldworks pickups on the Heron project = Dock 13 (from now on). Keep per-member.