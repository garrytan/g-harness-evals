Pree's standing calls: Tansley Parcel team / Nettle rollout — Thursdays 10:15 (from 2026-10-14); Marrow Agrisupply team / Saltire rollout — Wednesdays 9:30; Tansleigh Packaging team / Kestrel rollout — Fridays 11:45; Marrow Fieldworks team / Ironbridge rollout — Wednesdays 14:45.
§
Hollis Mbeki (Central team lead): standing call with the Tansley Parcel team / Jasper rollout — Fridays 15:45, effective 2026-10-27.
§
Ilse Varga (North team lead): standing call with the Tansley Parcel team / Petrel rollout — Mondays 12:15, effective 2026-11-04.