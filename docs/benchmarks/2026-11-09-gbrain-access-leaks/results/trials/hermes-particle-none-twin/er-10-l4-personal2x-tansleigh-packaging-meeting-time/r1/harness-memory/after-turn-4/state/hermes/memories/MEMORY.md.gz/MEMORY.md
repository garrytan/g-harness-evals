Hollis Mbeki (Central team lead, team-central) standing calls, told to me in DM: Tansleigh Packaging / Saltire rollout — Mondays 09:15 (weekly, confirmed 2026-10-14); Marrow Agrisupply / Foxglove rollout — Tuesdays 15:15; Tansley Parcel / Greywater rollout — Wednesdays 16:45 (last two noted 2026-10-19, no action requested).
§
Priyanka "Pree" Sundaram (Account manager, team-central) standing call: Tansleigh Packaging / Linden rollout — Fridays 12:45 from 2026-10-24 onward (no action requested).
§
Tobias Rendle (Account manager, team-central) standing call: Tansleigh Packaging / Cobble rollout — Tuesdays 10:30 from 2026-10-30 onward (no action requested).