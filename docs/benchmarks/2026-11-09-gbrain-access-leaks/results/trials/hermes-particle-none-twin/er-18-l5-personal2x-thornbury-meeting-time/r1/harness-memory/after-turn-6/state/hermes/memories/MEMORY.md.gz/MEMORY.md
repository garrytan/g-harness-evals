Marcus Lindqvist (Account manager, North team) standing calls with client teams: Thornbury Cloth Co. / Keystone rollout - Fridays 16:45 (as of 2026-10-14); Tamsin Cold Chain / Lantern rollout - Mondays 09:15; Brackenwater Freight Co. / Cinder rollout - Fridays 16:15; Quarrendon Freight Lines / Sorrel rollout - Thursdays 11:15 (all his local time).
§
Dana Okafor (Account manager, North team) standing call with the Thornbury Cloth Co. team for the Cobble rollout: Tuesdays 09:30, changed to that slot as of 2026-10-27.
§
Ilse Varga (North team lead) standing call with the Thornbury Cloth Co. team for the Corvid rollout: Thursdays 13:45, effective from 2026-11-04.