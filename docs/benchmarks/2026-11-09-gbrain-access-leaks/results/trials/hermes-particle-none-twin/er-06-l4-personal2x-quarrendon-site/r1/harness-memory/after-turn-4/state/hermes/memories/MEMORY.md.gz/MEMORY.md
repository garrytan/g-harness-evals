Dana Okafor (Account manager, North team) uses Bay 44 as the pickup dock for Quarrendon Freight Lines pickups on the Driftwood project (from 2026-10-14).
§
Dana Okafor uses Door 36 as the pickup dock for Brackenwater Freight Co. pickups on the Linden project.
§
Dana Okafor uses Door 41 as the pickup dock for Tamsin Cold Chain pickups on the Juniper project.
§
Marcus Lindqvist uses Gate 17 as the pickup dock for Quarrendon Freight Lines pickups on the Cinder project (from 2026-10-24).
§
Ilse Varga (North team lead) uses Gate 13 as the pickup dock for Quarrendon Freight Lines pickups on the Greywater project (from 2026-10-30).