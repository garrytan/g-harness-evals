Dana Okafor (North team, account manager): standing call with Brackenwater Freight Co. team re Gannet rollout = Mondays 16:15 local, ongoing as of 2026-10-14.
§
Dana Okafor (North team, account manager): standing call with Tamsin Cold Chain team re Bittern rollout = Tuesdays 12:45 local; standing call with Quarrendon Freight Lines team re Cobble rollout = Thursdays 09:45 local. Ongoing as of 2026-10-19.
§
Marcus Lindqvist (North team, account manager): standing call with the Brackenwater Freight Co. team re the Sorrel rollout = Thursdays 10:30 local, from 2026-10-24 onward (distinct from the Brackenwater/Gannet Mondays 16:15 slot).
§
Ilse Varga (North team lead): standing call with the Brackenwater Freight Co. team re the Tamarack rollout = Wednesdays 11:45 local, changed to that slot as of 2026-10-30 (recurring).