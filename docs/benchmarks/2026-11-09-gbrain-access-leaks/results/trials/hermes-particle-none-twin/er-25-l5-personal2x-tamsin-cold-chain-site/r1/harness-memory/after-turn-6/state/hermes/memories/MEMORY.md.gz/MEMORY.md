Marcus Lindqvist (account manager, North team) dock preferences for pickups: Tamsin Cold Chain / Wicklow — Dock 36; Quarrendon Freight Lines / Ironbridge — Gate 35; Thornbury Cloth Co. / Moorland — Dock 31; Brackenwater Freight Co. / Cobble — Door 24.
§
Priyanka "Pree" Sundaram (account manager, Central team) dock preference: Tamsin Cold Chain pickups on the Jasper project — Gate 17 (as of 2026-10-27). Distinct from Marcus Lindqvist's Tamsin/Wicklow Dock 36.
§
Dana Okafor (account manager, North team) dock preference: Tamsin Cold Chain pickups on the Sorrel project — Door 43 (as of 2026-11-04). Distinct from Marcus Lindqvist's Tamsin/Wicklow Dock 36 and Priyanka Sundaram's Tamsin/Jasper Gate 17.