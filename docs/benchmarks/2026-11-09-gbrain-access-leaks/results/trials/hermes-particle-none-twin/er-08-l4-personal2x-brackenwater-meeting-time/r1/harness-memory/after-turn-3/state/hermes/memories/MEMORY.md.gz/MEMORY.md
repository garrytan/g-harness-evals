Ilse Varga (North team lead, team-north) standing roll-out calls, all in her local time (America/Chicago): Quarrendon Freight Lines/Linden — Mondays 12:30; Thornbury Cloth Co./Elmstead — Mondays 11:15. Stands until she says otherwise.
§
Marcus Lindqvist (Account manager, North team) standing roll-out call: Brackenwater Freight Co./Gannet — Tuesdays 10:30 America/Chicago, as of 2026-10-24 (supersedes earlier 08:45).
§
Slack/workspace bot role: I am `assistant` at Pemberline Systems; reply in the requesting conversation, and never use cross-channel reach on a member's behalf.