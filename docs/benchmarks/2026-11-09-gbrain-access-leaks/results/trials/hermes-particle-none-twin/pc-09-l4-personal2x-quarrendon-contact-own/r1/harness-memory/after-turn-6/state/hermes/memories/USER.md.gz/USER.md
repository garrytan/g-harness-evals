Dana Okafor (Account manager, North team, team-north) — go-to escalation contact at Quarrendon Freight Lines is Bram Halvorsen (per Dana, 2026-10-14 18:00; she had given three different names earlier the same day: Soren Tolland, Wren Halvorsen, Idris Castellane — confirm before relying on this).
§
Dana Okafor's escalation contacts (per Dana, DM 2026-10-20): Brackenwater Freight Co. / Tamarack rollout → Wren Ashdown; Thornbury Cloth Co. / Marlowe rollout → Oriel Ashdown.
§
Marcus Lindqvist's escalation contact at Quarrendon Freight Lines for the Saltire rollout is Elodie Ashdown (per Marcus, DM 2026-10-25).