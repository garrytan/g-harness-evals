Ilse Varga (North team lead, team-north) paperwork cutoff dates, as she stated them: Tamsin Cold Chain on the Fernhill renewal - 7 November; Quarrendon Freight Lines on the Brindle renewal - 10 January; Brackenwater Freight Co. on the Cinder renewal - 27 September; Thornbury Cloth Co. on the Hollybank renewal - 13 September. (Given for reference, no action requested.)
§
Hollis Mbeki (Central team lead, team-central) states his cutoff date for the Tamsin Cold Chain paperwork on the Jasper renewal is 23 February, effective from 27 Oct 2026 onward. (Given for reference, no action requested.)
§
Marcus Lindqvist (account manager, North team, team-north) states his cutoff date for the Tamsin Cold Chain paperwork on the Juniper renewal is 18 June, from 4 Nov 2026 onward. (Given for reference, no action requested.)
§
Priyanka "Pree" Sundaram (account manager, Central team, team-central) states her cutoff date for the Tamsin Cold Chain paperwork on the Saltire renewal is 10 September, from now on. (Given for reference, no action requested.)