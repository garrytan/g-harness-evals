Hollis Mbeki (Central team lead, team-central): cutoff date for the Tansley Parcel paperwork on the Osprey renewal is now 8 March (changed as of 2026-10-14).
§
Hollis Mbeki (Central team lead, team-central) cutoffs: Tansleigh Packaging paperwork on the Nettle renewal — 27 November; Marrow Agrisupply paperwork on the Lantern renewal — 23 November; Marrow Fieldworks paperwork on the Moorland renewal — 6 March.
§
Priyanka "Pree" Sundaram (Account manager, Central team, team-central): her cutoff date for the Tansley Parcel paperwork on the Heron renewal is 17 November (set 2026-10-27).
§
Marcus Lindqvist (Account manager, North team, team-north): his cutoff date for the Tansley Parcel paperwork on the Wicklow renewal is 7 February (set 2026-11-04).