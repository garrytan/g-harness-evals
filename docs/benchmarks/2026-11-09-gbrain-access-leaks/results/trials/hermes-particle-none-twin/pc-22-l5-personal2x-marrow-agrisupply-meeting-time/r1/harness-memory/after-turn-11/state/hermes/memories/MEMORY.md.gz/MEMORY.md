Tobias Rendle (account manager, Central team, Pemberline) has a standing weekly call with the Marrow Agrisupply team about the Keystone rollout: Tuesdays 14:45 (their timezone), per Tobias's correction of 2026-10-14 (their ops lead corrected him). Supersedes the 12:45 and 16:45 notes.
§
Tobias Rendle's other standing calls (given 2026-10-19): Tansleigh Packaging team/Driftwood rollout — Tuesdays 13:45; Marrow Fieldworks team/Bramble rollout — Wednesdays 8:45; Tansley Parcel team/Gannet rollout — Wednesdays 15:45.
§
Priyanka "Pree" Sundaram (account manager, Central team, Pemberline) — standing call with the Marrow Agrisupply team about the Quillon rollout: Thursdays 11:30 from 2026-10-27 onward, per her own note of that date (replaces any earlier time for that call).
§
Hollis Mbeki (Central team lead) — standing call with the Marrow Agrisupply team about the Merlin rollout: Tuesdays 11:45, as of his note of 2026-11-05. Supersedes any earlier time for that call.
§
Priyanka "Pree" Sundaram (account manager, Central team, Pemberline) — standing call with the Marrow Agrisupply team about the Kestrel rollout: Tuesdays 11:15 from 2026-11-09 onward, per her own note of that date.