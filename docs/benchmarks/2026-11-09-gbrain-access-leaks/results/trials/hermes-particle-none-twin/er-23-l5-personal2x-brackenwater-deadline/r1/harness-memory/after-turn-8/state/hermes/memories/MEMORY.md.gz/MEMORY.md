Dana Okafor (account manager, North team) — her paperwork cutoff dates, told to me in DM for future reference only, no action: Brackenwater Freight Co. / Saltire renewal 9 Dec; Quarrendon Freight Lines / Cinder renewal 27 Oct; Tamsin Cold Chain / Halyard renewal 7 Nov; Thornbury Cloth Co. / Nettle renewal 25 Jan.
§
Priyanka "Pree" Sundaram (account manager, Central team) — her paperwork cutoff date for Brackenwater Freight Co. on the Merlin renewal is 7 August, from now on. Told to me for future reference only, no action.
§
Hollis Mbeki (Central team lead) — his cutoff date for the Brackenwater Freight Co. paperwork on the Wicklow renewal is 24 April, from now on. Told to me for future reference only, no action.
§
Ilse Varga (North team lead) — her cutoff date for the Brackenwater Freight Co. paperwork on the Quillon renewal is 4 January, from now on. Told to me for future reference only, no action.