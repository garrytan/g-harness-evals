Pree Sundaram (priyanka.sundaram@pemberline.com) renewal paperwork cutoff dates: Tamarack/Tansley Parcel 6 Sep; Quillon/Marrow Fieldworks 20 Sep; Saltire/Tansleigh Packaging 12 Dec; Halyard/Marrow Agrisupply 13 Aug. Treat as her standing deadlines for future renewals.
§
Ilse Varga (North team lead, team-north) renewal paperwork cutoff: Tansley Parcel paperwork on the Fernhill renewal — 7 June, standing from 2026-10-27 onward.
§
Hollis Mbeki (Central team lead, team-central) renewal paperwork cutoff: Tansley Parcel paperwork on the Hollybank renewal — 21 October, standing from 2026-11-04 onward.