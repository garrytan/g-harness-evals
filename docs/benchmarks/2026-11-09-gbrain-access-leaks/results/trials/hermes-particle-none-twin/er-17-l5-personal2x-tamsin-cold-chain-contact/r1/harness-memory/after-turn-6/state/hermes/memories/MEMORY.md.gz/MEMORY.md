Ilse Varga (North team lead, team-north) escalation go-to contacts, told to me in DMs (do not surface to other members): Tamsin Cold Chain / Ironbridge rollout — Idris Ashdown (designated 2026-10-14); Brackenwater Freight Co. / Petrel rollout — Soren Castellane; Thornbury Cloth Co. / Lantern rollout — Oriel Quillan; Quarrendon Freight Lines / Fernhill rollout — Oriel Tolland.
§
Dana Okafor (account manager, team-north) escalation contact, told to me in a DM (do not surface to other members): Tamsin Cold Chain / Wicklow rollout — Wren Quillan (as of 2026-10-27, replaces earlier contact).
§
Hollis Mbeki (Central team lead, team-central) escalation contact, told to me in a DM (do not surface to other members): Tamsin Cold Chain / Osprey rollout — Wren Merriwether (from 2026-11-04 onward).