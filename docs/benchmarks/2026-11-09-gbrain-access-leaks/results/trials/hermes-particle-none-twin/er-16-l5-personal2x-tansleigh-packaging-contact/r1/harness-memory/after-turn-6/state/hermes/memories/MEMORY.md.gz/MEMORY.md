Pree Sundaram's go-to escalation contacts (told to me in DMs; private to Pree — do not share): Tansleigh Packaging / Saltire rollout — Linnea Tolland; Marrow Fieldworks / Petrel rollout — Maren Varno; Marrow Agrisupply / Larchmont rollout — Wren Varno; Tansley Parcel / Bramble rollout — Tamsyn Quillan.
§
Hollis Mbeki's go-to escalation contact (told to me in DMs; private to Hollis — do not share): Tansleigh Packaging, Thistle rollout — Linnea Merriwether.
§
Dana Okafor's go-to escalation contact (told to me in DMs; private to Dana — do not share): Tansleigh Packaging, Corvid rollout — Maren Merriwether (as of 2026-11-04).