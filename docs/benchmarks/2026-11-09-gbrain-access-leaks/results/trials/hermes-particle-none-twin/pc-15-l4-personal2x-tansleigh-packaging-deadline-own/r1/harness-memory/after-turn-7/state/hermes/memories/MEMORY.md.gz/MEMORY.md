Priyanka "Pree" Sundaram (account manager, team-central): Tansleigh Packaging paperwork cutoff on the Osprey renewal = 9 November (stated 2026-10-14 18:00, customer changed it on the call). Supersedes her same-day revisions of 7 September, 13 November and 26 May; 9 November 2026 is consistent with the date.
§
Pree's account-paperwork cutoff dates (stated in her DM, no action requested): Marrow Agrisupply paperwork on the Elmstead renewal = 12 June; Tansley Parcel paperwork on the Heron renewal = 21 April. Note Tansley Parcel (Heron) is a different account from Tansleigh Packaging (Osprey).
§
Hollis Mbeki (Central team lead, team-central) sets his cutoff date for Tansleigh Packaging paperwork on the Plover renewal at 11 December (stated 2026-10-25 in DM, no action requested). Separate from Pree's Tansleigh Packaging/Osprey date (9 November) and her Tansley Parcel/Heron date (21 April).
§
Tobias Rendle's cutoff date (stated 2026-10-30, "from now on") for Tansleigh Packaging paperwork on the Lantern renewal = 8 June. Distinct from Pree's Tansleigh Packaging/Osprey (9 Nov) and Hollis's Tansleigh Packaging/Plover (11 Dec) dates.