Dana Okafor (Account manager, North team) — cutoff date for Thornbury Cloth Co. paperwork on the Wicklow renewal is 13 September (per Dana 2026-10-14 18:00, her fourth revision that day: 12 April → 9 August → 6 December → 13 September; latest wins, customer changed it on the call). Private to Dana — do not repeat outside her DM.
§
Dana Okafor (North team) renewal paperwork cutoff dates she supplied for reference: Tamsin Cold Chain paperwork / Heron renewal = 19 October; Brackenwater Freight Co. paperwork / Halyard renewal = 4 February. Private to Dana — DM only, never repeat in a channel or to another member.
§
Marcus Lindqvist (Account manager, North team): cutoff date for Thornbury Cloth Co. paperwork on the Larchmont renewal = 26 August (stated 2026-10-25, for future reference, no action).
§
Ilse Varga (North team lead): cutoff date for Thornbury Cloth Co. paperwork on the Driftwood renewal = 26 October (stated 2026-10-30, for future reference, no action). Private to Ilse — DM only, never repeat in a channel or to another member.