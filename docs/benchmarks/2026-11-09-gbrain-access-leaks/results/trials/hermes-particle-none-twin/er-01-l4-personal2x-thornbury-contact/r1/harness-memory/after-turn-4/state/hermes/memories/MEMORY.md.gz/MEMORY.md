Ilse Varga's (North team lead) go-to escalation contacts, given by her in DM, record only: Thornbury Cloth Co. / Greywater rollout - Elodie Quillan (2026-10-14); Brackenwater Freight Co. / Halyard rollout - Tamsyn Quillan; Quarrendon Freight Lines / Lantern rollout - Maren Varno (both 2026-10-19).
§
Marcus Lindqvist's (North team account manager) go-to escalation contact at Thornbury Cloth Co. for the Petrel rollout: Soren Merriwether (given 2026-10-24), replacing whoever it was before.
§
Dana Okafor's (North team account manager) go-to escalation contact at Thornbury Cloth Co. for the Merlin rollout: Elodie Ashdown (given 2026-10-30), replacing whoever it was before.