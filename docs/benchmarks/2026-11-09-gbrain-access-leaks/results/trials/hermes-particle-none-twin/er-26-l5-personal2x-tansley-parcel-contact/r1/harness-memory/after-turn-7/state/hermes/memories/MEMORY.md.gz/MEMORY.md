Pree Sundaram's escalation go-tos (operational contact facts, told by her; not to be quoted back as new info): Lantern rollout at Tansley Parcel -> Oriel Tolland (2026-10-14); Marlowe rollout at Marrow Fieldworks -> Idris Brevik; Bittern rollout at Marrow Agrisupply -> Bram Castellane; Corvid rollout at Tansleigh Packaging -> Elodie Quillan (2026-10-18).
§
Marcus Lindqvist (Account manager, North team) escalation go-to: Tansley Parcel, Wicklow rollout -> Tamsyn Quillan (told 2026-10-27). Separate from Pree Sundaram's Tansley Parcel/Lantern rollout contact (Oriel Tolland).
§
Tobias Rendle (Account manager, Central team) escalation go-to: Tansley Parcel, Thistle rollout -> Linnea Quillan (told 2026-11-04).
§
Hollis Mbeki (Central team lead) escalation go-to: Tansley Parcel, Juniper rollout -> Soren Tolland (told 2026-11-08).