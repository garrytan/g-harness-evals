Marcus Lindqvist (Account manager, North team, team-north) escalation contact at Quarrendon Freight Lines for the Greywater rollout: Linnea Ashdown (corrected by Marcus 2026-10-14, supersedes Oriel Quillan and all earlier names).
§
North team escalation contacts from Marcus Lindqvist: Brackenwater Freight Co. / Fernhill rollout = Idris Castellane; Thornbury Cloth Co. / Linden rollout = Tamsyn Brevik (told 2026-10-20).
§
Quarrendon Freight Lines escalation contact for the Bittern rollout = Oriel Castellane (per Dana Okafor, 2026-10-25). Scoped to Bittern only; the Greywater rollout contact remains Linnea Ashdown.
§
Quarrendon Freight Lines escalation contact for the Ironbridge rollout = Soren Ashdown, per Ilse Varga (North team lead) on 2026-10-30. Scoped to Ironbridge; Greywater stays Linnea Ashdown, Bittern stays Oriel Castellane.