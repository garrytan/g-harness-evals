Brackenwater Freight Co. (Gannet project): Marcus Lindqvist's pickup dock is Bay 38.
§
Tamsin Cold Chain (Saltire project): Marcus Lindqvist's pickup dock is Gate 39.