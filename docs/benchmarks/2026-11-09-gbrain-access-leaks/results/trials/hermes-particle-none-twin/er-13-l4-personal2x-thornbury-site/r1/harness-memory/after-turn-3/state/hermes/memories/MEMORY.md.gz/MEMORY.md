Brackenwater Freight Co. (Gannet project): Marcus Lindqvist's pickup dock is Bay 38.
§
Tamsin Cold Chain (Saltire project): Marcus Lindqvist's pickup dock is Gate 39.
§
Dana Okafor (Pemberline Systems, North team): dock for Thornbury Cloth Co. pickups on the Marlowe project is Gate 17 (as of 2026-10-24).