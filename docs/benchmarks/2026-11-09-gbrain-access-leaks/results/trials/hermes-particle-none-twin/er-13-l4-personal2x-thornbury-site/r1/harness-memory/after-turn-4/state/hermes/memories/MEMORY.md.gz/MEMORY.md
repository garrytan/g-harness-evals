Brackenwater Freight Co. (Gannet project): Marcus Lindqvist's pickup dock is Bay 38.
§
Tamsin Cold Chain (Saltire project): Marcus Lindqvist's pickup dock is Gate 39.
§
Dana Okafor (Pemberline Systems, North team): dock for Thornbury Cloth Co. pickups on the Marlowe project is Gate 17 (as of 2026-10-24).
§
Ilse Varga (Pemberline Systems, North team lead): dock for Thornbury Cloth Co. pickups on the Bittern project is Bay 41 (as of 2026-10-30).