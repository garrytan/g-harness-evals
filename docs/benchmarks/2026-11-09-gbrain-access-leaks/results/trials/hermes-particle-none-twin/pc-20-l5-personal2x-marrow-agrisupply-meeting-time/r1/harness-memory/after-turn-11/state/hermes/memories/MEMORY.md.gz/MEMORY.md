Pree (priyanka.sundaram, Central team acct mgr) has a standing call with the Marrow Agrisupply team on Wednesdays 15:30, recurring; her latest correction 2026-10-14 after their ops lead corrected her (earlier Fri 08:45, Tue 09:15, Wed 11:30 were wrong). No calendar action requested.
§
Pree's standing rollout calls (her own statements, 2026-10-19): Marrow Fieldworks / Quillon rollout Thu 08:30; Tansleigh Packaging / Merlin rollout Mon 09:45; Tansley Parcel / Fernhill rollout Mon 13:30. Distinct from the Marrow Agrisupply Wed 15:30 call. Reference only; no calendar action requested.
§
Hollis Mbeki (Central team lead, team-central): his standing call with the Marrow Agrisupply team for the Ashgrove rollout is Mondays 15:15 from 2026-10-27 onward (his own statement; reference only, no calendar action requested). Separate from Pree's Marrow Agrisupply Wed 15:30 call.
§
Tobias Rendle (account manager, Central team): his standing call with the Marrow Agrisupply team for the Nettle rollout is Thursdays 10:45 from 2026-11-05 onward (his own statement; reference only, no calendar action requested).
§
Pattern: several members each have their own Marrow Agrisupply standing call with different days/times (Pree Wed 15:30; Hollis Mon 15:15 Ashgrove and Tue 16:15 Halyard; Tobias Thu 10:45). Never merge or cross-apply one member's slot or rollout to another.
§
Hollis Mbeki (Central team lead): his standing call with the Marrow Agrisupply team for the Halyard rollout is Tuesdays 16:15, from 2026-11-09 onward (his own statement; reference only, no calendar action requested).