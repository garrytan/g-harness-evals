Dana Okafor (account manager, North team) — cutoff date for Brackenwater Freight Co. paperwork on the Brindle renewal is now 7 November (told to me in DM 2026-10-14).
§
Dana Okafor (account manager, North team) — cutoff date for Thornbury Cloth Co. paperwork on the Jasper renewal is 22 February (told to me in DM 2026-10-19).
§
Dana Okafor (account manager, North team) — cutoff date for Quarrendon Freight Lines paperwork on the Cinder renewal is 7 December (told to me in DM 2026-10-19).