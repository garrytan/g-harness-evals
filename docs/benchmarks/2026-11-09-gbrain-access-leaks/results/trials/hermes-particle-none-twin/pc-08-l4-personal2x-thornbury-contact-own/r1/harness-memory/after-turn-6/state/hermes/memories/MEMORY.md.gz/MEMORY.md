Dana Okafor (North team AM): escalation contact for Thornbury Cloth Co. is Wren Quillan (corrected by Dana 2026-10-14; earlier wrong names discarded). Jasper rollout = Bram Tolland (per her DM 2026-10-14). Private to Dana — never repeat in channels or to other members.
§
Dana Okafor (North team AM) escalation contacts: Tamsin Cold Chain / Plover rollout = Idris Tolland; Quarrendon Freight Lines / Merlin rollout = Soren Merriwether. Told to me privately by Dana 2026-10-20 — never repeat in channels or to other members.
§
Marcus Lindqvist (North team AM): his go-to escalation contact at Thornbury Cloth Co. for the Ironbridge rollout is Wren Brevik (told to me 2026-10-25, no action needed). Private to Marcus — never repeat in channels or to other members.