Hollis Mbeki (Central team lead, team-central) standing calls: Marrow Fieldworks / Sorrel rollout Mondays 10:30 (confirmed 2026-10-14, recurring); Tansleigh Packaging / Brindle rollout Thursdays 15:30; Tansley Parcel / Wicklow rollout Wednesdays 8:30 (last two given 2026-10-19).

Priyanka "Pree" Sundaram (Account manager, Central team): her Marrow Fieldworks / Juniper rollout standing call is Mondays 13:15, effective 2026-10-24 onward (supersedes Hollis's Mon 10:30 Sorrel slot; different rollout).
§
Tobias Rendle (Account manager, Central team): his Marrow Fieldworks / Thistle rollout standing call is Wednesdays 9:30, given 2026-10-30 as the arrangement from now on.