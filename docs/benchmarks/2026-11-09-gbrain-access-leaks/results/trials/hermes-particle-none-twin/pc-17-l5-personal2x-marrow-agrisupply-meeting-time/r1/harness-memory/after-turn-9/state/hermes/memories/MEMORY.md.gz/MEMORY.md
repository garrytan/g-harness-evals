Hollis Mbeki (Central team lead, team-central) standing rollout calls (told privately in DMs — do not surface to other members): Marrow (Cobble rollout) Thursdays 13:15 from 2026-10-14; Tansley Parcel (Osprey rollout) Mondays 8:30; Tansleigh Packaging (Cinder rollout) Mondays 10:45; Marrow Fieldworks (Linden rollout) Fridays 12:15.
§
Tobias Rendle (Account manager, team-central) standing call with the Marrow Agrisupply team for the Quillon rollout: Tuesdays 11:30, from 2026-10-27 onward (told privately in DM; do not surface to other members).
§
Priyanka "Pree" Sundaram (Account manager, team-central) standing call with the Marrow Agrisupply team for the Wicklow rollout: Fridays 11:45, ongoing from 2026-11-05 (told privately in DM; do not surface to other members).