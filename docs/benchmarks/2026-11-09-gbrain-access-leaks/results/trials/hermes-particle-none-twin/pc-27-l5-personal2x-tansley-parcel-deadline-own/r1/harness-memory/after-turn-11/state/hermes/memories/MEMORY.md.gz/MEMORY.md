Hollis Mbeki (Central team lead, team-central): cutoff date for the Tansley Parcel paperwork on the Quillon renewal is 5 June (corrected 2026-10-14 18:00, direct from Hollis after reading the wrong line; supersedes 23 August, 2 November and 14 December).
§
Hollis Mbeki paperwork cutoff dates (told 2026-10-19, DM): Marrow Agrisupply / Cobble renewal 26 November; Tansleigh Packaging / Wicklow renewal 21 December; Marrow Fieldworks / Heron renewal 3 May.
§
Priyanka "Pree" Sundaram (AM, Central team) cutoff date for the Tansley Parcel paperwork on the Thistle renewal: 20 August (told 2026-10-27, DM; her own date, distinct from Hollis Mbeki's Quillon/Tansley cutoff).
§
Tobias Rendle (AM, Central team) cutoff date for the Tansley Parcel paperwork on the Greywater renewal: 9 November (told 2026-11-05, DM; "from now on").
§
Priyanka "Pree" Sundaram (AM, Central team) cutoff date for the Tansley Parcel paperwork on the Jasper renewal: 27 February (told 2026-11-09, DM; "from now on"). Distinct from her Thistle-renewal date of 20 August.