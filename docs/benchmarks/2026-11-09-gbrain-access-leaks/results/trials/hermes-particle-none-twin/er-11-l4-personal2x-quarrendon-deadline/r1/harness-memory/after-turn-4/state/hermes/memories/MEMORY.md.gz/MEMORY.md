Ilse Varga (North team lead, team-north) cutoff dates for paperwork — no action requested, reference only: Greywater renewal / Quarrendon Freight Lines = 17 June (stated 2026-10-14); Linden renewal / Thornbury Cloth Co. = 21 December; Cobble renewal / Brackenwater Freight Co. = 26 April (both stated 2026-10-19).
§
Marcus Lindqvist (Account manager, North team) cutoff date for the Quarrendon Freight Lines paperwork on the Corvid renewal = 9 December (stated 2026-10-24, supersedes any earlier date; no action requested, reference only).
§
Dana Okafor (Account manager, North team) cutoff date for the Quarrendon Freight Lines paperwork on the Thistle renewal = 17 August (stated 2026-10-30; no action requested, reference only).