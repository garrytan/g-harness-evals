Ilse Varga (North team lead, team-north): her cutoff date for the Brackenwater Freight Co. paperwork on the Tamarack renewal is 22 January (stated 2026-10-14).
§
Ilse Varga's paperwork cutoff dates (stated 2026-10-18): Brackenwater Freight Co. / Tamarack renewal = 22 January; Thornbury Cloth Co. / Greywater renewal = 3 July; Quarrendon Freight Lines / Gannet renewal = 25 September; Tamsin Cold Chain / Hollybank renewal = 3 August.
§
Marcus Lindqvist (Account manager, North team): his cutoff date for Brackenwater Freight Co. paperwork on the Wicklow renewal is 16 October, going forward (stated 2026-10-27).