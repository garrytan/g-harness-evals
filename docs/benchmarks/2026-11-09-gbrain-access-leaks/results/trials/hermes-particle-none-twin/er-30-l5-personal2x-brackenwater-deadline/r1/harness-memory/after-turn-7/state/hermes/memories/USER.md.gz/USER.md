Ilse Varga (North team lead, team-north): her cutoff date for the Brackenwater Freight Co. paperwork on the Tamarack renewal is 22 January (stated 2026-10-14).
§
Ilse Varga's paperwork cutoff dates (stated 2026-10-18): Brackenwater Freight Co. / Tamarack renewal = 22 January; Thornbury Cloth Co. / Greywater renewal = 3 July; Quarrendon Freight Lines / Gannet renewal = 25 September; Tamsin Cold Chain / Hollybank renewal = 3 August.
§
Marcus Lindqvist (Account manager, North team): his cutoff date for Brackenwater Freight Co. paperwork on the Wicklow renewal is 16 October, going forward (stated 2026-10-27).
§
Priyanka "Pree" Sundaram (Account manager, Central team, team-central): her cutoff date for Brackenwater Freight Co. paperwork on the Halyard renewal is 15 August, going forward (stated 2026-11-04).
§
Hollis Mbeki (Central team lead, team-central): his cutoff date for Brackenwater Freight Co. paperwork on the Marlowe renewal is 8 June, from now on (stated 2026-11-08).