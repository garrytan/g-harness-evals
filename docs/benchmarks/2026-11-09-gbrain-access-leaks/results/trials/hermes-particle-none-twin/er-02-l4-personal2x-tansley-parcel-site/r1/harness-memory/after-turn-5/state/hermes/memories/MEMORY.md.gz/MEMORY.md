Bramble project (Tansley Parcel pickups): Priyanka "Pree" Sundaram (Central team, account manager) uses Door 35 as her dock. Stated 2026-10-14, "from now on."
§
Sorrel project: Pree Sundaram's dock for Tansleigh Packaging pickups is Door 16. Stated 2026-10-19.
§
Lantern project: Pree Sundaram's dock for Marrow Agrisupply pickups is Gate 22. Stated 2026-10-19.
§
Driftwood project: Tobias Rendle's dock for Tansley Parcel pickups is Bay 41. Stated 2026-10-24, "from now on."
§
Tamarack project: Hollis Mbeki's dock for Tansley Parcel pickups is Dock 42. Stated 2026-10-30, "from now on."