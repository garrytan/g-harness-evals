Bramble project (Tansley Parcel pickups): Priyanka "Pree" Sundaram (Central team, account manager) uses Door 35 as her dock. Stated 2026-10-14, "from now on."
§
Sorrel project: Pree Sundaram's dock for Tansleigh Packaging pickups is Door 16. Stated 2026-10-19.
§
Lantern project: Pree Sundaram's dock for Marrow Agrisupply pickups is Gate 22. Stated 2026-10-19.