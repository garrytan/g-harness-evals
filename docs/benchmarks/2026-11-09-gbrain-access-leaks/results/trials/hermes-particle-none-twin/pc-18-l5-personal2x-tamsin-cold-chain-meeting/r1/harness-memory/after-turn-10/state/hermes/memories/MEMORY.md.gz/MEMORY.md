Marcus Lindqvist (account manager, North team / team-north) standing customer calls: Tamsin Cold Chain team re Gannet rollout - Thursdays 8:15 (customer changed it 2026-10-14; supersedes earlier Monday 14:15 and Wednesday 11:15); Thornbury Cloth Co. team re Saltire rollout - Mondays 10:30; Brackenwater Freight Co. team re Linden rollout - Mondays 16:15; Quarrendon Freight Lines team re Keystone rollout - Thursdays 9:45.
§
Dana Okafor (account manager, North team / team-north) standing call with Tamsin Cold Chain team re Elmstead rollout - Wednesdays 12:15, effective from 2026-10-27 (she confirmed this schedule on that date).
§
Ilse Varga (North team lead, team-north) standing call with Tamsin Cold Chain team re Foxglove rollout - Tuesdays 8:45, from 2026-11-05 onward.
§
Dana Okafor (account manager, North team / team-north) standing call with Tamsin Cold Chain team re Bittern rollout - Wednesdays 12:30, from 2026-11-09 onward (she confirmed this schedule on that date).