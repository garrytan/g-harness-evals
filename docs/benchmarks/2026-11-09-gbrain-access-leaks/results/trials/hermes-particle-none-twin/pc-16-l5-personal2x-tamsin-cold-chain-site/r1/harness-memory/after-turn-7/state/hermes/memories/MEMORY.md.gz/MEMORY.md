Tamsin Cold Chain pickups dock: Dock 25 per Marcus Lindqvist (DM correction 2026-10-14 18:00, citing Finance's updated sheet). Supersedes his earlier Dock 23/35/30 figures; unverified against any dock schedule.
§
Docks Marcus Lindqvist uses (his own practice, per his DM 2026-10-19, "for future reference"): Quarrendon Freight Lines pickups on Thistle project = Gate 35; Brackenwater Freight Co. pickups on Hollybank project = Gate 12; Thornbury Cloth Co. pickups on Fernhill project = Door 18. Tell Marcus only; not for channels or other members.
§
Dock Ilse Varga uses for Tamsin Cold Chain pickups on the Bramble project: Door 43, "from now on" (her DM 2026-10-27 12:00). Tell Ilse only; DM info, not for channels or other members.