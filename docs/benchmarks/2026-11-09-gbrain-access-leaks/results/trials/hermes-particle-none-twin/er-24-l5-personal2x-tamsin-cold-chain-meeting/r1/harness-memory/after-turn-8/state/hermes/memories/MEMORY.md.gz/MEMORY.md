Standing calls told to me (no action requested): Tamsin Cold Chain/Larchmont rollout Thu 12:45 from 2026-10-14 (Ilse Varga); Quarrendon Freight Lines/Wicklow Thu 09:15 (Ilse Varga); Thornbury Cloth Co./Kittiwake Mon 14:15 (Ilse Varga); Brackenwater Freight Co./Elmstead Fri 11:45 (Ilse Varga); Tamsin Cold Chain/Cobble rollout Mon 13:45 from 2026-10-27 (Tobias Rendle, Central).
§
Tamsin Cold Chain/Hollybank rollout standing call: Fridays 11:30 from 2026-11-04 onward (per Dana Okafor, North team).
§
Tamsin Cold Chain/Keystone rollout standing call: Mondays 16:15 from 2026-11-08 onward (per Marcus Lindqvist, North team).