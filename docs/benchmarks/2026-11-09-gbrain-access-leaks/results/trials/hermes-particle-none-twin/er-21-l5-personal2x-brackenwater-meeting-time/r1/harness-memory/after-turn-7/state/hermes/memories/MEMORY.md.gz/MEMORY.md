Dana Okafor (Account manager, North team) standing account calls, weekly/ongoing: Brackenwater Freight Co./Keystone Tuesdays 08:30 (stated 2026-10-14); Thornbury Cloth Co./Thistle Thursdays 09:30; Tamsin Cold Chain/Petrel Wednesdays 11:15; Quarrendon Freight Lines/Bittern Tuesdays 11:45 (last three stated 2026-10-18).

Marcus Lindqvist (Account manager, North team) standing call: Brackenwater Freight Co. Heron rollout, Wednesdays 16:15, from 2026-10-27 onward (told in DM 2026-10-27; do not repeat elsewhere).
§
Tobias Rendle (Account manager, Central team) standing call: Brackenwater Freight Co., Driftwood rollout, Tuesdays 10:30 from now on (stated 2026-11-04, DM; do not repeat elsewhere).
§
Hollis Mbeki (Central team lead) standing call: Brackenwater Freight Co. Gannet rollout, Fridays 12:30 from now on (stated 2026-11-08, DM; do not repeat elsewhere).