Pemberline, Tobias Rendle (account manager, Central team): for Marrow Agrisupply pickups on the Cobble project his dock is Bay 38, per his correction of 2026-10-14 (customer changed it on the call; supersedes Gate 23 and the earlier Dock 45). Private to Tobias — don't repeat elsewhere.
§
Tobias Rendle's dock assignments (told in DM 2026-10-20, private to him — don't repeat elsewhere): Tansleigh Packaging pickups on the Halyard project = Gate 44; Marrow Fieldworks pickups on the Kestrel project = Bay 24.
§
Hollis Mbeki (Central team lead): dock he uses for Marrow Agrisupply pickups on the Sorrel project is Dock 33 from 2026-10-25 onward. Private to Hollis — don't repeat elsewhere.
§
Priyanka "Pree" Sundaram (account manager, Central team): dock she uses for Marrow Agrisupply pickups on the Wicklow project is Gate 45, from 2026-10-30 onward. Private to Priyanka — don't repeat elsewhere.