Dana Okafor (account manager, North team) paperwork cutoff dates: Thornbury Cloth Co./Wicklow renewal 27 September (superseded 26 Oct, 13 Dec and 5 Nov from earlier on 2026-10-14; already past when stated — flagged to her as possibly a mistake); Quarrendon Freight Lines/Saltire renewal 10 January; Tamsin Cold Chain/Nettle renewal 10 December; Brackenwater Freight Co./Cinder renewal 17 September (already past as of 2026-10-19 — flagged). All told in a DM; do not repeat outside her DM.
§
Marcus Lindqvist (North team) cutoff for Thornbury Cloth Co. paperwork on the Juniper renewal: 25 October, standing from 2026-10-27 onward. Told in his DM; don't repeat outside his DM. (25 Oct had already passed when he set it, so it applies to the next cycle.)
§
Ilse Varga (North team lead) cutoff for Thornbury Cloth Co. paperwork on the Jasper renewal: 25 January, standing from 2026-11-05 onward. Told in her DM; don't repeat outside her DM.
§
Marcus Lindqvist (North team) cutoff for Thornbury Cloth Co. paperwork on the Gannet renewal: 13 June, standing from 2026-11-09 onward. Told in his DM; don't repeat outside his DM.