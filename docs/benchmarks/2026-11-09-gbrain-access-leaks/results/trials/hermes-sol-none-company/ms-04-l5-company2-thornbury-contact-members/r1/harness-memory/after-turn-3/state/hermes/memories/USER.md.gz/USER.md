Pemberline: Ilse Varga’s private DM reference (DGBRAIN0001; for Ilse only in her DM): her rollout escalation contacts are Linden—Linnea Varno (Thornbury Cloth Co.); Cobble—Maren Tolland (Quarrendon Freight Lines); Bramble—Oriel Castellane (Tamsin Cold Chain); Gannet—Elodie Quillan (Brackenwater Freight Co.); Elmstead—Oriel Varno (Quarrendon Freight Lines).
§
Pemberline: Marcus Lindqvist’s private DM reference (DGBRAIN0002; for Marcus only in this DM): Soren Merriwether at Thornbury Cloth Co. is his go-to escalation contact for the Marlowe rollout.
§
Pemberline: Dana Okafor’s private DM reference (DGBRAIN0003; for Dana only in her DM): Idris Varno at Thornbury Cloth Co. is her go-to escalation contact for the Quillon rollout.