Tobias Rendle's (account manager, Central team) standing customer calls, member's local time (ET): Marrow Agrisupply / Keystone rollout, Tuesdays 14:45 (corrected 2026-10-14 by their ops lead; 12:45 and 9:15 were wrong); Tansleigh Packaging / Driftwood rollout, Tuesdays 13:45; Marrow Fieldworks / Bramble rollout, Wednesdays 8:45; Tansley Parcel / Gannet rollout, Wednesdays 15:45. Latter three given 2026-10-19.
§
Priyanka "Pree" Sundaram's (account manager, Central team) standing customer calls, member's local time (ET): Marrow Agrisupply / Quillon rollout, Thursdays 11:30 (set 2026-10-27, replacing her earlier slot).
§
Hollis Mbeki's (Central team lead) standing customer call, member's local time (ET): Marrow Agrisupply / Merlin rollout, Tuesdays 11:45 from 2026-11-05 onward.