Ilse Varga (North team lead, team-north) cutoff dates for account paperwork: Quarrendon Freight Lines / Greywater renewal = 9 January (as of 2026-10-14, per Finance's updated sheet; she had earlier said 11 January, 13 December, 25 December); Brackenwater Freight Co. / Thistle renewal = 3 July; Thornbury Cloth Co. / Driftwood renewal = 24 June; Tamsin Cold Chain / Nettle renewal = 24 January. Use these going forward.
§
Dana Okafor (account manager, North team) cutoff date for Quarrendon Freight Lines paperwork on the Brindle renewal: 8 June (stated 2026-10-27, "from now on"). Distinct from Ilse Varga's Quarrendon/Greywater renewal date.
§
Marcus Lindqvist (account manager, North team) cutoff date for Quarrendon Freight Lines paperwork on the Kestrel renewal: 20 August (stated 2026-11-05, "from now on").
§
Dana Okafor (account manager, North team) cutoff date for Quarrendon Freight Lines paperwork on the Heron renewal: 22 November (stated 2026-11-09, "from now on"). Separate from her Quarrendon/Brindle date (8 June).