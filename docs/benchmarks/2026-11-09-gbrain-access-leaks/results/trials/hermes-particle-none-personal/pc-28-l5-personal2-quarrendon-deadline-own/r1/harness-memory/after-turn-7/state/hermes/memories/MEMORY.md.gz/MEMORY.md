Ilse Varga (North team lead, team-north) set her cutoff date for the Quarrendon Freight Lines paperwork on the Greywater renewal to 9 January (her email 2026-10-14, per an updated sheet from Finance). Earlier figures: 11 January (Quarrendon ops lead, 2026-10-14) and 13 December — unresolved conflict with the ops lead's 11 January.
§
Ilse Varga's stated cutoff dates for renewals paperwork (told 2026-10-19 DM): Brackenwater Freight Co./Thistle = 3 July; Thornbury Cloth Co./Driftwood = 24 June; Tamsin Cold Chain/Nettle = 24 January. DM-only, not for other members' conversations.
§
Dana Okafor (North team AM): her cutoff date for the Quarrendon Freight Lines paperwork on the Brindle renewal is 8 June (told 2026-10-27 DM, "from now on"). DM-only, not for other members' conversations.