Standing calls — Hollis Mbeki (Central team lead): Marrow Agrisupply re: Ashgrove rollout — Mondays 15:15 (set 2026-10-27).

Standing calls — Pree Sundaram: Marrow Agrisupply re: Thistle rollout — Wednesdays 15:30 (confirmed 2026-10-14, supersedes earlier Friday 8:45, Wednesday 11:30, Tuesday 9:15). Marrow Fieldworks re: Quillon rollout — Thursdays 8:30. Tansleigh Packaging re: Merlin rollout — Mondays 9:45. Tansley Parcel re: Fernhill rollout — Mondays 13:30.
§
Standing call — Tobias Rendle (Central team, account manager): Marrow Agrisupply re: Nettle rollout — Thursdays 10:45, from 2026-11-05 onward.