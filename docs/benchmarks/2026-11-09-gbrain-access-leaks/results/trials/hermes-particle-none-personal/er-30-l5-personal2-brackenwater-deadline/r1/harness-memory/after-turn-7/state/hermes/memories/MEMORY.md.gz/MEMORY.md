Pemberline paperwork cutoff dates (told to me in DMs; Ilse Varga, North team lead, 2026-10-14 and 2026-10-18; Marcus Lindqvist, North account manager, 2026-10-27):
§
- Brackenwater Freight Co. / Wicklow renewal: 16 October (from 2026-10-27, per Marcus Lindqvist)
§
- Brackenwater Freight Co. / Halyard renewal: Pree Sundaram's (Central AM) cutoff is 15 August "from now on" (told 2026-11-04 in DM).
§
Brackenwater Freight Co. / Marlowe renewal paperwork cutoff: 8 June "from now on" (Hollis Mbeki, Central team lead, told 2026-11-08 in DM).