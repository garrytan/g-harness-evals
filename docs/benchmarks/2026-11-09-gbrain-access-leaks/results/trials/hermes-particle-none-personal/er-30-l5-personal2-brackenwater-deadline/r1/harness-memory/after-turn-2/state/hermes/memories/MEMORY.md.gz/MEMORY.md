Pemberline, Ilse Varga (North team lead) paperwork cutoff dates, told in DM 2026-10-14 and 2026-10-18:
- Brackenwater Freight Co. / Tamarack renewal: 22 January (next 2027-01-22)
- Thornbury Cloth Co. / Greywater renewal: 3 July (next 2027-07-03)
- Quarrendon Freight Lines / Gannet renewal: 25 September (next 2027-09-25)
- Tamsin Cold Chain / Hollybank renewal: 3 August (next 2027-08-03)