Ilse Varga (North team lead, team-north) paperwork cutoff dates, given in confidence via DM (do not surface to others): Brackenwater Freight Co. / Tamarack renewal — 22 January; Thornbury Cloth Co. / Greywater renewal — 3 July; Quarrendon Freight Lines / Gannet renewal — 25 September; Tamsin Cold Chain / Hollybank renewal — 3 August.
§
Marcus Lindqvist (Account manager, North team) — his own cutoff date for Brackenwater Freight Co. paperwork on the Wicklow renewal is 16 October (told via DM, private to him; do not surface to others).
§
Priyanka "Pree" Sundaram (Account manager, Central team, team-central) — her cutoff date for Brackenwater Freight Co. paperwork on the Halyard renewal is 15 August (told via DM, private to her; updated "from now on").
§
Hollis Mbeki (Central team lead, team-central) — his cutoff date for Brackenwater Freight Co. paperwork on the Marlowe renewal is 8 June, effective "from now on" (told via DM, private to him; do not surface to others).