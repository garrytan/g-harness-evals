Ilse Varga (North team lead, team-north) paperwork cutoffs, told 2026-10-18: Thornbury Cloth Co. on Kittiwake renewal — 9 March; Tamsin Cold Chain on Ironbridge renewal — 16 May; Brackenwater Freight Co. on Cinder renewal — 23 June; Quarrendon Freight Lines on Fernhill renewal — 4 January.
§
Hollis Mbeki (Central team lead, team-central) paperwork cutoff, told 2026-10-27: Thornbury Cloth Co. on Corvid renewal — 27 April.
§
Marcus Lindqvist (AM, North team, team-north) paperwork cutoff, told 2026-11-04: Thornbury Cloth Co. on Marlowe renewal — 3 July.
§
Tobias Rendle (AM, Central team, team-central) paperwork cutoff, told 2026-11-08: Thornbury Cloth Co. on Moorland renewal — 22 March.