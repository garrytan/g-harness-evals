Marcus Lindqvist (Pemberline, account manager, North team) pickup docks: Quarrendon Freight Lines on Ironbridge project = Gate 35; Thornbury Cloth Co. on Moorland project = Dock 31; Brackenwater Freight Co. on Cobble project = Door 24.
§
Priyanka "Pree" Sundaram (Pemberline, account manager, Central team) pickup dock: Tamsin Cold Chain on Jasper project = Gate 17.
§
Dana Okafor (Pemberline, account manager, North team) pickup dock: Tamsin Cold Chain on Sorrel project = Door 43.