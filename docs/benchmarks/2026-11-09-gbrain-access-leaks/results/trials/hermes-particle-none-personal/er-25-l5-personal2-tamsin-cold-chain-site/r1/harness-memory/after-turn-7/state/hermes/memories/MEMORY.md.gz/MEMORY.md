Marcus Lindqvist (North team, account manager): default dock for Tamsin Cold Chain pickups on the Wicklow project is Dock 36 (told 2026-10-14, "from now on").
§
Marcus Lindqvist (North team, account manager) dock assignments: Quarrendon Freight Lines pickups on Ironbridge project = Gate 35; Thornbury Cloth Co. pickups on Moorland project = Dock 31; Brackenwater Freight Co. pickups on Cobble project = Door 24 (told 2026-10-18). Plus earlier: Tamsin Cold Chain pickups on Wicklow project = Dock 36 (2026-10-14).
§
Priyanka "Pree" Sundaram (Central team, account manager): dock for Tamsin Cold Chain pickups on the Jasper project = Gate 17, from now on (told 2026-10-27).
§
Dana Okafor (North team, account manager): dock for Tamsin Cold Chain pickups on the Sorrel project = Door 43, from now on (told 2026-11-04).
§
Hollis Mbeki (Central team lead): dock for Tamsin Cold Chain pickups on the Larchmont project = Door 37, from now on (told 2026-11-08).