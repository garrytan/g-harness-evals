Marcus Lindqvist (Account manager, North team / team-north) standing calls, as he gave them: Tamsin Cold Chain / Gannet — Thursdays 08:15 local (stated 2026-10-19, supersedes his earlier Mondays 14:15, Wednesdays 11:15, Mondays 11:45); Thornbury Cloth Co. / Saltire — Mondays 10:30; Brackenwater Freight Co. / Linden — Mondays 16:15; Quarrendon Freight Lines / Keystone — Thursdays 09:45.
§
Dana Okafor (Account manager, North team / team-north) standing call: Tamsin Cold Chain team, Elmstead rollout — Wednesdays 12:15 (stated 2026-10-27).
§
Ilse Varga (North team lead) standing call: Tamsin Cold Chain team, Foxglove rollout — Tuesdays 08:45 from 2026-11-05 onward (stated 2026-11-05).