Pemberline, Marcus Lindqvist (Account manager, North team / team-north): standing call with the Tamsin Cold Chain team is Thursdays at 8:15 (recurring; set by the customer on the call, corrected by Marcus 2026-10-14). Supersedes earlier notes (Mondays 14:15, then Wednesdays 11:15).
§
Marcus Lindqvist's standing rollout calls (given 2026-10-19): Thornbury Cloth Co. / Saltire — Mondays 10:30; Brackenwater Freight Co. / Linden — Mondays 16:15; Quarrendon Freight Lines / Keystone — Thursdays 9:45.
§
Dana Okafor (Account manager, North team / team-north): her standing call with the Tamsin Cold Chain team for the Elmstead rollout is Wednesdays at 12:15, effective from now on (told 2026-10-27). Her own recurring slot — separate from Marcus Lindqvist's Tamsin Cold Chain call note.