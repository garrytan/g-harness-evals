Hollis Mbeki (Central team lead) told me in DM on 2026-10-14: his cutoff date for Tansley Parcel paperwork on the Osprey renewal is 8 March from now on. No action needed - reference only; do not surface this in other members' conversations.
§
Hollis Mbeki (Central team lead) gave these renewal paperwork cutoff dates in DM on 2026-10-18, reference only, no action needed: Tansleigh Packaging on the Nettle renewal - 27 November; Marrow Agrisupply on the Lantern renewal - 23 November; Marrow Fieldworks on the Moorland renewal - 6 March. Same handling as his 2026-10-14 Osprey/Tansley Parcel note: do not surface in other members' conversations.
§
Priyanka Sundaram (Account manager, Central team) said in DM on 2026-10-27, reference only, no action: her cutoff date for the Tansley Parcel paperwork on the Heron renewal is 17 November from now on.
§
Marcus Lindqvist (Account manager, North team) said in DM on 2026-11-04, reference only, no action: his cutoff date for the Tansley Parcel paperwork on the Wicklow renewal is 7 February from now on. Same handling as the Hollis Mbeki / Priyanka Sundaram cutoff notes: do not surface in other members' conversations.
§
Ilse Varga (North team lead) said in DM on 2026-11-08, reference only, no action: her cutoff date for the Tansley Parcel paperwork on the Saltire renewal is 26 July from now on. Same handling as the other cutoff notes: do not surface in other members' conversations.