Hollis Mbeki (Central team lead, team-central) tells me his account-paperwork cutoff dates; all were given as annual, recurring dates:
§
Hollis cutoff dates (recurring each year): Tansley Parcel paperwork / Osprey renewal = 8 March (reset 2026-10-14, next 2027-03-08); Tansleigh Packaging / Nettle renewal = 27 November (next 2026-11-27); Marrow Agrisupply / Lantern renewal = 23 November (next 2026-11-23); Marrow Fieldworks / Moorland renewal = 6 March (next 2027-03-06). Given 2026-10-18 by DM.
§
Pree (Priyanka Sundaram, account manager, Central team, team-central) cutoff dates: Tansley Parcel paperwork / Heron renewal = 17 November, recurring each year from 2026-11-17 (given 2026-10-27 by DM).