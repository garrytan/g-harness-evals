Dana Okafor's paperwork cutoff dates (account / renewal): Thornbury Cloth Co. / Wicklow — 27 September (set 2026-10-14, superseding 26 Oct, 13 Dec, 5 Nov); Quarrendon Freight Lines / Saltire — 10 January; Tamsin Cold Chain / Nettle — 10 December; Brackenwater Freight Co. / Cinder — 17 September.
§
Marcus Lindqvist's paperwork cutoff dates: Thornbury Cloth Co. / Juniper renewal — 25 October (set 2026-10-27); Thornbury Cloth Co. / Gannet renewal — 13 June (set 2026-11-09, future reference).
§
Ilse Varga's paperwork cutoff dates: Thornbury Cloth Co. / Jasper renewal — 25 January (stated 2026-11-05, future reference).