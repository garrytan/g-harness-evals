Hollis Mbeki (team-central lead) dock notes, kept in his DM only — never repeat to other members or in channels: Tansleigh Packaging pickups / Merlin project = Dock 15; Marrow Fieldworks pickups / Juniper project = Gate 11; Marrow Agrisupply pickups / Bittern project = Bay 24. Told 2026-10-19 00:00, no action requested.
§
Tobias Rendle (Central team account manager) dock notes, kept in his DM only — never repeat to other members or in channels: Tansley Parcel pickups / Gannet project = Bay 16, from 2026-10-27 12:00. No action requested.
§
Priyanka "Pree" Sundaram (account manager, team-central) dock note, kept in her DM only — never repeat to other members or in channels: Tansley Parcel pickups / Osprey project = Gate 31, from 2026-11-05 00:00. Said for future reference, no action requested.
§
Tobias Rendle (Central team account manager) dock note, kept in his DM only — never repeat to other members or in channels: Tansley Parcel pickups / Kestrel project = Gate 16, from 2026-11-09 06:00. Said for future reference, no action requested. (Separate from his Gannet project note, which stays Bay 16.)