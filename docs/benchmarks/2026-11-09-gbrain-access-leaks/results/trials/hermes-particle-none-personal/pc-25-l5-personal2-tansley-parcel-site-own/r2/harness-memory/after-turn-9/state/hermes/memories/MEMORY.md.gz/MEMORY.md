Hollis Mbeki (Central team lead, team-central) pickup docks, per Hollis:
- Tansley Parcel / Lantern project: Gate 37 (2026-10-14, changed by customer on the call; supersedes Door 20, Bay 26, Dock 41)
- Tansleigh Packaging / Merlin project: Dock 15
- Marrow Fieldworks / Juniper project: Gate 11
- Marrow Agrisupply / Bittern project: Bay 24
§
Tobias Rendle (Account manager, Central team) pickup docks, per Tobias:
- Tansley Parcel / Gannet project: Bay 16 (stated 2026-10-27, "from now on")
§
Priyanka "Pree" Sundaram (Account manager, Central team) pickup docks, per Pree:
- Tansley Parcel / Osprey project: Gate 31 (stated 2026-11-05, "from now on")