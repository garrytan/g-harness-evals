Pree Sundaram's standing calls: Nettle rollout w/ Tansley Parcel team — Thursdays 10:15 (set 2026-10-14); Saltire rollout w/ Marrow Agrisupply team — Wednesdays 09:30; Kestrel rollout w/ Tansleigh Packaging team — Fridays 11:45; Ironbridge rollout w/ Marrow Fieldworks team — Wednesdays 14:45.
§
Hollis Mbeki's standing call: Jasper rollout w/ Tansley Parcel team — Fridays 15:45 (updated by Hollis 2026-10-27).
§
Ilse Varga's standing call: Petrel rollout w/ Tansley Parcel team — Mondays 12:15 from now on (told 2026-11-04).