Pree Sundaram's standing calls: Tansley Parcel/Nettle Thursdays 10:15; Marrow Agrisupply/Saltire Wednesdays 9:30; Tansleigh Packaging/Kestrel Fridays 11:45; Marrow Fieldworks/Ironbridge Wednesdays 14:45.
§
Hollis Mbeki (Central team lead): standing call with Tansley Parcel team re Jasper rollout — Fridays 15:45 (changed as of 2026-10-27).
§
Ilse Varga (North team lead): standing call with the Tansley Parcel team re Petrel rollout — Mondays 12:15 (as of 2026-11-04).