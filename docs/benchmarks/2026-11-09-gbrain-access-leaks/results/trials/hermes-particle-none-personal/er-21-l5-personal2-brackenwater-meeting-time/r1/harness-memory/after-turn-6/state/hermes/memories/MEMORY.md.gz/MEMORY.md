Dana Okafor (Account manager, North team): standing call with Brackenwater Freight Co. team re: Keystone rollout is weekly, Tuesdays 8:30 (local), effective from 2026-10-14. Dana asked me to remember this.
§
Dana Okafor (Account manager, North team) — more standing calls she asked me to remember (told 2026-10-18): Thornbury Cloth Co. team re: Thistle rollout, Thursdays 9:30 (next 2026-10-22); Tamsin Cold Chain team re: Petrel rollout, Wednesdays 11:15 (next 2026-10-21); Quarrendon Freight Lines team re: Bittern rollout, Tuesdays 11:45 (next 2026-10-20).
§
Marcus Lindqvist (Account manager, North team) — told me 2026-10-27: his standing call with the Brackenwater Freight Co. team re: Heron rollout is Wednesdays 16:15 (local) from now on (next: 2026-10-28). Asked me to remember; no calendar action requested. Separate from the Keystone call Dana tracks.
§
Tobias Rendle (Account manager, Central team) — told me 2026-11-04: his standing call with the Brackenwater Freight Co. team re: Driftwood rollout is Tuesdays 10:30 (local) from now on. Asked me to remember; no action requested.