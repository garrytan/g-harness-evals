Dana Okafor (Account manager, North team) — standing call with the Thornbury Cloth Co. team, Cobble rollout: Tuesdays 09:30, from 2026-10-27 onward. Told in a DM; private to Dana, don't repeat elsewhere.
§
Ilse Varga (North team lead) — standing call with the Thornbury Cloth Co. team, Corvid rollout: Thursdays 13:45 from 2026-11-04 onward. Told in a DM; private to Ilse, don't repeat elsewhere.