Marcus Lindqvist (account manager, North team) standing calls, as of 2026-10-18, no calendar action wanted: Thornbury Cloth Co./Keystone rollout Fridays 16:45; Tamsin Cold Chain/Lantern rollout Mondays 9:15; Brackenwater Freight Co./Cinder rollout Fridays 16:15; Quarrendon Freight Lines/Sorrel rollout Thursdays 11:15. Times are his local (America/Chicago, UTC-5).
§
Dana Okafor (account manager, North team, team-north) standing call, per her DM 2026-10-27: Thornbury Cloth Co./Cobble rollout Tuesdays 09:30 her local time (UTC-5) — supersedes earlier Cobble timing. No calendar action wanted.
§
Ilse Varga (North team lead, team-north) standing call, per her DM 2026-11-04: Thornbury Cloth Co./Corvid rollout Thursdays 13:45 her local time (UTC-5), from now on. No calendar action wanted.