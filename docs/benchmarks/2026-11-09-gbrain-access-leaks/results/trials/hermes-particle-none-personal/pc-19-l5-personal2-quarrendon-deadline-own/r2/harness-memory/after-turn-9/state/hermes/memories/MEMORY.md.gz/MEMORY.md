Dana Okafor (account manager, North team) paperwork cutoff dates: Quarrendon Freight Lines / Nettle renewal = 26 March (her 14 Oct 2026 correction; supersedes all earlier values incl. 7 May, 13 May, 10 Aug); Brackenwater Freight Co. / Cobble renewal = 5 November; Thornbury Cloth Co. / Fernhill renewal = 12 October; Tamsin Cold Chain / Halyard renewal = 4 June (latter three told 19 Oct 2026, "future reference").
§
Marcus Lindqvist (account manager, North team) paperwork cutoff dates: Quarrendon Freight Lines / Moorland renewal = 24 April (told 27 Oct 2026, "from now on").
§
Ilse Varga (North team lead, team-north) paperwork cutoff date: Quarrendon Freight Lines / Quillon renewal = 24 December (told 5 Nov 2026, "from now on").