Dana Okafor (Account manager, North team) paperwork cutoff dates: Quarrendon Freight Lines / Nettle renewal = 26 March (Dana's correction, 2026-10-14, after the customer changed it on the call; supersedes her earlier 7 May, 13 May and 10 August dates); Brackenwater Freight Co. / Cobble renewal = 5 November; Thornbury Cloth Co. / Fernhill renewal = 12 October; Tamsin Cold Chain / Halyard renewal = 4 June.
§
Marcus Lindqvist (Account manager, North team) paperwork cutoff dates: Quarrendon Freight Lines / Moorland renewal = 24 April (set 2026-10-27; supersedes any earlier date for that renewal).
§
Ilse Varga (North team lead) paperwork cutoff date: Quarrendon Freight Lines / Quillon renewal = 24 December (set 2026-11-05, no action requested).