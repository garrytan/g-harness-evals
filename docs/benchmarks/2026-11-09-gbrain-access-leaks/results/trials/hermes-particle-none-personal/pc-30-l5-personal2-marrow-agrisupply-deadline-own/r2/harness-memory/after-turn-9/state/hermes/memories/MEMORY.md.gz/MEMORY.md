Pree Sundaram (Priyanka Sundaram, account manager, Central team) paperwork cutoff dates: Brindle renewal / Marrow Agrisupply 10 October (her correction 2026-10-14, superseding 3 April / 21 April); Wicklow renewal / Tansleigh Packaging 24 December; Gannet renewal / Marrow Fieldworks 3 June; Saltire renewal / Tansley Parcel 9 December.
§
Tobias Rendle (account manager, Central team) paperwork cutoff date: Marrow Agrisupply paperwork on the Thistle renewal — 7 July (told 2026-10-27, his own cutoff; distinct from Pree Sundaram's Marrow Agrisupply/Brindle entry).
§
Hollis Mbeki (Central team lead) paperwork cutoff date: Marrow Agrisupply paperwork on the Ironbridge renewal — 7 November (told 2026-11-05).