Tobias Rendle (account manager, Central team) paper cutoff dates stated in DM: Brindle renewal / Marrow Fieldworks — 5 March (superseding his earlier 7 June, 17 May and 20 May figures; the customer changed it on the call); Kestrel renewal / Tansleigh Packaging — 25 June; Cinder renewal / Marrow Agrisupply — 18 August; Juniper renewal / Tansley Parcel — 12 July.
§
Priyanka "Pree" Sundaram (account manager, Central team) — Petrel renewal / Marrow Fieldworks paperwork cutoff date: 25 December (she set this as her standing cutoff, stated 27 Oct 2026).
§
Hollis Mbeki (Central team lead, team-central) — Bittern renewal / Marrow Fieldworks paperwork cutoff date: 22 January (his standing cutoff, stated 5 Nov 2026).