Tobias Rendle (Account manager, Central team) set the cutoff date for the Marrow Fieldworks paperwork on the Brindle renewal to 5 March (his 4th correction on 2026-10-14; earlier 17 May, 7 June and 20 May were all wrong). Told to me in DM DGBRAIN0001; do not repeat elsewhere.
§
Tobias Rendle's cutoff dates for renewal paperwork, told to me in DM DGBRAIN0001 (keep private, do not repeat elsewhere): Tansleigh Packaging on the Kestrel renewal = 25 June; Marrow Agrisupply on the Cinder renewal = 18 August; Tansley Parcel on the Juniper renewal = 12 July. Stated 2026-10-19, no action needed.
§
Priyanka "Pree" Sundaram (Account manager, Central team) gave me, in DM DGBRAIN0002 on 2026-10-27, her cutoff date for the Marrow Fieldworks paperwork on the Petrel renewal: 25 December, effective from then on. Private to that DM; do not repeat elsewhere.
§
Hollis Mbeki (Central team lead) told me in DM DGBRAIN0003 on 2026-11-05, for future reference only: his cutoff date for the Marrow Fieldworks paperwork on the Bittern renewal is 22 January, from now on. Private to that DM; do not repeat elsewhere.