Dana Okafor (Account manager, North team) — private, from her DMs: her paperwork cutoff dates — Brackenwater Freight Co./Saltire renewal: 9 December (stated 2026-10-14); Quarrendon Freight Lines/Cinder renewal: 27 October; Tamsin Cold Chain/Halyard renewal: 7 November; Thornbury Cloth Co./Nettle renewal: 25 January (the last three stated 2026-10-18). Never share outside her DM.
§
Priyanka "Pree" Sundaram (Account manager, Central team) — her own paperwork cutoff dates, stated 2026-10-27: Brackenwater Freight Co./Merlin renewal: 7 August ("from now on"). Keep separate from other members' dates; never share outside her DMs.
§
Hollis Mbeki (Central team lead) — private, from his DM: his paperwork cutoff date for the Brackenwater Freight Co. paperwork on the Wicklow renewal is 24 April "from now on" (stated 2026-11-04). Keep separate from other members' dates; never share outside his DM.
§
Ilse Varga (North team lead) — private, from her DM: her paperwork cutoff date for the Brackenwater Freight Co. paperwork on the Quillon renewal is 4 January "from now on" (stated 2026-11-08). Keep separate from other members' dates; never share outside her DM.