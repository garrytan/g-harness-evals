Hollis Mbeki's paperwork cutoff dates (told to me in his DM; private, do not surface in channels): Tansley Parcel on Quillon renewal = 5 June (corrected by Hollis in DM 2026-10-14; he had read the wrong line; supersedes earlier dates); Marrow Agrisupply on Cobble renewal = 26 November; Tansleigh Packaging on Wicklow renewal = 21 December; Marrow Fieldworks on Heron renewal = 3 May.
§
Priyanka "Pree" Sundaram's paperwork cutoff dates (told to me in her DM; private, do not surface in channels): Tansley Parcel on Thistle renewal = 20 August (set 2026-10-27, "from now on").
§
Tobias Rendle's paperwork cutoff dates (told to me in his DM; private, do not surface in channels): Tansley Parcel on Greywater renewal = 9 November (set 2026-11-05, "from now on").