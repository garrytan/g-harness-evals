Ilse Varga (North team lead, team-north), paperwork cutoff dates: Tamsin Cold Chain / Fernhill renewal 7 Nov; Quarrendon Freight Lines / Brindle renewal 10 Jan; Brackenwater Freight Co. / Cinder renewal 27 Sep; Thornbury Cloth Co. / Hollybank renewal 13 Sep.
§
Hollis Mbeki (Central team lead, team-central) paperwork cutoff: Tamsin Cold Chain / Jasper renewal is 23 February (updated 27 Oct 2026; supersedes any earlier date).
§
Marcus Lindqvist (North team account manager, team-north) paperwork cutoff: Tamsin Cold Chain / Juniper renewal is 18 June (told 4 Nov 2026).
§
Priyanka "Pree" Sundaram (Central team account manager, team-central) paperwork cutoff: Tamsin Cold Chain / Saltire renewal is 10 September (told 8 Nov 2026; effective from now on).