Pree (Priyanka Sundaram, account manager, team-central) go-to escalation contacts: Lantern/Tansley Parcel — Oriel Tolland (from 2026-10-14 onward, replaces prior contact); Marlowe/Marrow Fieldworks — Idris Brevik; Bittern/Marrow Agrisupply — Bram Castellane; Corvid/Tansleigh Packaging — Elodie Quillan.
§
Marcus Lindqvist (account manager, team-north) escalation contact at Tansley Parcel for the Wicklow rollout: Tamsyn Quillan, as of 2026-10-27. Distinct from Pree's Tansley contact (Oriel Tolland) — keep member-specific.
§
Tobias Rendle (account manager, team-central) escalation contact at Tansley Parcel for the Thistle rollout: Linnea Quillan, as of 2026-11-04.