Ilse Varga (North team lead, team-north) standing calls: Quarrendon Freight Lines / Wicklow rollout — Thursdays 09:15; Thornbury Cloth Co. / Kittiwake rollout — Mondays 14:15; Brackenwater Freight Co. / Elmstead rollout — Fridays 11:45. All recurring, 'future reference' only, no calendar invites requested.
§
Tobias Rendle (account manager, Central team, team-central) standing call: Tamsin Cold Chain / Cobble rollout — Mondays 13:45, effective from 2026-10-27. Told to me in DM for future reference only; no calendar invite requested.
§
Dana Okafor (account manager, North team, team-north) standing call: Tamsin Cold Chain / Hollybank rollout — Fridays 11:30, effective from 2026-11-04. Told to me in DM for future reference only; no calendar invite requested.