Ilse Varga (North team lead, team-north): standing call with the Tamsin Cold Chain team for the Larchmont rollout is Thursdays at 12:45, starting from 2026-10-14 onward.
§
Ilse's other standing rollout calls: Quarrendon Freight Lines team / Wicklow rollout — Thursdays 9:15; Thornbury Cloth Co. team / Kittiwake rollout — Mondays 14:15; Brackenwater Freight Co. team / Elmstead rollout — Fridays 11:45.
§
Tobias Rendle (Account manager, Central team / team-central) standing call: Tamsin Cold Chain team / Cobble rollout — Mondays 13:45, from 2026-10-27 onward.