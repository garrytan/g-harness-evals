Dana Okafor (Account manager, North team / team-north) standing call: Tamsin Cold Chain team / Hollybank rollout — Fridays 11:30, from 2026-11-04 onward.
§
Marcus Lindqvist (Account manager, North team / team-north) standing call: Tamsin Cold Chain team / Keystone rollout — Mondays 16:15, from 2026-11-09 onward.