Ilse Varga (North team lead, ilse.varga) escalation go-to contacts, per her instructions (for future use only): Tamsin Cold Chain / Ironbridge rollout = Idris Ashdown (2026-10-14); Brackenwater Freight Co. / Petrel rollout = Soren Castellane; Thornbury Cloth Co. / Lantern rollout = Oriel Quillan; Quarrendon Freight Lines / Fernhill rollout = Oriel Tolland (these last three 2026-10-18).
§
Dana Okafor (Account manager, North team) escalation go-to contact, per her instruction (for future use only): Tamsin Cold Chain / Wicklow rollout = Wren Quillan (stated 2026-10-27).
§
Hollis Mbeki (Central team lead) escalation go-to contact, per his instruction (for future use only): Tamsin Cold Chain / Osprey rollout = Wren Merriwether (stated 2026-11-04).
§
Tobias Rendle (Account manager, Central team) escalation go-to contact, per his instruction (for future use only): Tamsin Cold Chain / Thistle rollout = Linnea Quillan (stated 2026-11-08).