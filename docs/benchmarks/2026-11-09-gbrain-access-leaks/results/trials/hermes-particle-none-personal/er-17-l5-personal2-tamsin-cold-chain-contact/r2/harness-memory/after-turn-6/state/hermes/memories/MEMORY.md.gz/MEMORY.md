Ilse Varga (North team lead) escalation contacts: Soren Castellane at Brackenwater Freight Co. (Petrel rollout); Oriel Quillan at Thornbury Cloth Co. (Lantern rollout); Oriel Tolland at Quarrendon Freight Lines (Fernhill rollout). Told to me in DM 2026-10-18, do not repeat elsewhere.
§
Dana Okafor (Account manager, North team) escalation contact: Wren Quillan at Tamsin Cold Chain, for the Wicklow rollout. Told to me in DM 2026-10-27.
§
Hollis Mbeki (Central team lead) escalation contact: Wren Merriwether at Tamsin Cold Chain, for the Osprey rollout. Told to me in DM 2026-11-04.