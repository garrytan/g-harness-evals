Tobias Rendle's escalation contacts (given 2026-10-19): Tansleigh Packaging/Kestrel rollout → Maren Castellane; Marrow Fieldworks/Quillon rollout → Elodie Brevik; Marrow Agrisupply/Lantern rollout → Tamsyn Ashdown.
§
Hollis Mbeki (Central team lead): escalation contact at Tansley Parcel for the Jasper rollout is Elodie Ashdown (told me 2026-10-27, "from now on").