Hollis Mbeki's escalation contacts (per his own instructions): Tansley Parcel / Jasper rollout -> Elodie Ashdown (2026-10-27); Tansley Parcel / Cobble rollout -> Elodie Merriwether (2026-11-09).
§
Priyanka "Pree" Sundaram's escalation contact (per her own instruction, 2026-11-05): Tansley Parcel / Larchmont rollout -> Oriel Tolland, from now on.
§
Tobias Rendle's escalation contacts (per his own instructions, 2026-10-19): Tansley Parcel / Gannet rollout -> Soren Castellane (corrected 2026-10-14 by their ops lead); Tansleigh Packaging / Kestrel rollout -> Maren Castellane; Marrow Fieldworks / Quillon rollout -> Elodie Brevik; Marrow Agrisupply / Lantern rollout -> Tamsyn Ashdown.