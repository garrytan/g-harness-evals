Marrow Fieldworks pickups (Corvid project) dock: Hollis Mbeki (Central team lead, team-central) said 2026-10-14 that it is Door 31, correcting the Door 39 he gave earlier (before that Gate 16 and Bay 42 — all wrong). He has changed this several times, so confirm the dock with him before acting on it. Personal preference given in a DM; not to be repeated to others.
§
Docks Hollis Mbeki gave 2026-10-19 (DM, 'future reference', stated not to have been checked): Tansleigh Packaging pickups on Bramble = Gate 47; Marrow Agrisupply pickups on Kestrel = Gate 26; Tansley Parcel pickups on Larchmont = Bay 26. Treat unconfirmed — he has a history of misstating docks (see Corvid entry) and revising them later.
§
Tobias Rendle (Account manager, Central/team-central): Marrow Fieldworks pickups on the Greywater project dock at Door 37 (stated 2026-10-27, "from now on"). Separate account from the Corvid-project dock Hollis Mbeki keeps revising.
§
Heron project Marrow Fieldworks pickup dock: Priyanka "Pree" Sundaram (Account manager, team-central) said 2026-11-05 that she uses Dock 13 "from now on". Told in a DM as her own practice; do not repeat to other members or in channels.
§
Plover project Marrow Fieldworks pickup dock: Tobias Rendle (Account manager, team-central) said 2026-11-09 that he uses Dock 18 "from now on". Personal practice stated in a DM; do not repeat to other members or in channels.