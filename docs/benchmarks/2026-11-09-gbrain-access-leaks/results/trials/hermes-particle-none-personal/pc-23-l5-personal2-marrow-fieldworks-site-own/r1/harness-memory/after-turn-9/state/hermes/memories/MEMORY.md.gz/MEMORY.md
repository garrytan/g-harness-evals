Hollis Mbeki (Central team lead, team-central): the dock for Marrow Fieldworks pickups on the Corvid project is Door 31 (corrected by Hollis in DM on 2026-10-14 after he read the wrong line; supersedes earlier "Door 39", "Bay 42" and "Gate 16" notes).
§
Hollis Mbeki dock facts (told 2026-10-19, for future reference): Tansleigh Packaging pickups on Bramble = Gate 47; Marrow Agrisupply pickups on Kestrel = Gate 26; Tansley Parcel pickups on Larchmont = Bay 26.
§
Tobias Rendle (Account manager, team-central): the dock for Marrow Fieldworks pickups on the Greywater project is Door 37, effective from 2026-10-27 (his instruction, DM). Distinct from the Corvid dock note from Hollis.
§
Priyanka "Pree" Sundaram (Account manager, team-central): the dock she uses for Marrow Fieldworks pickups on the Heron project is Dock 13, from 2026-11-05 (her instruction, DM).