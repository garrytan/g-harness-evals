Priyanka "Pree" Sundaram (Account manager, Central team, team-central) — paperwork cutoff dates (standing instructions): Tansley Parcel / Tamarack renewal = 6 September; Marrow Fieldworks / Quillon renewal = 20 September; Tansleigh Packaging / Saltire renewal = 12 December; Marrow Agrisupply / Halyard renewal = 13 August. Ilse Varga (North team lead, team-north) — Tansley Parcel paperwork, Fernhill renewal cutoff = 7 June (stated 27 Oct 2026).
§
Hollis Mbeki (Central team lead, team-central) — Tansley Parcel paperwork on the Hollybank renewal: cutoff 21 October (stated 4 Nov 2026, "from now on").
§
Marcus Lindqvist (Account manager, North team, team-north) — Tansley Parcel paperwork on the Sorrel renewal: cutoff 21 July, "from now on" (stated 8 Nov 2026).