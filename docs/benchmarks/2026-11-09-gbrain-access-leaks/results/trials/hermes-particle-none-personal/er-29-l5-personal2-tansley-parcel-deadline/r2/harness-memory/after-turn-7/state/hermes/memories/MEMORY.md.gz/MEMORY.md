Pemberline workspace — Priyanka "Pree" Sundaram (account manager, team-central): her paperwork cutoff dates (told to me in DM; personal deadlines, not to be shared into channels): Tansley Parcel / Tamarack renewal — 6 September (standing from 2026-10-14); Marrow Fieldworks / Quillon renewal — 20 September; Marrow Agrisupply / Halyard renewal — 13 August; Tansleigh Packaging / Saltire renewal — 12 December.
§
Ilse Varga (North team lead, team-north) — her paperwork cutoff date for the Tansley Parcel documents on the Fernhill renewal: 7 June (standing from 2026-10-27). Told to me in DM; personal deadline, not to be shared into channels.
§
Hollis Mbeki (Central team lead, team-central) — his paperwork cutoff date for the Tansley Parcel paperwork on the Hollybank renewal: 21 October (standing from 2026-11-04). Told to me in DM; personal deadline, not to be shared into channels.
§
Marcus Lindqvist (North team account manager, team-north) — his paperwork cutoff date for the Tansley Parcel paperwork on the Sorrel renewal: 21 July (standing from 2026-11-08). Told to me in DM; personal deadline, not to be shared into channels.