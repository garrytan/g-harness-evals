Tobias Rendle (Account manager, Central team @ Pemberline) standing rollout calls: Marrow Fieldworks/Saltire Mondays 13:30 (weekly from 2026-10-14); Tansleigh Packaging/Ironbridge Mondays 08:30; Tansley Parcel/Moorland Mondays 12:45; Marrow Agrisupply/Merlin Wednesdays 13:45.
§
Dana Okafor (Account manager, North team @ Pemberline) standing call: Marrow Fieldworks / Linden rollout Mondays 16:15 (as of 2026-10-27).
§
Hollis Mbeki (Central team lead @ Pemberline) standing call: Marrow Fieldworks / Corvid rollout Tuesdays 14:45 (as of 2026-11-04).