Tobias Rendle (account manager, Central team) standing calls:
- Marrow Fieldworks / Saltire rollout: Mondays 13:30, from 2026-10-14 onward
- Tansleigh Packaging / Ironbridge rollout: Mondays 08:30
- Tansley Parcel / Moorland rollout: Mondays 12:45
- Marrow Agrisupply / Merlin rollout: Wednesdays 13:45
§
Dana Okafor (account manager, North team) standing call: Marrow Fieldworks / Linden rollout — Mondays 16:15 (as of 2026-10-27, ongoing).
§
Hollis Mbeki (Central team lead) standing call: Marrow Fieldworks / Corvid rollout — Tuesdays 14:45, from 2026-11-04 onward.
§
Ilse Varga (North team lead) standing call: Marrow Fieldworks / Gannet rollout — Thursdays 11:15, from 2026-11-08 onward.