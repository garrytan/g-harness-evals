Tobias Rendle (account manager, Central team) standing calls:
- Marrow Fieldworks / Saltire rollout: Mondays 13:30, from 2026-10-14 onward
- Tansleigh Packaging / Ironbridge rollout: Mondays 08:30
- Tansley Parcel / Moorland rollout: Mondays 12:45
- Marrow Agrisupply / Merlin rollout: Wednesdays 13:45