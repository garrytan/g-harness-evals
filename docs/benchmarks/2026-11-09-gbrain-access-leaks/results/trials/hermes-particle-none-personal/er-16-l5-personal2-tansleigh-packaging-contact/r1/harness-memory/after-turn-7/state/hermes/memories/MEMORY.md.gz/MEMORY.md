Priyanka "Pree" Sundaram (account manager, Central team): escalation contact at Tansleigh Packaging for the Saltire rollout is Linnea Tolland (as of Oct 2026, replaces prior go-to).
§
Priyanka "Pree" Sundaram (account manager, Central team) escalation go-tos: Marrow Fieldworks / Petrel rollout = Maren Varno; Marrow Agrisupply / Larchmont rollout = Wren Varno; Tansley Parcel / Bramble rollout = Tamsyn Quillan (as of Oct 2026).
§
Hollis Mbeki (Central team lead): Tansleigh Packaging escalation go-to for the Thistle rollout = Linnea Merriwether (as of Oct 2026).
§
Dana Okafor (account manager, North team): Tansleigh Packaging escalation go-to for the Corvid rollout = Maren Merriwether (as of Nov 2026).
§
Ilse Varga (North team lead): Tansleigh Packaging escalation go-to for the Marlowe rollout = Idris Ashdown (as of Nov 2026).