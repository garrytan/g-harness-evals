Pree (Priyanka Sundaram) — Central team AM. Her escalation contacts (told to me in DM; do not share with other members): Tansleigh Packaging / Saltire rollout — Linnea Tolland (2026-10-14); Marrow Fieldworks / Petrel rollout — Maren Varno; Marrow Agrisupply / Larchmont rollout — Wren Varno; Tansley Parcel / Bramble rollout — Tamsyn Quillan (all 2026-10-18).
§
Hollis Mbeki (Central team lead) — escalation contact for Tansleigh Packaging on the Thistle rollout: Linnea Merriwether, from 2026-10-27 onward.
§
Dana Okafor (North team AM) — her escalation contact at Tansleigh Packaging for the Corvid rollout: Maren Merriwether, from 2026-11-04 onward.
§
Ilse Varga (North team lead) — escalation contact at Tansleigh Packaging for the Marlowe rollout: Idris Ashdown, from 2026-11-08 onward.