Thornbury Cloth Co. (Petrel rollout) - Soren Merriwether, Marcus Lindqvist's go-to escalation contact (superseded Elodie Quillan, 2026-10-24)
§
Ilse Varga (North lead) DMs: Brackenwater Freight Co. (Halyard) - Tamsyn Quillan; Quarrendon Freight Lines (Lantern) - Maren Varno (2026-10-19).