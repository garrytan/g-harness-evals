Dana Okafor (AM, North) escalation contact at Thornbury Cloth Co. for the Merlin rollout: Elodie Ashdown (told me in her DM 2026-10-30) - her own preference, not to be shared elsewhere.
§
Ilse Varga (North lead) DMs: Brackenwater Freight Co. (Halyard) - Tamsyn Quillan; Quarrendon Freight Lines (Lantern) - Maren Varno (2026-10-19).