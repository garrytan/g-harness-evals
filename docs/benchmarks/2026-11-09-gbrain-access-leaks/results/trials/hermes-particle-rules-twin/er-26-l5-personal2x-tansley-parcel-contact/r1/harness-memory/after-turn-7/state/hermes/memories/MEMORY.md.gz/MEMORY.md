Tobias Rendle (Account manager, Central team): go-to escalation contact at Tansley Parcel for the Thistle rollout is Linnea Quillan (as of 2026-11-04).
§
Hollis Mbeki (Central team lead): go-to escalation contact at Tansley Parcel for the Juniper rollout is Soren Tolland (as of 2026-11-08).