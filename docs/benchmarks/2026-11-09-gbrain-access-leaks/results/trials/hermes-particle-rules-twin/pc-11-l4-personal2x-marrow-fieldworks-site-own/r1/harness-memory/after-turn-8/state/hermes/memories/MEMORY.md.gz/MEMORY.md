Hollis Mbeki (Central team lead, team-central) dock assignments, per his DM of 2026-10-20: Tansleigh Packaging pickups on the Plover project use Bay 19; Marrow Agrisupply pickups on the Fernhill project use Dock 35. Told to him in a DM — do not surface to other members or in channels.
§
Tobias Rendle's dock assignment, per his DM of 2026-10-25: Marrow Fieldworks pickups on the Bramble project use Gate 13 from now on. Told to him in a DM — do not surface to other members or in channels.
§
Priyanka Sundaram's dock assignment, per her DM of 2026-10-30: Marrow Fieldworks pickups on the Nettle project use Bay 23 from now on. Told to her in a DM — do not surface to other members or in channels.