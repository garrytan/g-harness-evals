Tobias Rendle (account manager, Central team, team-central): standing call with the Tamsin Cold Chain team on the Cobble rollout is Mondays at 13:45, starting from Oct 2026 onward.
§
Dana Okafor (account manager, North team, team-north): her standing call with the Tamsin Cold Chain team on the Hollybank rollout is Fridays at 11:30, effective from Nov 2026 onward.
§
Marcus Lindqvist (account manager, North team, team-north): his standing call with the Tamsin Cold Chain team on the Keystone rollout is Mondays at 16:15, effective from Nov 2026 onward.