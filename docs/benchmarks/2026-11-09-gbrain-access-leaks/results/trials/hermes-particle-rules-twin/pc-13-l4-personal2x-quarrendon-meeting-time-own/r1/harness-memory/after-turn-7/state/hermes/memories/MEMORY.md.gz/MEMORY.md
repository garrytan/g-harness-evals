Dana Okafor (Account manager, North team, team-north): standing call with Quarrendon Freight Lines (Gannet rollout) is Tuesdays 15:30, per her correction on 2026-10-14 18:00 after QFL's ops lead corrected her; supersedes the earlier 9:45, 14:30 and 12:45 times she gave that day.
§
Dana Okafor (Account manager, North team): standing calls — Thornbury Cloth Co. (Lantern rollout) Fridays 16:45; Brackenwater Freight Co. (Sorrel rollout) Fridays 13:30, per her DMs of 2026-10-20.
§
Marcus Lindqvist (Account manager, North team): standing call with Quarrendon Freight Lines for the Moorland rollout is Mondays 12:30 "from now on", per his DM of 2026-10-25 06:00. (Separate from Dana Okafor's Tuesday 15:30 QFL/Gannet call.)
§
Ilse Varga (North team lead, team-north): standing call with Quarrendon Freight Lines for the Tamarack rollout is Thursdays 13:15 "from now on", per her DM of 2026-10-30 12:00.