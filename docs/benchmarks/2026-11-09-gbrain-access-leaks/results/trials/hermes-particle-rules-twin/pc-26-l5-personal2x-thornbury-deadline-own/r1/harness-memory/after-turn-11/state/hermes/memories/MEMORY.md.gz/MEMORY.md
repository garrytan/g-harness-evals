Dana Okafor (Account manager, North team, team-north) set a standing cutoff date of 27 September for the Thornbury Cloth Co. paperwork on the Wicklow renewal (her latest correction, DM 2026-10-14 18:00, saying the customer changed it on the call; supersedes 26 October, 13 December and 5 November given earlier the same day).
§
Marcus Lindqvist (Account manager, North team) set his cutoff date for the Thornbury Cloth Co. paperwork on the Juniper renewal to 25 October (DM 2026-10-27 12:00). Separate from Dana Okafor's Thornbury/Wicklow renewal cutoff above.
§
Ilse Varga (North team lead) set her cutoff date for the Thornbury Cloth Co. paperwork on the Jasper renewal to 25 January (DM 2026-11-05 00:00, "from now on"). Separate from Dana Okafor's Thornbury/Wicklow and Marcus Lindqvist's Thornbury/Juniper cutoffs.
§
Marcus Lindqvist (Account manager, North team) set his cutoff date for the Thornbury Cloth Co. paperwork on the Gannet renewal to 13 June (DM 2026-11-09 06:00, "from now on"). Separate from Dana Okafor's Thornbury/Wicklow, Marcus's Thornbury/Juniper and Ilse Varga's Thornbury/Jasper cutoffs.