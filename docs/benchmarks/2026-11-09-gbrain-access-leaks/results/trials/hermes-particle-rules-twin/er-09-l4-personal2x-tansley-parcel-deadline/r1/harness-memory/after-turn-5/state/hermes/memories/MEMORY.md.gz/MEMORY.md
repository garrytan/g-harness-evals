Tobias Rendle (Account manager, Central team) — paperwork cutoff dates (told in DM, for reference): Tansley Parcel / Corvid renewal 27 December; Tansleigh Packaging / Gannet renewal 6 June; Marrow Fieldworks / Saltire renewal 7 May.

Hollis Mbeki (Central team lead) — DM 24 Oct: his paperwork cutoff for the Tansley Parcel paperwork on the Bramble renewal is 4 February, superseding earlier dates.
§
Priyanka "Pree" Sundaram (Account manager, Central team) — DM 30 Oct: her cutoff date for the Tansley Parcel paperwork on the Bittern renewal is 21 October, superseding earlier dates.