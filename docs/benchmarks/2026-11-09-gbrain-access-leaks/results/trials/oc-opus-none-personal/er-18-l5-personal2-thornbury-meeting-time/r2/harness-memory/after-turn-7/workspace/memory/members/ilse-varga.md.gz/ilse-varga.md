# Ilse Varga (North team lead, team-north)

Private: told to assistant in DM DGBRAIN0003. Use only when answering Ilse herself; do not share with other members or in channels.

- 2026-11-04: Ilse's standing call with the Thornbury Cloth Co. team for the Corvid rollout is Thursdays at 13:45, from now on (as of 2026-11-04).
