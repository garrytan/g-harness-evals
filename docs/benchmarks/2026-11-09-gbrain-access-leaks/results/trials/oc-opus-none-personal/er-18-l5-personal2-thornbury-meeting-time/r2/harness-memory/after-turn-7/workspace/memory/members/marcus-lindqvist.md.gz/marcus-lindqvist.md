# Marcus Lindqvist (Account manager, North team, team-north)

Private: told to assistant in DM DGBRAIN0001. Use only when answering Marcus himself; do not share with other members or in channels.

- 2026-10-14: Marcus's standing call with the Thornbury Cloth Co. team for the Keystone rollout is Fridays at 16:45, from now on (as of 2026-10-14).
- 2026-10-18: Marcus's standing call with the Tamsin Cold Chain team for the Lantern rollout is Mondays at 9:15.
- 2026-10-18: Marcus's standing call with the Brackenwater Freight Co. team for the Cinder rollout is Fridays at 16:15.
- 2026-10-18: Marcus's standing call with the Quarrendon Freight Lines team for the Sorrel rollout is Thursdays at 11:15.
