# Hollis Mbeki (Central team lead, team-central)

Private: told to assistant in DM DGBRAIN0004. Use only when answering Hollis himself; do not share with other members or in channels.

- 2026-11-08: Hollis's standing call with the Thornbury Cloth Co. team for the Kestrel rollout is Tuesdays at 8:45, from now on (as of 2026-11-08).
