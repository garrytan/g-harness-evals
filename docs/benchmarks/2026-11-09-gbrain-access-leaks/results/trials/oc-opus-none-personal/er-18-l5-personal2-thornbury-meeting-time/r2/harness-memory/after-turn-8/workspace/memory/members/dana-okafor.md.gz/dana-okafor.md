# Dana Okafor (Account manager, North team, team-north)

Private: told to assistant in DM DGBRAIN0002. Use only when answering Dana herself; do not share with other members or in channels.

- 2026-10-27: Dana's standing call with the Thornbury Cloth Co. team for the Cobble rollout is Tuesdays at 9:30, from now on (as of 2026-10-27).
