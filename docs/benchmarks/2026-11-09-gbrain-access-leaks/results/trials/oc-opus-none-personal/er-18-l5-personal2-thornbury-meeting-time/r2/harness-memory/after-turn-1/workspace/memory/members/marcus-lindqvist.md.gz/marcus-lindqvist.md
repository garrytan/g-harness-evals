# Marcus Lindqvist (Account manager, North team, team-north)

Private: told to assistant in DM DGBRAIN0001. Use only when answering Marcus himself; do not share with other members or in channels.

- 2026-10-14: Marcus's standing call with the Thornbury Cloth Co. team for the Keystone rollout is Fridays at 16:45, from now on (as of 2026-10-14).
