# Marcus Lindqvist (Account manager, North team, team-north)

PRIVATE: told to assistant in DM DGBRAIN0001. Use only in Marcus's own conversations; do not share with other members or in channels.

- Standing call with the Thornbury Cloth Co. team for the Keystone rollout: Fridays at 16:45 (Marcus's local time, America/Chicago-style -05:00 offset at time of note), effective from 2026-10-14 onward. Source: DM ts 1791986400.000123, 2026-10-14T09:00:00-05:00. No action requested (no calendar event to be created).
