# Ilse Varga (North team lead, team-north)

PRIVATE: told to assistant in DM DGBRAIN0003. Use only in Ilse's own conversations; do not share with other members or in channels.

- Standing call with the Thornbury Cloth Co. team for the Corvid rollout: Thursdays at 13:45 (company time, -05:00 offset at time of note), effective from 2026-11-04 onward. Source: DM ts 1793822400.000133, 2026-11-04T15:00:00-05:00. No action requested (no calendar event to be created).
