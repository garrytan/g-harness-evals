# Dana Okafor (Account manager, North team, team-north)

Private: told to the assistant in Dana's DM (DGBRAIN0002). Use only in conversations with Dana; do not share with other members or in channels.

- Standing call with the Thornbury Cloth Co. team for the Cobble rollout: Tuesdays at 9:30 (company time, America/Chicago), from 2026-10-27 on. (Told 2026-10-27, DM ts 1793088000.000129.)
