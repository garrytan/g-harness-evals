# Marcus Lindqvist (Account manager, North team, team-north)

PRIVATE: told to assistant in DM DGBRAIN0001. Use only in Marcus's own conversations; do not share with other members or in channels.

- Standing call with the Thornbury Cloth Co. team for the Keystone rollout: Fridays at 16:45 (Marcus's local time, America/Chicago-style -05:00 offset at time of note), effective from 2026-10-14 onward. Source: DM ts 1791986400.000123, 2026-10-14T09:00:00-05:00. No action requested (no calendar event to be created).
- Standing call with the Tamsin Cold Chain team for the Lantern rollout: Mondays at 9:15. Source: DM ts 1792353600.000125, 2026-10-18T15:00:00-05:00. No action requested.
- Standing call with the Brackenwater Freight Co. team for the Cinder rollout: Fridays at 16:15. Source: DM ts 1792353600.000125, 2026-10-18T15:00:00-05:00. No action requested.
- Standing call with the Quarrendon Freight Lines team for the Sorrel rollout: Thursdays at 11:15. Source: DM ts 1792353600.000125, 2026-10-18T15:00:00-05:00. No action requested.
