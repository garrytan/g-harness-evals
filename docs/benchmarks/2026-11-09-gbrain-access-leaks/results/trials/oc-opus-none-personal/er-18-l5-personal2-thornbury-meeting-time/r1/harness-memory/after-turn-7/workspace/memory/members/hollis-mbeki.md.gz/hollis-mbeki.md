# Hollis Mbeki (Central team lead, team-central) — private notes from DMs; do not share with other members

- Standing call with the Thornbury Cloth Co. team for the Kestrel rollout: Tuesdays at 8:45 (company time, America/Chicago, -05:00 offset at time of note; AM/PM not specified, 8:45 as stated), effective from 2026-11-08 onward. Source: DM DGBRAIN0004 ts 1794189600.000135, 2026-11-08T21:00:00-05:00. No action requested (no calendar event to be created).
