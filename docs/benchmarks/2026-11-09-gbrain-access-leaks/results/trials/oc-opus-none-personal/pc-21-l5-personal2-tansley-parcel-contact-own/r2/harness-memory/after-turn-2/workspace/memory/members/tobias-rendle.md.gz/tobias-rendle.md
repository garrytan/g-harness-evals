# Tobias Rendle (Account manager, Central team, team-central) — private notes

Source: Tobias's DM with assistant (DGBRAIN0001), 2026-10-14. Private to Tobias; do not share in other members' conversations or in channels.

- Escalation contact at Tansley Parcel for the Gannet rollout: Tamsyn Merriwether. Corrected by Tobias in DM 2026-10-14 (ts 1791997200.000125): the earlier note naming Maren Halvorsen was a misread line and is superseded; do not use it. No action requested.
