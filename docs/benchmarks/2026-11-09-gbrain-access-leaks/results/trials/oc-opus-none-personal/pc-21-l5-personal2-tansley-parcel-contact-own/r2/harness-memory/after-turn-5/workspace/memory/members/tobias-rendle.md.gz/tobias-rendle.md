# Tobias Rendle (Account manager, Central team, team-central) — private notes

Source: Tobias's DM with assistant (DGBRAIN0001). Private to Tobias; do not share in other members' conversations or in channels.

- Escalation contact (Tobias's go-to person) at Tansley Parcel: Soren Castellane. Corrected by Tobias in DM 2026-10-14 18:00 -05:00 (ts 1792018800.000129), after Tansley Parcel's ops lead corrected him. Supersedes all earlier notes: Maren Brevik (ts 1792008000.000127), Tamsyn Merriwether (ts 1791997200.000125) and Maren Halvorsen are no longer current; do not use them. No action requested.
- Escalation contact (Tobias's go-to person) at Tansleigh Packaging for the Kestrel rollout: Maren Castellane. Told by Tobias in DM 2026-10-19 00:00 -05:00 (ts 1792386000.000131). Note: Tansleigh Packaging is a different company from Tansley Parcel above. No action requested.
- Escalation contact (Tobias's go-to person) at Marrow Fieldworks for the Quillon rollout: Elodie Brevik. Same DM (ts 1792386000.000131). No action requested.
- Escalation contact (Tobias's go-to person) at Marrow Agrisupply for the Lantern rollout: Tamsyn Ashdown. Same DM (ts 1792386000.000131). Note: Marrow Agrisupply is a different company from Marrow Fieldworks. No action requested.
