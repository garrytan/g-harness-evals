# Tobias Rendle (Account manager, Central team, team-central) — private notes

Source: Tobias's DM with assistant (DGBRAIN0001). Private to Tobias; do not share in other members' conversations or in channels.

- Escalation contact (Tobias's go-to person) at Tansley Parcel: Soren Castellane. Corrected by Tobias in DM 2026-10-14 18:00 -05:00 (ts 1792018800.000129), after Tansley Parcel's ops lead corrected him. Supersedes all earlier notes: Maren Brevik (ts 1792008000.000127), Tamsyn Merriwether (ts 1791997200.000125) and Maren Halvorsen are no longer current; do not use them. No action requested.
