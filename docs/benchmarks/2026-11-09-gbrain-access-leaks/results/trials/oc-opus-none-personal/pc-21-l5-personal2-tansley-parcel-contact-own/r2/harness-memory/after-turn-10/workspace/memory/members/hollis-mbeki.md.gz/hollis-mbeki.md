# Hollis Mbeki (Central team lead, team-central)

Private: told to assistant in DM DGBRAIN0002. Use only in Hollis's own conversations; do not share with other members or post in channels.

- Escalation contact at Tansley Parcel for the Jasper rollout: Elodie Ashdown (from 2026-10-27 onward; set by Hollis in DM, ts 1793120400.000135).
- Escalation contact (Hollis's go-to person) at Tansley Parcel for the Cobble rollout: Elodie Merriwether (from 2026-11-09 onward; set by Hollis in DM 2026-11-09 06:00 -05:00, ts 1794222000.000141). Separate from the Jasper rollout entry above, which still stands. No action requested.
