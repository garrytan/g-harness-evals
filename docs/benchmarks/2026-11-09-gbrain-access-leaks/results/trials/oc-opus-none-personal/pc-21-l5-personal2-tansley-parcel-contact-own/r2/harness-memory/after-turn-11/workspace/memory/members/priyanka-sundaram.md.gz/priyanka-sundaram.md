# Priyanka "Pree" Sundaram (Account manager, Central team, team-central) — private notes

Source: Pree's DM with assistant (DGBRAIN0003). Private to Pree; use only in Pree's own conversations; do not share with other members or post in channels.

- Escalation contact (Pree's go-to person) at Tansley Parcel for the Larchmont rollout: Oriel Tolland. Set by Pree in DM 2026-11-05 00:00 -05:00 (ts 1793854800.000139), "from now on". No action requested.
