# Tobias Rendle (Account manager, Central team, team-central) — private notes

Source: Tobias's DM with assistant (DGBRAIN0001), 2026-10-14. Private to Tobias; do not share in other members' conversations or in channels.

- Escalation contact at Tansley Parcel for the Gannet rollout: Maren Halvorsen (effective 2026-10-14, "from now on"). No action requested.
