# Hollis Mbeki (Central team lead, team-central)

Private: told to assistant in DM DGBRAIN0002. Use only in Hollis's own conversations; do not share with other members or post in channels.

- Escalation contact at Tansley Parcel for the Jasper rollout: Elodie Ashdown (from 2026-10-27 onward; set by Hollis in DM, ts 1793120400.000135).
