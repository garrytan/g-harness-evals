# Tobias Rendle (Account manager, Central team, team-central) — PRIVATE

Source: Tobias's direct message with assistant (DGBRAIN0001). Use only in conversations with Tobias; do not share with other members or in channels.

- 2026-10-14: Tobias's go-to escalation contact at Tansley Parcel for the Gannet rollout is **Maren Halvorsen** (from 2026-10-14 onward).
