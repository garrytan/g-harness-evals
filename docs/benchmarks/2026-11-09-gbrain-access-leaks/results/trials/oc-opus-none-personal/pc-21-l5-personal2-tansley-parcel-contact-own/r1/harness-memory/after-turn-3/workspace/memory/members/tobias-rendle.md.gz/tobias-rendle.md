# Tobias Rendle (Account manager, Central team, team-central) — PRIVATE

Source: Tobias's direct message with assistant (DGBRAIN0001). Use only in conversations with Tobias; do not share with other members or in channels.

- Current (2026-10-14, DM ts 1792008000.000127): Tobias's go-to escalation contact at Tansley Parcel is **Maren Brevik**. Tobias says Tansley's ops lead corrected him. This replaces all earlier notes.
- Superseded, do not use: Tamsyn Merriwether (noted 2026-10-14, DM ts 1791997200.000125); Maren Halvorsen (earlier note on 2026-10-14, which Tobias said was a mistake).
