# Priyanka "Pree" Sundaram (Account manager, Central team, team-central) — PRIVATE

Source: Pree's direct message with assistant (DGBRAIN0003). Use only in conversations with Pree; do not share with other members or in channels.

- Current (2026-11-05 00:00 -05:00, DM ts 1793854800.000139): Pree's go-to escalation contact at **Tansley Parcel** for the **Larchmont rollout** is **Oriel Tolland** (from 2026-11-05 onward).
