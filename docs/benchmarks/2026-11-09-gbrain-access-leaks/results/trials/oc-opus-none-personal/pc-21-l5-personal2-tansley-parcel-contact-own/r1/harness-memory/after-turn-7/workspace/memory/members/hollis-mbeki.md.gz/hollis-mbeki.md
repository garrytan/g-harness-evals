# Hollis Mbeki (Central team lead, team-central) — PRIVATE

Source: Hollis's direct message with assistant (DGBRAIN0002). Use only in conversations with Hollis; do not share with other members or in channels.

- 2026-10-27: Hollis's go-to escalation contact at Tansley Parcel for the Jasper rollout is **Elodie Ashdown** (from 2026-10-27 onward).
