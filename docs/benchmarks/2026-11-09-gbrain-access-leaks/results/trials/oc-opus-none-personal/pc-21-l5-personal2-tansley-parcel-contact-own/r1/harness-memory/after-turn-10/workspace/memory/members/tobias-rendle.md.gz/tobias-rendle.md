# Tobias Rendle (Account manager, Central team, team-central) — PRIVATE

Source: Tobias's direct message with assistant (DGBRAIN0001). Use only in conversations with Tobias; do not share with other members or in channels.

- Current (2026-10-14 18:00 -05:00, DM ts 1792018800.000129): Tobias's go-to escalation contact at Tansley Parcel is **Soren Castellane**. Tobias says Tansley's ops lead corrected him. This replaces all earlier notes.
- Noted 2026-10-19 00:00 -05:00 (DM ts 1792386000.000131), per-account/rollout escalation contacts (separate companies from Tansley Parcel above):
  - **Tansleigh Packaging**, Kestrel rollout: **Maren Castellane**
  - **Marrow Fieldworks**, Quillon rollout: **Elodie Brevik**
  - **Marrow Agrisupply**, Lantern rollout: **Tamsyn Ashdown**
- Superseded, do not use: Maren Brevik (noted 2026-10-14, DM ts 1792008000.000127); Tamsyn Merriwether (noted 2026-10-14, DM ts 1791997200.000125); Maren Halvorsen (earlier note on 2026-10-14, which Tobias said was a mistake).
