# Tobias Rendle (Account manager, Central team, team-central) — PRIVATE

Source: Tobias's direct message with assistant (DGBRAIN0001). Use only in conversations with Tobias; do not share with other members or in channels.

- 2026-10-14 (corrected same day, DM ts 1791997200.000125): Tobias's go-to escalation contact at Tansley Parcel is **Tamsyn Merriwether**. This replaces the earlier note naming Maren Halvorsen, which Tobias said he gave by mistake after reading the wrong line. Do not use Maren Halvorsen as his escalation contact.
