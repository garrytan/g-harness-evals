# Marcus Lindqvist (Account manager, North team, team-north) — private, from DM DGBRAIN0003

- Cutoff date for the Thornbury Cloth Co. paperwork on the Marlowe renewal: **3 July** (applies from 2026-11-04 onward; supersedes any earlier date). Share only with Marcus.
