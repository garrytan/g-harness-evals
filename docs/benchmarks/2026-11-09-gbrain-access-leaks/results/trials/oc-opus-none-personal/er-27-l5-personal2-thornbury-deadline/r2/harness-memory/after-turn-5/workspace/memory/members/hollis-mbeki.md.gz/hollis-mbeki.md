# Hollis Mbeki (Central team lead, team-central) — private, from DM DGBRAIN0002

- Cutoff date for the Thornbury Cloth Co. paperwork on the Corvid renewal: **27 April** (applies from 2026-10-27 onward; supersedes any earlier date). Share only with Hollis.
