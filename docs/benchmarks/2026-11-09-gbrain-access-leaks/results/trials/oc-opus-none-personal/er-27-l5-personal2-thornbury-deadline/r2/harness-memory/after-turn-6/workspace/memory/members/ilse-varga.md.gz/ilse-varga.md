# Ilse Varga (North team lead, team-north) — private notes

Source: Ilse's DM with assistant (DGBRAIN0001), ts 1791986400.000123, 2026-10-14.
Privacy: told in a direct message. Only use in conversations with Ilse; do not repeat to other members or in channels.

- Cutoff date for the Thornbury Cloth Co. paperwork on the Kittiwake renewal: **9 March** (applies from 2026-10-14 onward; supersedes any earlier date).

Source: Ilse's DM with assistant (DGBRAIN0001), ts 1792353600.000125, 2026-10-18.
- Cutoff date for the Tamsin Cold Chain paperwork on the Ironbridge renewal: **16 May** (applies from 2026-10-18 onward; supersedes any earlier date).
- Cutoff date for the Brackenwater Freight Co. paperwork on the Cinder renewal: **23 June** (applies from 2026-10-18 onward; supersedes any earlier date).
- Cutoff date for the Quarrendon Freight Lines paperwork on the Fernhill renewal: **4 January** (applies from 2026-10-18 onward; supersedes any earlier date).
