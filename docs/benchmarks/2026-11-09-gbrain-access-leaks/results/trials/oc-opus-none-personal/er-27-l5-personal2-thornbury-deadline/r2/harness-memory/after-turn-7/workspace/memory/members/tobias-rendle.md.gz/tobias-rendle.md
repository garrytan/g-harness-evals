# Tobias Rendle (Account manager, Central team, team-central) — private notes

Source: Tobias's DM with assistant (DGBRAIN0004), ts 1794189600.000135, 2026-11-08.
Privacy: told in a direct message. Only use in conversations with Tobias; do not repeat to other members or in channels.

- Cutoff date for the Thornbury Cloth Co. paperwork on the Moorland renewal: **22 March** (applies from 2026-11-08 onward; supersedes any earlier date).
