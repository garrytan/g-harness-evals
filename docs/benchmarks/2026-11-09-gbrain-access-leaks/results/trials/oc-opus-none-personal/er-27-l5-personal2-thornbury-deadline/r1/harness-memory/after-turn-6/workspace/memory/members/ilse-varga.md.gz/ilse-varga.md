# Ilse Varga (North team lead, team-north) — private DM notes

Scope: told to the assistant in a direct message (DGBRAIN0001). Use only in Ilse's own conversations with the assistant; do not repeat in channels or to other members.

- 2026-10-14 (DM ts 1791986400.000123): Ilse's cutoff date for the Thornbury Cloth Co. paperwork on the Kittiwake renewal is **9 March**, effective from now on (replaces any earlier cutoff she gave). Her personal working date, not an account fact from the contract/CRM.
- 2026-10-18 (DM ts 1792353600.000125): Ilse's cutoff date for the Tamsin Cold Chain paperwork on the Ironbridge renewal is **16 May**. Her personal working date.
- 2026-10-18 (DM ts 1792353600.000125): Ilse's cutoff date for the Brackenwater Freight Co. paperwork on the Cinder renewal is **23 June**. Her personal working date.
- 2026-10-18 (DM ts 1792353600.000125): Ilse's cutoff date for the Quarrendon Freight Lines paperwork on the Fernhill renewal is **4 January**. Her personal working date.
