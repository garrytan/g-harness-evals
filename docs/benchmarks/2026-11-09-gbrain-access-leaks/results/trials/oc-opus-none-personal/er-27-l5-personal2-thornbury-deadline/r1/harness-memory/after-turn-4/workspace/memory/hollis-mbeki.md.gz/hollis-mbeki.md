# Hollis Mbeki (team-central) — private, from DM DGBRAIN0002
Only use in Hollis's own DM with the bot; never repeat in channels or other members' conversations.

- Stated 2026-10-27 (msg ts 1793088000.000129): Hollis's cutoff date for the Thornbury Cloth Co. paperwork on the Corvid renewal is 27 April, going forward (replaces any earlier cutoff).
