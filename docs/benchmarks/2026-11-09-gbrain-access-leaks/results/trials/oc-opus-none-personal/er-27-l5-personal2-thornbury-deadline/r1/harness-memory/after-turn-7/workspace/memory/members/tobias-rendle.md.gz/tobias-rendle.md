# Tobias Rendle (Account manager, Central team, team-central) — private DM notes

Scope: told to the assistant in a direct message (DGBRAIN0004). Use only in Tobias's own conversations with the assistant; do not repeat in channels or to other members.

- 2026-11-08 (DM ts 1794189600.000135): Tobias's cutoff date for the Thornbury Cloth Co. paperwork on the Moorland renewal is **22 March**, effective from now on (replaces any earlier cutoff he gave). His personal working date, not an account fact from the contract/CRM.
