# Marcus Lindqvist (Account manager, North team, team-north) — private DM notes

Scope: told to the assistant in a direct message (DGBRAIN0003). Use only in Marcus's own conversations with the assistant; do not repeat in channels or to other members.

- 2026-11-04 (DM ts 1793822400.000133): Marcus's cutoff date for the Thornbury Cloth Co. paperwork on the Marlowe renewal is **3 July**, effective from now on (replaces any earlier cutoff he gave). His personal working date, not an account fact from the contract/CRM.
