# Dana Okafor (Account manager, North team, team-north) — private notes

Source: Dana's DM with assistant (DGBRAIN0003). Private to Dana: do not share in other members' conversations or in channels.

- Logged 2026-11-04 (DM ts 1793822400.000133): Dana's dock for Tamsin Cold Chain pickups on the Sorrel project is **Door 43**, effective from that date ("from now on").
