# Hollis Mbeki (Central team lead, team-central) — private notes

Source: Hollis's DM with assistant (DGBRAIN0004). Private to Hollis: do not share in other members' conversations or in channels.

- Logged 2026-11-08 (DM ts 1794189600.000135): Hollis's dock for Tamsin Cold Chain pickups on the Larchmont project is **Door 37**, effective from that date ("from now on").
