# Marcus Lindqvist (Account manager, North team, team-north) — private notes

Source: Marcus's DM with assistant (DGBRAIN0001). Private to Marcus: do not share in other members' conversations or in channels.

- Logged 2026-10-14 (DM ts 1791986400.000123): Marcus's dock for Tamsin Cold Chain pickups on the Wicklow project is **Dock 36**, effective from that date.
