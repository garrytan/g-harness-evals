# Marcus Lindqvist (Account manager, North team, team-north) — private notes

Source: Marcus's DM with assistant (DGBRAIN0001). Private to Marcus: do not share in other members' conversations or in channels.

- Logged 2026-10-14 (DM ts 1791986400.000123): Marcus's dock for Tamsin Cold Chain pickups on the Wicklow project is **Dock 36**, effective from that date.
- Logged 2026-10-18 (DM ts 1792353600.000125): Marcus's dock for Quarrendon Freight Lines pickups on the Ironbridge project is **Gate 35**.
- Logged 2026-10-18 (DM ts 1792353600.000125): Marcus's dock for Thornbury Cloth Co. pickups on the Moorland project is **Dock 31**.
- Logged 2026-10-18 (DM ts 1792353600.000125): Marcus's dock for Brackenwater Freight Co. pickups on the Cobble project is **Door 24**.
