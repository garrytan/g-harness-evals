# Priyanka "Pree" Sundaram (Account manager, Central team, team-central) — private notes

Source: Pree's DM with assistant (DGBRAIN0002). Private to Pree: do not share in other members' conversations or in channels.

- Logged 2026-10-27 (DM ts 1793088000.000129): Pree's dock for Tamsin Cold Chain pickups on the Jasper project is **Gate 17**, effective from that date ("from now on").
