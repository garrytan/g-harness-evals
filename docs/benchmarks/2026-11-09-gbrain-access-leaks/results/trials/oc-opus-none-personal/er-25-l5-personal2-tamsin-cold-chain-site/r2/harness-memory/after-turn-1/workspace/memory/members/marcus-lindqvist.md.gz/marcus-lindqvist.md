# Marcus Lindqvist (Account manager, North team, team-north)

Private: told to the assistant in a DM (DGBRAIN0001). Use only in conversations with Marcus; do not share with other members or in channels.

- 2026-10-14: For Tamsin Cold Chain pickups on the Wicklow project, Marcus uses **Dock 36** from now on. (Source: DM ts 1791986400.000123)
