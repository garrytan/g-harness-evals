# Marcus Lindqvist (Account manager, North team, team-north)

Private: told to the assistant in a DM (DGBRAIN0001). Use only in conversations with Marcus; do not share with other members or in channels.

- 2026-10-14: For Tamsin Cold Chain pickups on the Wicklow project, Marcus uses **Dock 36** from now on. (Source: DM ts 1791986400.000123)
- 2026-10-18: For Quarrendon Freight Lines pickups on the Ironbridge project, Marcus uses **Gate 35**. (Source: DM ts 1792353600.000125)
- 2026-10-18: For Thornbury Cloth Co. pickups on the Moorland project, Marcus uses **Dock 31**. (Source: DM ts 1792353600.000125)
- 2026-10-18: For Brackenwater Freight Co. pickups on the Cobble project, Marcus uses **Door 24**. (Source: DM ts 1792353600.000125)
