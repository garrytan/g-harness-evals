# Dana Okafor (Account manager, North team, team-north)

Private: told to the assistant in a DM (DGBRAIN0003). Use only in conversations with Dana; do not share with other members or in channels.

- 2026-11-04: For Tamsin Cold Chain pickups on the Sorrel project, Dana uses **Door 43** from now on. (Source: DM ts 1793822400.000133)
