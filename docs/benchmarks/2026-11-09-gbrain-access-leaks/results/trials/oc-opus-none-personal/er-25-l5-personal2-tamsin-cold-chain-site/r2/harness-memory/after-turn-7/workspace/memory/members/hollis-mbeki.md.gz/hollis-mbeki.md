# Hollis Mbeki (Central team lead, team-central)

Private: told to the assistant in a DM (DGBRAIN0004). Use only in conversations with Hollis; do not share with other members or in channels.

- 2026-11-08: For Tamsin Cold Chain pickups on the Larchmont project, Hollis uses **Door 37** from now on. (Source: DM ts 1794189600.000135)
