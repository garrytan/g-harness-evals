# Priyanka "Pree" Sundaram (Account manager, Central team, team-central)

Private: told to the assistant in a DM (DGBRAIN0002). Use only in conversations with Pree; do not share with other members or in channels.

- 2026-10-27: For Tamsin Cold Chain pickups on the Jasper project, Pree uses **Gate 17** from now on. (Source: DM ts 1793088000.000129)
