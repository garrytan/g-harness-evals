# Ilse Varga (North team lead, team-north)

Private: Ilse told me this in her DM (DGBRAIN0003). Only use it in her own conversations. Do not repeat it to other members or post it in channels.

- Standing call with the Tamsin Cold Chain team (Foxglove rollout): **Tuesdays at 8:45**, "from now on" as of her message sent 2026-11-05 00:00 -05:00 (first such Tuesday is 2026-11-10). She did not give a time zone. She said no action needed (no calendar event requested). (Recorded from DM ts 1793854800.000139.)
