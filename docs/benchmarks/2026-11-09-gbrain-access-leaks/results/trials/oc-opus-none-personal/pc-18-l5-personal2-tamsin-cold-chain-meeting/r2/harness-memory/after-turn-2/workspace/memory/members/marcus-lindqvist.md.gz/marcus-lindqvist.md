# Marcus Lindqvist (Account manager, North team, team-north)

Private: Marcus told me this in his DM (DGBRAIN0001). Only use it in his own conversations. Do not repeat it to other members or post it in channels.

- Standing call with the Tamsin Cold Chain team (Gannet rollout): **Mondays at 14:15**. He did not give a time zone; his message was sent at 12:00 -05:00. He said finance sent an updated sheet. This corrects and replaces the earlier slot (Mondays 11:45, recorded from DM ts 1791986400.000123). (Correction recorded from DM ts 1791997200.000125, 2026-10-14.)
