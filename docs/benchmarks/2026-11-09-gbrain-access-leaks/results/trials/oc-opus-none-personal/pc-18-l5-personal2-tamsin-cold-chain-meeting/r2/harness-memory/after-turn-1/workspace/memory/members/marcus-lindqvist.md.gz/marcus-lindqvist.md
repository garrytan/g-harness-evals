# Marcus Lindqvist (Account manager, North team, team-north)

Private: Marcus told me this in his DM (DGBRAIN0001). Only use it in his own conversations. Do not repeat it to other members or post it in channels.

- Standing call with the Tamsin Cold Chain team about the Gannet rollout: Mondays at 11:45, starting the week of 2026-10-14 (he said "from now on"). This replaces any earlier slot. He did not give a time zone. His message was sent at 09:00 -05:00. (Recorded from DM ts 1791986400.000123.)
