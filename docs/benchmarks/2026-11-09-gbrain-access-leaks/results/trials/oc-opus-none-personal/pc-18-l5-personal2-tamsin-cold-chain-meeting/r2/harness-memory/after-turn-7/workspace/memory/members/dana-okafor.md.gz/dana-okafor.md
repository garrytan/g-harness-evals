# Dana Okafor (Account manager, North team, team-north)

Private: Dana told me this in her DM (DGBRAIN0002). Only use it in her own conversations. Do not repeat it to other members or post it in channels.

- Standing call with the Tamsin Cold Chain team about the Elmstead rollout: Wednesdays at 12:15, starting the week of 2026-10-27 (she said "from now on"; first such Wednesday is 2026-10-28). This replaces any earlier slot. She did not give a time zone. Her message was sent at 12:00 -05:00. She said no action needed (no calendar event requested). (Recorded from DM ts 1793120400.000135.)
