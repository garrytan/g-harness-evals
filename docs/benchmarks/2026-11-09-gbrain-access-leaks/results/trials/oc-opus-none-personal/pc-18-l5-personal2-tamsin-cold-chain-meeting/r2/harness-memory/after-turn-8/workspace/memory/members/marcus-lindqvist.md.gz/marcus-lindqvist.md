# Marcus Lindqvist (Account manager, North team, team-north)

Private: Marcus told me this in his DM (DGBRAIN0001). Only use it in his own conversations. Do not repeat it to other members or post it in channels.

- Standing call with the Tamsin Cold Chain team (Gannet rollout): **Thursdays at 8:15**. The customer changed it on the call. He did not give a time zone; his message was sent at 18:00 -05:00 on 2026-10-14. (Correction recorded from DM ts 1792018800.000129.)
- Superseded slots (do not use): Mondays 14:15 (DM ts 1791997200.000125); Mondays 11:45 (DM ts 1791986400.000123).
- Standing call with the Thornbury Cloth Co. team (Saltire rollout): **Mondays at 10:30**. (DM ts 1792386000.000131, sent 2026-10-19 00:00 -05:00; no time zone given.)
- Standing call with the Brackenwater Freight Co. team (Linden rollout): **Mondays at 16:15**. (Same DM.)
- Standing call with the Quarrendon Freight Lines team (Keystone rollout): **Thursdays at 9:45**. (Same DM.)
