# Dana Okafor (Account manager, North team, team-north)

Private notes from Dana's direct messages with the assistant (DM DGBRAIN0002). Use only in conversations with Dana; do not share in channels or with other members.

- Standing call with the Tamsin Cold Chain team for the Elmstead rollout: Wednesdays at 12:15 (company time zone), effective from 2026-10-27 onward. (Told in DM, ts 1793120400.000135.)
- Standing call with the Tamsin Cold Chain team for the Bittern rollout: Wednesdays at 12:30 (company time zone), effective from 2026-11-09 onward. Separate from the Elmstead call above. (Told in DM, ts 1794222000.000141.)
