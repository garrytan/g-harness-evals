# Ilse Varga (North team lead, team-north)

Private notes from Ilse's direct messages with the assistant (DM DGBRAIN0003). Use only in conversations with Ilse; do not share in channels or with other members.

- CURRENT (2026-11-05, DM ts 1793854800.000139): Standing call with the Tamsin Cold Chain team for the Foxglove rollout: **Tuesdays at 8:45** (company time zone), from 2026-11-05 onward. No action needed (no calendar change requested).
