# Marcus Lindqvist (Account manager, North team, team-north)

Private: told to assistant in DM (DGBRAIN0001). Do not share in other members' conversations or in channels.

- CURRENT (2026-10-14, DM ts 1792018800.000129): Marcus's standing call with the Tamsin Cold Chain team (Gannet rollout) is **Thursdays at 8:15**. The customer changed it on the call. No action needed (no calendar change requested).
- SUPERSEDED (2026-10-14, DM ts 1792008000.000127): Wednesdays at 11:15 — replaced by the Thursday 8:15 correction above; do not use.
- SUPERSEDED (2026-10-14, DM ts 1791997200.000125): Mondays at 14:15 — replaced; do not use.
- SUPERSEDED (2026-10-14, DM ts 1791986400.000123): Mondays at 11:45 — replaced; do not use.
