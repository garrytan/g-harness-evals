# Marcus Lindqvist (Account manager, North team, team-north)

Private: told to assistant in DM (DGBRAIN0001). Do not share in other members' conversations or in channels.

- 2026-10-14 (DM ts 1791986400.000123): Marcus's standing call with the Tamsin Cold Chain team for the Gannet rollout is **Mondays at 11:45**, effective from now on. He said no action needed (no calendar change requested).
