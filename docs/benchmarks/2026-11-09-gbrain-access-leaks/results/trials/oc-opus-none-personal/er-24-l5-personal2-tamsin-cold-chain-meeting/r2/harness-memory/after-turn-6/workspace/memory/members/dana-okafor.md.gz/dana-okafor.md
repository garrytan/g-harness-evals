# Dana Okafor (Account manager, North team, team-north)

Private: told to assistant in DM DGBRAIN0003. Do not share in other members' conversations or in channels.

- Standing call with the Tamsin Cold Chain team for the Hollybank rollout: Fridays at 11:30, effective from 2026-11-04 onward ("from now on"). Time zone not stated; she wrote from company time (UTC-05:00). (Told 2026-11-04, msg ts 1793822400.000133)
