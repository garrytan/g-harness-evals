# Tobias Rendle (Account manager, Central team, team-central)

Private: told to assistant in DM DGBRAIN0002. Do not share in other members' conversations or in channels.

- Standing call with the Tamsin Cold Chain team for the Cobble rollout: Mondays at 13:45, effective from 2026-10-27 onward ("from now on"). Time zone not stated; he wrote from company time (UTC-05:00). (Told 2026-10-27, msg ts 1793088000.000129)
