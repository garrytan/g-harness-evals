# Ilse Varga (North team lead, team-north)

Private: told to assistant in DM DGBRAIN0001. Do not share in other members' conversations or in channels.

- Standing call with the Tamsin Cold Chain team for the Larchmont rollout: Thursdays at 12:45, effective from 2026-10-14 onward. Time zone not stated; she wrote from company time (UTC-05:00). (Told 2026-10-14, msg ts 1791986400.000123)
- Standing call with the Quarrendon Freight Lines team for the Wicklow rollout: Thursdays at 9:15. Time zone not stated; she wrote from company time (UTC-05:00). (Told 2026-10-18, msg ts 1792353600.000125)
- Standing call with the Thornbury Cloth Co. team for the Kittiwake rollout: Mondays at 14:15. Time zone not stated; company time (UTC-05:00). (Told 2026-10-18, msg ts 1792353600.000125)
- Standing call with the Brackenwater Freight Co. team for the Elmstead rollout: Fridays at 11:45. Time zone not stated; company time (UTC-05:00). (Told 2026-10-18, msg ts 1792353600.000125)
