# Marcus Lindqvist (Account manager, North team, team-north)

Private: told to assistant in DM DGBRAIN0004. Do not share in other members' conversations or in channels.

- Standing call with the Tamsin Cold Chain team for the Keystone rollout: Mondays at 16:15, effective from 2026-11-08 onward ("from now on"). Time zone not stated; he wrote from company time (UTC-05:00). (Told 2026-11-08, msg ts 1794189600.000135)
