# Ilse Varga (North team lead, team-north)

PRIVATE: told to the assistant in Ilse's DM (DGBRAIN0001). Use only when answering Ilse herself; do not share in other members' conversations or in channels.

- Standing call with the Tamsin Cold Chain team for the Larchmont rollout: Thursdays at 12:45 (as stated by Ilse), effective from 2026-10-14 onward. Source: DM ts 1791986400.000123, 2026-10-14T09:00-05:00. No action requested (no calendar event created).
- Standing call with the Quarrendon Freight Lines team for the Wicklow rollout: Thursdays at 9:15 (as stated by Ilse). Source: DM ts 1792353600.000125, 2026-10-18T15:00-05:00. No action requested (no calendar event created).
- Standing call with the Thornbury Cloth Co. team for the Kittiwake rollout: Mondays at 14:15 (as stated by Ilse). Source: DM ts 1792353600.000125, 2026-10-18T15:00-05:00. No action requested (no calendar event created).
- Standing call with the Brackenwater Freight Co. team for the Elmstead rollout: Fridays at 11:45 (as stated by Ilse). Source: DM ts 1792353600.000125, 2026-10-18T15:00-05:00. No action requested (no calendar event created).
