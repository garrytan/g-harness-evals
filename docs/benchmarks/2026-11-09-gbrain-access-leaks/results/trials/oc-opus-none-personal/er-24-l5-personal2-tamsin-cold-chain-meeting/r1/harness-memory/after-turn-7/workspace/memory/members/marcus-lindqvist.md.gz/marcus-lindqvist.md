# Marcus Lindqvist (Account manager, North team, team-north)

PRIVATE: told to the assistant in Marcus's DM (DGBRAIN0004). Use only when answering Marcus himself; do not share in other members' conversations or in channels.

- Standing call with the Tamsin Cold Chain team for the Keystone rollout: Mondays at 16:15 (as stated by Marcus), effective from 2026-11-08 onward ("from now on"). Source: DM ts 1794189600.000135, 2026-11-08T21:00-05:00. No action requested (no calendar event created).
