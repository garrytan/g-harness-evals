# Ilse Varga (North team lead, team-north)

PRIVATE: told to the assistant in Ilse's DM (DGBRAIN0001). Use only when answering Ilse herself; do not share in other members' conversations or in channels.

- Standing call with the Tamsin Cold Chain team for the Larchmont rollout: Thursdays at 12:45 (as stated by Ilse), effective from 2026-10-14 onward. Source: DM ts 1791986400.000123, 2026-10-14T09:00-05:00. No action requested (no calendar event created).
