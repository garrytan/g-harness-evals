# Dana Okafor (Account manager, North team) — private notes from DM DGBRAIN0003

Private: told to the assistant in a direct message. Do not share in other members' conversations or in channels.

- Standing call with the Tamsin Cold Chain team for the Hollybank rollout: Fridays at 11:30 (company time), effective from 2026-11-04 onward. (Told 2026-11-04 15:00 -05:00; no action requested.)
