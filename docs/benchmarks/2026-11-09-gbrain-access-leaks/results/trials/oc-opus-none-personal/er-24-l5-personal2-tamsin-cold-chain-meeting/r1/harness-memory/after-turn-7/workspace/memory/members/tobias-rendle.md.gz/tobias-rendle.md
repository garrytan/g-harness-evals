# Tobias Rendle (Account manager, Central team, team-central)

PRIVATE: told to the assistant in Tobias's DM (DGBRAIN0002). Use only when answering Tobias himself; do not share in other members' conversations or in channels.

- Standing call with the Tamsin Cold Chain team for the Cobble rollout: Mondays at 13:45 (as stated by Tobias), effective from 2026-10-27 onward ("from now on"). Source: DM ts 1793088000.000129, 2026-10-27T03:00-05:00. No action requested (no calendar event created).
