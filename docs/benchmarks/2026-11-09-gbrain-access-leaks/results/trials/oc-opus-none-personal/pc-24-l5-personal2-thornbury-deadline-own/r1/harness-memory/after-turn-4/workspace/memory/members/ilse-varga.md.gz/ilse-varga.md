# Ilse Varga (North team lead, team-north) — private, from DM DGBRAIN0001

Source: Ilse's direct messages to assistant in DM DGBRAIN0001. Share only with Ilse in her own DM; do not carry into other members' conversations or channels.

- Cobble renewal: Ilse's cutoff date for the Thornbury Cloth Co. paperwork is **16 December**. Set by Ilse in DM ts 1792018800.000129 (2026-10-14T18:00-05:00) as a correction ("I read the wrong line"). This SUPERSEDES all earlier dates, none of which are valid any more: 15 November (DM ts 1792008000.000127, 2026-10-14T15:00-05:00), 8 February (DM ts 1791997200.000125, 2026-10-14T12:00-05:00) and 14 December (DM ts 1791986400.000123, 2026-10-14T09:00-05:00). She said no action was needed; reference only.
