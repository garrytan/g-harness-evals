# Marcus Lindqvist (Account manager, North team, team-north)

Private: told to the assistant in DM (DGBRAIN0003). Use only in Marcus's own conversations.

- Thornbury Cloth Co., Lantern renewal: Marcus's cutoff date for the paperwork is **16 May** (stated 2026-11-05, ts 1793854800.000139; applies "from now on", supersedes any earlier date he gave).
