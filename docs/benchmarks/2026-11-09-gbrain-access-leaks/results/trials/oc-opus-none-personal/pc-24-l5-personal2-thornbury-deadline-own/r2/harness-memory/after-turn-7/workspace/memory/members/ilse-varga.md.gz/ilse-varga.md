# Ilse Varga (North team lead, team-north) — private, from DM DGBRAIN0001

Do not share these notes in other members' conversations or in channels.

- Thornbury Cloth Co. paperwork, Cobble renewal: Ilse's cutoff date is **16 December**. Corrected in DM on 2026-10-14 18:00 (msg ts 1792018800.000129); she had read the wrong line. This supersedes all earlier cutoffs she gave: 15 November (2026-10-14 15:00, msg ts 1792008000.000127), 8 February (2026-10-14 12:00, msg ts 1791997200.000125) and 14 December (2026-10-14 09:00, msg ts 1791986400.000123). None of those are valid any more.
- Brackenwater Freight Co. paperwork, Driftwood renewal: Ilse's cutoff date is **4 June**. Given in DM on 2026-10-19 00:00 (msg ts 1792386000.000131).
- Tamsin Cold Chain paperwork, Quillon renewal: Ilse's cutoff date is **9 May**. Given in DM on 2026-10-19 00:00 (msg ts 1792386000.000131).
- Quarrendon Freight Lines paperwork, Fernhill renewal: Ilse's cutoff date is **25 September**. Given in DM on 2026-10-19 00:00 (msg ts 1792386000.000131).
