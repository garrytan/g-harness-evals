# Marcus Lindqvist (Account manager, North team, team-north) — private, from DMs only

- Thornbury Cloth Co. paperwork, Lantern renewal: Marcus's cutoff date is **16 May**, "from now on". Given in DM on 2026-11-05 00:00 -05:00 (channel DGBRAIN0003, msg ts 1793854800.000139). No action requested; remember only. Do not share in other members' conversations or channels.
