# Ilse Varga (North team lead, team-north)

Private notes from Ilse's DMs with assistant (DGBRAIN0004). Use only in conversations with Ilse; do not share in other members' conversations or channels.

- Standing call with the Marrow Fieldworks team for the Gannet rollout: Thursdays at 11:15, effective from 2026-11-08 onward. (Told in DM, ts 1794189600.000135, 2026-11-08T21:00-05:00.) No action requested. Note: distinct from other Marrow Fieldworks rollouts (e.g. Linden, Corvid, Saltire).
