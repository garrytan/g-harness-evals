# Tobias Rendle (Account manager, Central team, team-central)

Private notes from Tobias's DMs with assistant (DGBRAIN0001). Use only in conversations with Tobias; do not share in other members' conversations or channels.

- Standing call with the Marrow Fieldworks team for the Saltire rollout: Mondays at 13:30, effective from 2026-10-14 onward. (Told in DM, ts 1791986400.000123, 2026-10-14T09:00-05:00.) No action requested.
- Standing call with the Tansleigh Packaging team for the Ironbridge rollout: Mondays at 08:30. (Told in DM, ts 1792353600.000125, 2026-10-18T15:00-05:00.) No action requested.
- Standing call with the Marrow Agrisupply team for the Merlin rollout: Wednesdays at 13:45. (Same DM, ts 1792353600.000125.) No action requested. Note: Marrow Agrisupply is distinct from Marrow Fieldworks (Saltire).
- Standing call with the Tansley Parcel team for the Moorland rollout: Mondays at 12:45. (Same DM, ts 1792353600.000125.) No action requested. Note: Tansley Parcel (Moorland) is distinct from Tansleigh Packaging (Ironbridge).
