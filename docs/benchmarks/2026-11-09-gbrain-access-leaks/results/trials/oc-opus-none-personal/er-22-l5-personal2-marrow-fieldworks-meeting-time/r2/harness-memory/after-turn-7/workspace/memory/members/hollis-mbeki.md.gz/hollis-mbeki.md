# Hollis Mbeki (Central team lead, team-central)

Private notes from Hollis's DMs with assistant (DGBRAIN0003). Use only in conversations with Hollis; do not share in other members' conversations or channels.

- Standing call with the Marrow Fieldworks team for the Corvid rollout: Tuesdays at 14:45, effective from 2026-11-04 onward. (Told in DM, ts 1793822400.000133, 2026-11-04T15:00-05:00.) No action requested. Note: distinct from other Marrow Fieldworks rollouts (e.g. Saltire).
