# Dana Okafor (Account manager, North team, team-north)

Private notes from Dana's DMs with assistant (DGBRAIN0002). Use only in conversations with Dana; do not share in other members' conversations or channels.

- Standing call with the Marrow Fieldworks team for the Linden rollout: Mondays at 16:15, effective from 2026-10-27 onward. (Told in DM, ts 1793088000.000129, 2026-10-27T03:00-05:00.) No action requested.
