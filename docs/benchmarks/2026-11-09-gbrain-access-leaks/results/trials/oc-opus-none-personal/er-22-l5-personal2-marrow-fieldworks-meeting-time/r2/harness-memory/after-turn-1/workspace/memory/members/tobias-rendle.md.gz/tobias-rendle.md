# Tobias Rendle (Account manager, Central team, team-central)

Private notes from Tobias's DMs with assistant (DGBRAIN0001). Use only in conversations with Tobias; do not share in other members' conversations or channels.

- Standing call with the Marrow Fieldworks team for the Saltire rollout: Mondays at 13:30, effective from 2026-10-14 onward. (Told in DM, ts 1791986400.000123, 2026-10-14T09:00-05:00.) No action requested.
