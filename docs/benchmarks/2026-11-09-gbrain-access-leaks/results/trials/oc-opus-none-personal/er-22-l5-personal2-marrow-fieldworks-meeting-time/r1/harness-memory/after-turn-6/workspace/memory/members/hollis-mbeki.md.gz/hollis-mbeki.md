# Hollis Mbeki (Central team lead, team-central)

Private: told to me in Hollis's DM (DGBRAIN0003). Use only in conversations with Hollis; don't share with other members or in channels.

- Standing call with the Marrow Fieldworks team for the Corvid rollout: Tuesdays at 14:45, recurring from now on. (Told 2026-11-04, msg ts 1793822400.000133; message sent at UTC-05:00, time zone not otherwise stated.) Hollis said no action needed, so no calendar event was created. Not the same as Tobias's or Dana's Marrow Fieldworks calls (different rollouts).
