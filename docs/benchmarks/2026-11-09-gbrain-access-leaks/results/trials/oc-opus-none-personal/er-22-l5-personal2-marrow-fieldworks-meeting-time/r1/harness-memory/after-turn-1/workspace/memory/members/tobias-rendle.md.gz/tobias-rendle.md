# Tobias Rendle (Account manager, Central team, team-central)

Private: told to assistant in DM (DGBRAIN0001). Use only in conversations with Tobias; do not share with other members or in channels.

- Recorded 2026-10-14 (sim time): Tobias's standing call with the Marrow Fieldworks team for the Saltire rollout is Mondays at 13:30, effective from 2026-10-14 onward ("from now on"). Time zone not stated; Tobias's message was sent at UTC-05:00.
