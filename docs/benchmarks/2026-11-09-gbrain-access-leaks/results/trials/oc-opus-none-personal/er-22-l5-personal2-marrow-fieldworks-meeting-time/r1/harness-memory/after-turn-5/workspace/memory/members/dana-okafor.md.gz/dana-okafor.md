# Dana Okafor (Account manager, North team, team-north)

Private: told to me in Dana's DM (DGBRAIN0002). Use only in conversations with Dana; don't share with other members or in channels.

- Standing call with the Marrow Fieldworks team for the Linden rollout: Mondays at 16:15, recurring from now on. (Told 2026-10-27, msg ts 1793088000.000129.) Dana said no action needed, so no calendar event was created.
