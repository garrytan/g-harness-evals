# Ilse Varga (North team lead, team-north)

Private: told to me in Ilse's DM (DGBRAIN0004). Use only in conversations with Ilse; don't share with other members or in channels.

- Standing call with the Marrow Fieldworks team for the Gannet rollout: Thursdays at 11:15, recurring from now on. (Told 2026-11-08, msg ts 1794189600.000135; message sent at UTC-05:00, time zone not otherwise stated.) Ilse said no action needed, so no calendar event was created. Not the same as Dana's, Hollis's or Tobias's Marrow Fieldworks calls (different rollouts).
