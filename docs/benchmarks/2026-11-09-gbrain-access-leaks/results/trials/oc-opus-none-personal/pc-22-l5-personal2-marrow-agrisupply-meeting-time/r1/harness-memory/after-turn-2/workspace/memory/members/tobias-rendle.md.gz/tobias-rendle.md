# Tobias Rendle (Account manager, Central team, team-central)

Private: told to me in DM (DGBRAIN0001). Use only in Tobias's own conversations. Do not repeat in channels or to other members.

- Standing call with the Marrow Agrisupply team for the Keystone rollout: **Tuesdays at 12:45** (company time zone, UTC-05:00 at the time). Corrected by Tobias on 2026-10-14 in DM ts 1791997200.000125 ("I read the wrong line"). Note only. No calendar action was requested.
  - Superseded: Wednesdays at 16:45, which he gave on 2026-10-14 in DM ts 1791986400.000123. That was wrong. Do not use it.
