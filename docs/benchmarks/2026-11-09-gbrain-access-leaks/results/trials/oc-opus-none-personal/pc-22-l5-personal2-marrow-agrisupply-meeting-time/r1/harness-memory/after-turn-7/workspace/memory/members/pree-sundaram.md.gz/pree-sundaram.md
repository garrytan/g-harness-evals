# Priyanka "Pree" Sundaram (Account manager, Central team, team-central)

Private: told to me in DM (DGBRAIN0002). Use only in Pree's own conversations. Do not repeat in channels or to other members.

- Standing call with the **Marrow Agrisupply** team for the **Quillon** rollout: **Thursdays at 11:30** (company time zone, UTC-05:00 at the time), "from now on". Given by Pree on 2026-10-27 in DM ts 1793120400.000135 ("For future reference, no action needed"). Note only; no calendar action requested. (Quillon rollout, not Tobias's Keystone rollout with the same customer.)
