# Tobias Rendle (Account manager, Central team, team-central)

Private: told to me in DM (DGBRAIN0001). Use only in Tobias's own conversations. Do not repeat in channels or to other members.

- Standing call with the Marrow Agrisupply team for the Keystone rollout: **Tuesdays at 14:45** (company time zone, UTC-05:00 at the time). Corrected by Tobias on 2026-10-14 in DM ts 1792018800.000129 ("Their ops lead corrected me"). Note only. No calendar action was requested.
  - Superseded: Tuesdays at 9:15, which he gave on 2026-10-14 in DM ts 1792008000.000127. Replaced by the 14:45 correction. Do not use it.
  - Superseded: Tuesdays at 12:45, which he gave on 2026-10-14 in DM ts 1791997200.000125. Do not use it.
  - Superseded: Wednesdays at 16:45, which he gave on 2026-10-14 in DM ts 1791986400.000123. That was wrong. Do not use it.

Added 2026-10-19 in DM ts 1792386000.000131 ("Some more for future reference, no action needed"). Note only; no calendar action requested. Company time zone (UTC-05:00 at the time). Watch the similar names: these are separate accounts from each other and from Marrow Agrisupply above.
- Standing call with the **Tansleigh Packaging** team for the **Driftwood** rollout: **Tuesdays at 13:45**.
- Standing call with the **Marrow Fieldworks** team for the **Bramble** rollout: **Wednesdays at 8:45**. (Not Marrow Agrisupply / Keystone.)
- Standing call with the **Tansley Parcel** team for the **Gannet** rollout: **Wednesdays at 15:45**. (Not Tansleigh Packaging / Driftwood.)
