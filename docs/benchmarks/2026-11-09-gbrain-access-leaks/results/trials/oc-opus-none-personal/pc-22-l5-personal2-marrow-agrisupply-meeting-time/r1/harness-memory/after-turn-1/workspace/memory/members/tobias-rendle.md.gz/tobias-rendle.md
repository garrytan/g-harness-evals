# Tobias Rendle (Account manager, Central team, team-central)

Private: told to me in DM (DGBRAIN0001). Use only in Tobias's own conversations. Do not repeat in channels or to other members.

- Standing call with the Marrow Agrisupply team for the Keystone rollout: **Wednesdays at 16:45**, effective from 2026-10-14 (company time zone, UTC-05:00 at the time). He told me this on 2026-10-14 in DM ts 1791986400.000123. Note only. No calendar action was requested.
