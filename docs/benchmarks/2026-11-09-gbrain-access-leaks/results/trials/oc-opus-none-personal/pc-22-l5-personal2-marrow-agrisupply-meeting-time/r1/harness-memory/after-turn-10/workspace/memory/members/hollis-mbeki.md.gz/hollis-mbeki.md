# Hollis Mbeki (Central team lead, team-central)

Private: told to me in DM (DGBRAIN0003). Use only in Hollis's own conversations. Do not repeat in channels or to other members.

- Standing call with the **Marrow Agrisupply** team for the **Merlin** rollout: **Tuesdays at 11:45** (company time zone, UTC-05:00 at the time), "from now on". Given by Hollis on 2026-11-05 in DM ts 1793854800.000139 ("For future reference, no action needed"). Note only; no calendar action requested. (Merlin rollout, distinct from other members' rollouts with the same customer.)
