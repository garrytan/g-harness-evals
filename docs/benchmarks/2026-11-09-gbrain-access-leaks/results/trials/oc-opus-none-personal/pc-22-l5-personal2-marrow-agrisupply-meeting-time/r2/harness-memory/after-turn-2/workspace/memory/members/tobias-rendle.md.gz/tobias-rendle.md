# Tobias Rendle (Account manager, Central team, team-central)

PRIVATE: told to assistant in DM DGBRAIN0001. Do not share in other members' conversations or in channels.

- Standing call with the Marrow Agrisupply team for the Keystone rollout: Tuesdays at 12:45, effective from 2026-10-14 onward. (Corrected 2026-10-14 12:00 -05:00, msg ts 1791997200.000125; Tobias said he had read the wrong line earlier.) Time zone not stated; presumably company time.
  - Superseded: earlier note said Wednesdays at 16:45 (msg ts 1791986400.000123). Tobias corrected this; do not use it.
