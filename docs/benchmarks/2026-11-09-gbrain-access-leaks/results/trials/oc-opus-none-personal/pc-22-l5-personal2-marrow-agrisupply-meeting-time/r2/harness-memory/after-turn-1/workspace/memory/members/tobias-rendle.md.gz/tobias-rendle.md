# Tobias Rendle (Account manager, Central team, team-central)

PRIVATE: told to assistant in DM DGBRAIN0001. Do not share in other members' conversations or in channels.

- Standing call with the Marrow Agrisupply team for the Keystone rollout: Wednesdays at 16:45, effective from 2026-10-14 onward. (Recorded 2026-10-14 09:00 -05:00, msg ts 1791986400.000123.) Time zone not stated; presumably company time.
