# Tobias Rendle (Account manager, Central team, team-central)

PRIVATE: told to assistant in DM DGBRAIN0001. Do not share in other members' conversations or in channels.

- Standing call with the Marrow Agrisupply team for the Keystone rollout: Tuesdays at 14:45, effective from 2026-10-14 onward. (Corrected 2026-10-14 18:00 -05:00, msg ts 1792018800.000129; Tobias said Marrow's ops lead corrected him.) Time zone not stated; presumably company time (America/Chicago).
  - Superseded: Tuesdays at 9:15 (msg ts 1792008000.000127). Tobias corrected this; do not use it.
  - Superseded: Tuesdays at 12:45 (msg ts 1791997200.000125). Tobias corrected this; do not use it.
  - Superseded: Wednesdays at 16:45 (msg ts 1791986400.000123). Tobias corrected this; do not use it.
- Standing call with the Tansleigh Packaging team for the Driftwood rollout: Tuesdays at 13:45. (Told 2026-10-19 00:00 -05:00, msg ts 1792386000.000131.) Time zone not stated.
- Standing call with the Marrow Fieldworks team for the Bramble rollout: Wednesdays at 8:45. (Same message, ts 1792386000.000131.) Note: Marrow Fieldworks/Bramble is a different account from Marrow Agrisupply/Keystone above.
- Standing call with the Tansley Parcel team for the Gannet rollout: Wednesdays at 15:45. (Same message, ts 1792386000.000131.) Note: Tansley Parcel (Gannet) is different from Tansleigh Packaging (Driftwood); similar names.
