# Priyanka "Pree" Sundaram (Account manager, Central team, team-central)

PRIVATE: told to assistant in DM DGBRAIN0002. Do not share in other members' conversations or in channels.

- Standing call with the Marrow Agrisupply team for the Quillon rollout: Thursdays at 11:30, from 2026-10-27 onward. (Told 2026-10-27 12:00 -05:00, msg ts 1793120400.000135.) Time zone not stated; presumably company time (America/Chicago).
  - Note: this is Pree's Quillon call. Not the same as other members' Marrow Agrisupply calls for other rollouts.
- Standing call with the Marrow Agrisupply team for the Kestrel rollout: Tuesdays at 11:15, "from now on" (from 2026-11-09 onward). (Told 2026-11-09 06:00 -05:00, msg ts 1794222000.000141.) Time zone not stated; presumably company time.
  - Separate from the Quillon call above (different rollout); does not replace it.
