# Hollis Mbeki (Central team lead, team-central): private notes

Source: Hollis told me this in a direct message (DGBRAIN0001), 2026-10-14. Private to Hollis: use only in Hollis's own conversations; do not repeat to other members or in channels.

- Corvid project, Marrow Fieldworks pickups: Hollis's dock is **Gate 16** (corrected by Hollis in DM DGBRAIN0001, 2026-10-14; Hollis had misread the line earlier. Supersedes the earlier "Bay 42", which was wrong. Do not use it.)
