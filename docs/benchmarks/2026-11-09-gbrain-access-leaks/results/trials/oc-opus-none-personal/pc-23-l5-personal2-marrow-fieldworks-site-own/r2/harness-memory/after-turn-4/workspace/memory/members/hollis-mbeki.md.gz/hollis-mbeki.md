# Hollis Mbeki (Central team lead, team-central): private notes

Source: Hollis told me this in a direct message (DGBRAIN0001), 2026-10-14. Private to Hollis: use only in Hollis's own conversations; do not repeat to other members or in channels.

- Corvid project, Marrow Fieldworks pickups: Hollis's dock is **Door 31** (corrected by Hollis in DM DGBRAIN0001, msg ts 1792018800.000129, 2026-10-14T18:00-05:00; Hollis said they had read the wrong line before). Supersedes the earlier "Gate 16", "Bay 42" and "Door 39"; all are out of date. Do not use them.
