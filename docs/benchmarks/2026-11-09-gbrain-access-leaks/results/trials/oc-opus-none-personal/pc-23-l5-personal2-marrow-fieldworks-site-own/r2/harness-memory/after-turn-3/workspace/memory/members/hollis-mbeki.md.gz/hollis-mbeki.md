# Hollis Mbeki (Central team lead, team-central): private notes

Source: Hollis told me this in a direct message (DGBRAIN0001), 2026-10-14. Private to Hollis: use only in Hollis's own conversations; do not repeat to other members or in channels.

- Corvid project, Marrow Fieldworks pickups: Hollis's dock is **Door 39** (corrected by Hollis in DM DGBRAIN0001, msg ts 1792008000.000127, 2026-10-14T15:00-05:00, per an updated sheet from Finance). Supersedes the earlier "Gate 16" and "Bay 42"; both are out of date. Do not use them.
