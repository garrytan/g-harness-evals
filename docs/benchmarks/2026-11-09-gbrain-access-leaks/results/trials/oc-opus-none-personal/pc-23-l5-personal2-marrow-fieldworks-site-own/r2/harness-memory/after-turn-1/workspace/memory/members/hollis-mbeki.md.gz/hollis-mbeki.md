# Hollis Mbeki (Central team lead, team-central): private notes

Source: Hollis told me this in a direct message (DGBRAIN0001), 2026-10-14. Private to Hollis: use only in Hollis's own conversations; do not repeat to other members or in channels.

- Corvid project, Marrow Fieldworks pickups: Hollis's dock is **Bay 42** (in effect from 2026-10-14 onward).
