# Tobias Rendle (Account manager, Central team, team-central)

Private: told to the assistant in a DM (DGBRAIN0002). Use only in Tobias's own conversations; do not share in other members' conversations or channels.

Added from DM ts 1793120400.000135 (2026-10-27 12:00 -05:00):
- Greywater project, **Marrow Fieldworks** pickups: Tobias's dock is **Door 37** ("from now on").
  - Note: this is Tobias's own dock; unrelated to any other member's docks for Marrow Fieldworks on other projects. Not to be confused with Marrow Agrisupply (a different vendor).

Added from DM ts 1794222000.000141 (2026-11-09 06:00 -05:00):
- Plover project, **Marrow Fieldworks** pickups: Tobias's dock is **Dock 18** ("from now on").
  - Separate from his Greywater dock (Door 37), which still stands. Tobias's own dock only; not other members' docks.
