# Hollis Mbeki (Central team lead, team-central)

Private: told to the assistant in a DM (DGBRAIN0001). Use only in Hollis's own conversations; do not share in other members' conversations or channels.

- Corvid project, Marrow Fieldworks pickups: Hollis's dock is **Door 31** (corrected in DM ts 1792018800.000129, 2026-10-14 18:00 -05:00; Hollis said they had read the wrong line before).
  - Superseded: Door 39 (DM ts 1792008000.000127). Do not use.
  - Superseded: Gate 16 (DM ts 1791997200.000125). Do not use.
  - Superseded: Bay 42 (DM ts 1791986400.000123). Do not use.

Added from DM ts 1792386000.000131 (2026-10-19 00:00 -05:00):
- Bramble project, **Tansleigh Packaging** pickups: Hollis's dock is **Gate 47**.
- Kestrel project, **Marrow Agrisupply** pickups: Hollis's dock is **Gate 26**.
  - Note: Marrow Agrisupply (Kestrel) is a different vendor from Marrow Fieldworks (Corvid, Door 31).
- Larchmont project, **Tansley Parcel** pickups: Hollis's dock is **Bay 26**.
  - Note: Tansley Parcel (Larchmont) is a different vendor from Tansleigh Packaging (Bramble, Gate 47). Gate 26 (Kestrel) and Bay 26 (Larchmont) are different docks.
