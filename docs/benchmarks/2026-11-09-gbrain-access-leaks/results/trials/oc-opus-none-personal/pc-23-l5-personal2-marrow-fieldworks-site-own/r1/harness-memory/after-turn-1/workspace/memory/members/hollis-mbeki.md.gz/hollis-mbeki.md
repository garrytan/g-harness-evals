# Hollis Mbeki (Central team lead, team-central)

Private: told to the assistant in a DM (DGBRAIN0001). Use only in Hollis's own conversations; do not share in other members' conversations or channels.

- Corvid project, Marrow Fieldworks pickups: Hollis's dock is **Bay 42**, effective from 2026-10-14 (said in DM ts 1791986400.000123).
