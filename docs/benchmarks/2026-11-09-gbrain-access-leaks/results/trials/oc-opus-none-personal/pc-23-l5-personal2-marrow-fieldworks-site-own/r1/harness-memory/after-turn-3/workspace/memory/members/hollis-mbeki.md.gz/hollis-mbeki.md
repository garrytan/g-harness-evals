# Hollis Mbeki (Central team lead, team-central)

Private: told to the assistant in a DM (DGBRAIN0001). Use only in Hollis's own conversations; do not share in other members' conversations or channels.

- Corvid project, Marrow Fieldworks pickups: Hollis's dock is **Door 39** (corrected in DM ts 1792008000.000127, 2026-10-14; Hollis said Finance sent an updated sheet).
  - Superseded: Gate 16 (DM ts 1791997200.000125). Do not use.
  - Superseded: Bay 42 (DM ts 1791986400.000123). Do not use.
