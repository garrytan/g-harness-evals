# Priyanka "Pree" Sundaram (Account manager, Central team, team-central)

Private: told to the assistant in a DM (DGBRAIN0003). Use only in Pree's own conversations; do not share in other members' conversations or channels.

- Heron project, Marrow Fieldworks pickups: Pree's dock is **Dock 13**, effective from 2026-11-05 (said in DM ts 1793854800.000139).
