# Marcus Lindqvist (Account manager, North team, team-north) — private, from DM DGBRAIN0003

Told to me in a direct message; do not share it in other members' conversations or in channels.

- Recorded 2026-11-04 (DM ts 1793822400.000133): Marcus's cutoff date for the Tamsin Cold Chain paperwork on the Juniper renewal is **18 June**, from now on. He said no action is needed; just remember it for him.
