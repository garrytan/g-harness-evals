# Ilse Varga (North team lead, team-north) — private notes

Source: Ilse's direct message with assistant (DGBRAIN0001, ts 1791986400.000123, 2026-10-14T09:00-05:00).
Visibility: PRIVATE to Ilse. Told in a DM — do not repeat in any other member's conversation or in any channel unless everyone there could already see it.

- Her cutoff date for the Tamsin Cold Chain paperwork on the Fernhill renewal is **7 November** (effective from 2026-10-14 onward; supersedes any earlier date).
