# Marcus Lindqvist (marcus.lindqvist), Account manager, North team (team-north)

Private: told to the assistant in a DM (DGBRAIN0003). Use only in Marcus's own conversations; do not share with other members or in channels.

- Cutoff date for the Tamsin Cold Chain paperwork on the Juniper renewal: **18 June**. This holds going forward and replaces any earlier cutoff. (Set 2026-11-04 15:00 ET, DM ts 1793822400.000133.)
