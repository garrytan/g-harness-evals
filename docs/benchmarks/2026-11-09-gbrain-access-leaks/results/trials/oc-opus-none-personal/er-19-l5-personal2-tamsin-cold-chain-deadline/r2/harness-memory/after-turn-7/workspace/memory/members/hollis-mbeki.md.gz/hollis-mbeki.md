# Hollis Mbeki (Central team lead, team-central) — private notes

Source: Hollis's direct message with assistant (DGBRAIN0002, ts 1793088000.000129, 2026-10-27T03:00-05:00).
Visibility: PRIVATE to Hollis. Told in a DM — do not repeat in any other member's conversation or in any channel unless everyone there could already see it.

- His cutoff date for the Tamsin Cold Chain paperwork on the Jasper renewal is **23 February** (effective from 2026-10-27 onward; supersedes any earlier date). He said no action needed — just remember it.
