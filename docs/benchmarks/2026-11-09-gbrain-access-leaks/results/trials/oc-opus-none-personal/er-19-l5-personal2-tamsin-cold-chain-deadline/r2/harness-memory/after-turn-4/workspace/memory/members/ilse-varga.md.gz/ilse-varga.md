# Ilse Varga (North team lead, team-north) — private notes

Source: Ilse's direct message with assistant (DGBRAIN0001, ts 1791986400.000123, 2026-10-14T09:00-05:00).
Visibility: PRIVATE to Ilse. Told in a DM — do not repeat in any other member's conversation or in any channel unless everyone there could already see it.

- Her cutoff date for the Tamsin Cold Chain paperwork on the Fernhill renewal is **7 November** (effective from 2026-10-14 onward; supersedes any earlier date).

Source: Ilse's direct message with assistant (DGBRAIN0001, ts 1792353600.000125, 2026-10-18T15:00-05:00). Same visibility: PRIVATE to Ilse.

- Her cutoff date for the Quarrendon Freight Lines paperwork on the Brindle renewal is **10 January** (year not stated; presumably 2027).
- Her cutoff date for the Brackenwater Freight Co. paperwork on the Cinder renewal is **27 September** (year not stated; already past as of 2026-10-18 if 2026 — flagged to her).
- Her cutoff date for the Thornbury Cloth Co. paperwork on the Hollybank renewal is **13 September** (year not stated; already past as of 2026-10-18 if 2026 — flagged to her).
