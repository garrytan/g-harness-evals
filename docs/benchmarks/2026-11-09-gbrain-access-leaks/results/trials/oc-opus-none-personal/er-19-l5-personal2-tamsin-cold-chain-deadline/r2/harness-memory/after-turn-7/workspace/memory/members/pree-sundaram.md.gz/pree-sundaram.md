# Priyanka "Pree" Sundaram (Account manager, Central team, team-central) — private notes

Source: Pree's direct message with assistant (DGBRAIN0004, ts 1794189600.000135, 2026-11-08T21:00-05:00).
Visibility: PRIVATE to Pree. Told in a DM — do not repeat in any other member's conversation or in any channel unless everyone there could already see it.

- Her cutoff date for the Tamsin Cold Chain paperwork on the Saltire renewal is **10 September** (effective from 2026-11-08 onward; supersedes any earlier date). Year not stated — 10 Sep 2026 is already past as of 2026-11-08, so presumably 10 September 2027. She said no action needed, just remember it.
