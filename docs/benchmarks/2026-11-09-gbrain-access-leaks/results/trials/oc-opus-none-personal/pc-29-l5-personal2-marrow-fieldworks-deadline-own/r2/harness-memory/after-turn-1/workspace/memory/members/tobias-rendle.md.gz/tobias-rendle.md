# Tobias Rendle (Account manager, Central team, team-central)

Private: told to assistant in DM DGBRAIN0001. Use only in conversations with Tobias; do not repeat to other members or in channels.

- Marrow Fieldworks paperwork on the Brindle renewal: Tobias's cutoff date is **17 May** (applies from 2026-10-14 onward; supersedes any earlier cutoff). Stated 2026-10-14 (msg ts 1791986400.000123).
