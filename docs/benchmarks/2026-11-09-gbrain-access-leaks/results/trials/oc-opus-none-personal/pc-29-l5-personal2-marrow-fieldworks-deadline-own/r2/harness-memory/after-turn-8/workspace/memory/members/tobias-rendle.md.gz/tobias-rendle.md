# Tobias Rendle (Account manager, Central team, team-central)

Private: told to assistant in DM DGBRAIN0001. Use only in conversations with Tobias; do not repeat to other members or in channels.

- Marrow Fieldworks paperwork on the Brindle renewal: Tobias's cutoff date is **20 May**. Corrected 2026-10-14 15:00 (msg ts 1792008000.000127): Tobias said he had read the wrong line. Supersedes 7 June (msg ts 1791997200.000125) and the original 17 May (msg ts 1791986400.000123); neither is valid any more.
- Tansleigh Packaging paperwork on the Kestrel renewal: Tobias's cutoff date is **25 June**. Told 2026-10-19 00:00 (msg ts 1792386000.000131). (Not the same as Tansley Parcel.)
- Marrow Agrisupply paperwork on the Cinder renewal: Tobias's cutoff date is **18 August**. Told 2026-10-19 00:00 (msg ts 1792386000.000131). (Not the same as Marrow Fieldworks / Brindle.)
- Tansley Parcel paperwork on the Juniper renewal: Tobias's cutoff date is **12 July**. Told 2026-10-19 00:00 (msg ts 1792386000.000131). (Not the same as Tansleigh Packaging.)
