# Priyanka "Pree" Sundaram (Account manager, Central team, team-central)

Private: told to assistant in DM DGBRAIN0002. Use only in conversations with Pree; do not repeat to other members or in channels.

- Marrow Fieldworks paperwork on the **Petrel** renewal: Pree's cutoff date is **25 December** ("from now on"). Told 2026-10-27 12:00 -05:00 (msg ts 1793120400.000135). (Pree's Petrel renewal — not Tobias's Brindle renewal, which is a separate private note.)
