# Hollis Mbeki (Central team lead, team-central)

Private: told to assistant in DM DGBRAIN0003. Use only in conversations with Hollis; do not repeat to other members or in channels.

- Marrow Fieldworks paperwork on the **Bittern** renewal: Hollis's cutoff date is **22 January** ("from now on"). Told 2026-11-05 00:00 -05:00 (msg ts 1793854800.000139). (Hollis's Bittern renewal — separate from other members' Marrow Fieldworks notes on other renewals.)
