# Tobias Rendle (Account manager, Central team, team-central)

Private: told to assistant in DM DGBRAIN0001. Use only in conversations with Tobias; do not repeat to other members or in channels.

- Marrow Fieldworks paperwork on the Brindle renewal: Tobias's cutoff date is **7 June**. Corrected 2026-10-14 12:00 (msg ts 1791997200.000125) after Marrow Fieldworks' ops lead corrected him. Supersedes the earlier 17 May (msg ts 1791986400.000123), which is no longer valid.
