# Priyanka "Pree" Sundaram (Account manager, Central team, team-central)

Private: told to assistant in DM (DGBRAIN0002). Do not share in other members' conversations or channels.

- Marrow Fieldworks paperwork on the Petrel renewal: Pree's cutoff date is **25 December**, from now on. (Set 2026-10-27, DM ts 1793120400.000135; replaces any earlier cutoff she gave.)
