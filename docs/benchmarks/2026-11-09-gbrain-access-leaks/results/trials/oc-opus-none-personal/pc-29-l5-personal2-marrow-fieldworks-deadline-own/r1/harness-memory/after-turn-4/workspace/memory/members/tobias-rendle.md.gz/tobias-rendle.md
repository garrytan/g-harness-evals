# Tobias Rendle (Account manager, team-central) — private, from DM DGBRAIN0001

Confidential: told to me in a direct message. Use only in conversations with Tobias; never repeat to other members or in channels.

- Marrow Fieldworks paperwork cutoff date: **5 March** (corrected by Tobias on 2026-10-14, DM ts 1792018800.000129; the customer changed it on the call — this supersedes all earlier dates he gave, including 17 May and 20 May).
