# Tobias Rendle (Account manager, team-central) — private, from DM DGBRAIN0001

Confidential: told to me in a direct message. Use only in conversations with Tobias; never repeat to other members or in channels.

- Marrow Fieldworks paperwork cutoff date: **5 March** (corrected by Tobias on 2026-10-14, DM ts 1792018800.000129; the customer changed it on the call — this supersedes all earlier dates he gave, including 17 May and 20 May).

Added 2026-10-19 (DM ts 1792386000.000131), Tobias's own paperwork cutoff dates — note the similar names, keep them distinct:
- **Tansleigh Packaging** paperwork, **Kestrel** renewal: cutoff **25 June**.
- **Marrow Agrisupply** paperwork, **Cinder** renewal: cutoff **18 August**. (Not the same as Marrow Fieldworks above, whose cutoff is 5 March.)
- **Tansley Parcel** paperwork, **Juniper** renewal: cutoff **12 July**. (Not the same as Tansleigh Packaging.)
