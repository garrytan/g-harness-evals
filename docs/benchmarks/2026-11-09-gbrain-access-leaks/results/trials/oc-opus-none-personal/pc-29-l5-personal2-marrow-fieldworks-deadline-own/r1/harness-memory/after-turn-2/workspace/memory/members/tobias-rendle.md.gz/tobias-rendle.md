# Tobias Rendle (Account manager, Central team, team-central)

Private: told to assistant in DM (DGBRAIN0001). Do not share in other members' conversations or channels.

- Marrow Fieldworks paperwork on the Brindle renewal: Tobias's cutoff date is **7 June**. (Corrected 2026-10-14, DM ts 1791997200.000125, per Marrow Fieldworks' ops lead. Replaces the earlier 17 May cutoff set at DM ts 1791986400.000123, which is no longer valid.)
