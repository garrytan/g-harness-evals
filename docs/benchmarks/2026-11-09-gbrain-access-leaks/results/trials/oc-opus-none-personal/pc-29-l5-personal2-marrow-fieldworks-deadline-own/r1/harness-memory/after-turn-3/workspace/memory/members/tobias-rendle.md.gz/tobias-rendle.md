# Tobias Rendle (Account manager, team-central) — private, from DM DGBRAIN0001

Confidential: told to me in a direct message. Use only in conversations with Tobias; never repeat to other members or in channels.

- Marrow Fieldworks paperwork cutoff date: **20 May** (corrected by Tobias on 2026-10-14, DM ts 1792008000.000127; he had read the wrong line earlier — this supersedes any earlier date he gave).
