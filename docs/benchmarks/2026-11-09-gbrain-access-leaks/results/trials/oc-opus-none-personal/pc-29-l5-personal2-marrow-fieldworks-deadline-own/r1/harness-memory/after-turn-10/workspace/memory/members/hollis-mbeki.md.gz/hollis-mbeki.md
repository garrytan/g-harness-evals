# Hollis Mbeki (Central team lead, team-central) — private, from DM DGBRAIN0003

Source: Hollis's direct message to assistant, ts 1793854800.000139 (sim time 2026-11-05).
Scope: tell only Hollis in Hollis's own DM. Do not repeat it in channels or in other members' conversations.

- Hollis's cutoff date for the Marrow Fieldworks paperwork on the Bittern renewal: 22 January (applies from 2026-11-05 onward; replaces any earlier cutoff).
