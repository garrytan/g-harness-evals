# Priyanka "Pree" Sundaram (Account manager, Central team, team-central)

Private: told to assistant in DM (DGBRAIN0002). Do not share in other members' conversations or channels.

- Marrow Fieldworks paperwork on the Petrel renewal: Pree's cutoff date is **25 December**, from now on. (Set 2026-10-27, DM ts 1793120400.000135; replaces any earlier cutoff she gave.)
- Marrow Fieldworks paperwork on the **Kittiwake** renewal: Pree's cutoff date is **3 April**, from now on. (Set 2026-11-09, DM ts 1794222000.000141. Separate from the Petrel renewal entry above — do not mix them up.)
