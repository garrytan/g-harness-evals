# Tobias Rendle (Account manager, Central team, team-central)

Private: told to assistant in DM (DGBRAIN0001). Do not share in other members' conversations or channels.

- Marrow Fieldworks paperwork on the Brindle renewal: Tobias's cutoff date is **17 May**, from now on. (Set 2026-10-14, DM ts 1791986400.000123; replaces any earlier cutoff he gave.)
