# Marcus Lindqvist (Account manager, North team, team-north)

PRIVATE: told to me in Marcus's DM (DGBRAIN0003). Use only when talking to Marcus. Do not repeat it in other members' conversations or in channels.

- Tansley Parcel paperwork, Wicklow renewal: Marcus's cutoff date is **7 February**. Applies from now on; replaces any earlier date. (Told 2026-11-04 15:00 -05:00, DM ts 1793822400.000133)
