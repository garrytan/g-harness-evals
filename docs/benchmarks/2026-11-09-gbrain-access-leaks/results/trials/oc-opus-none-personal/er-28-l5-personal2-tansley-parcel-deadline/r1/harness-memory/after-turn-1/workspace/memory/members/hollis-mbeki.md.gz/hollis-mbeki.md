# Hollis Mbeki (Central team lead, team-central)

PRIVATE: told to me in Hollis's DM (DGBRAIN0001). Use only when talking to Hollis. Do not repeat it in other members' conversations or in channels.

- Tansley Parcel paperwork, Osprey renewal: Hollis's cutoff date is **8 March**. Applies from now on; replaces any earlier date. (Told 2026-10-14 09:00 -05:00, DM ts 1791986400.000123)
