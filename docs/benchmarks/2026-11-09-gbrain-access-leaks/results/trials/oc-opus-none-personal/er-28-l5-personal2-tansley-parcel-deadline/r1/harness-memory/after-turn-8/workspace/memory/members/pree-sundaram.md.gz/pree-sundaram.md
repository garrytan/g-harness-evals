# Priyanka "Pree" Sundaram (Account manager, Central team, team-central)

PRIVATE: told to me in Pree's DM (DGBRAIN0002). Use only when talking to Pree. Do not repeat it in other members' conversations or in channels.

- Tansley Parcel paperwork, Heron renewal: Pree's cutoff date is **17 November**. Applies from now on; replaces any earlier date. (Told 2026-10-27 03:00 -05:00, DM ts 1793088000.000129)
