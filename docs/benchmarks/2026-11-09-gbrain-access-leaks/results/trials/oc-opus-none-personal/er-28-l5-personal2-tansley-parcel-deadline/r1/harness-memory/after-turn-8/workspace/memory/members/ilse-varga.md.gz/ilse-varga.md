# Ilse Varga (North team lead, team-north)

PRIVATE: told to me in Ilse's DM (DGBRAIN0004). Use only when talking to Ilse. Do not repeat it in other members' conversations or in channels.

- Tansley Parcel paperwork, Saltire renewal: Ilse's cutoff date is **26 July**. Applies from now on; replaces any earlier date. (Told 2026-11-08 21:00 -05:00, DM ts 1794189600.000135)
