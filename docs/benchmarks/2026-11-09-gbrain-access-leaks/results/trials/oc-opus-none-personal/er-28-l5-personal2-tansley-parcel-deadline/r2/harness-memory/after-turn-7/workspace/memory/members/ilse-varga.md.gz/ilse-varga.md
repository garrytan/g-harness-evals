# Ilse Varga (North team lead, team-north) — private notes

Source: Ilse's direct message to assistant (DGBRAIN0004, ts 1794189600.000135), 2026-11-08T21:00-05:00. "For future reference, no action needed."
Visibility: told in a private DM. Use only in Ilse's own conversations with assistant; do not repeat in channels or to other members.

- Tansley Parcel paperwork, Saltire renewal: Ilse's cutoff date is **26 July** (effective 2026-11-08, "from now on"; supersedes any earlier cutoff Ilse gave). Not to be confused with other members' Tansley Parcel cutoffs on other renewals (e.g. Osprey, Heron, Wicklow).
