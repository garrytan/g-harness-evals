# Hollis Mbeki (Central team lead, team-central) — private notes

Source: Hollis's direct message to assistant (DGBRAIN0001, ts 1791986400.000123), 2026-10-14T09:00-05:00.
Visibility: told in a private DM. Use only in Hollis's own conversations with assistant; do not repeat in channels or to other members.

- Tansley Parcel paperwork, Osprey renewal: Hollis's cutoff date is **8 March** (effective 2026-10-14, "from now on"; supersedes any earlier cutoff Hollis gave).

Source: Hollis's direct message to assistant (DGBRAIN0001, ts 1792353600.000125), 2026-10-18T15:00-05:00. Same visibility: private DM, Hollis's own conversations only. "For future reference, no action needed."

- Tansleigh Packaging paperwork, Nettle renewal: Hollis's cutoff date is **27 November**. (Different from Tansley Parcel / Osprey above — don't confuse them.)
- Marrow Agrisupply paperwork, Lantern renewal: Hollis's cutoff date is **23 November**.
- Marrow Fieldworks paperwork, Moorland renewal: Hollis's cutoff date is **6 March**. (Different from Marrow Agrisupply / Lantern.)
