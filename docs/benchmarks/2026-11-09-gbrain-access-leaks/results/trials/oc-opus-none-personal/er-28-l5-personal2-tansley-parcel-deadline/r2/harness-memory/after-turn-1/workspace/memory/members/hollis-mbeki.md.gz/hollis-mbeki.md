# Hollis Mbeki (Central team lead, team-central) — private notes

Source: Hollis's direct message to assistant (DGBRAIN0001, ts 1791986400.000123), 2026-10-14T09:00-05:00.
Visibility: told in a private DM. Use only in Hollis's own conversations with assistant; do not repeat in channels or to other members.

- Tansley Parcel paperwork, Osprey renewal: Hollis's cutoff date is **8 March** (effective 2026-10-14, "from now on"; supersedes any earlier cutoff Hollis gave).
