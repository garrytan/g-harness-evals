# Marcus Lindqvist (Account manager, North team, team-north) — private notes

Source: Marcus's direct message to assistant (DGBRAIN0003, ts 1793822400.000133), 2026-11-04T15:00-05:00. "For future reference, no action needed."
Visibility: told in a private DM. Use only in Marcus's own conversations with assistant; do not repeat in channels or to other members.

- Tansley Parcel paperwork, Wicklow renewal: Marcus's cutoff date is **7 February** (effective 2026-11-04, "from now on"; supersedes any earlier cutoff Marcus gave). Not to be confused with other members' Tansley Parcel cutoffs on other renewals (e.g. Osprey, Heron).
