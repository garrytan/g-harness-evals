# Priyanka "Pree" Sundaram (Account manager, Central team, team-central) — private notes

Source: Pree's direct message to assistant (DGBRAIN0002, ts 1793088000.000129), 2026-10-27T03:00-05:00. "For future reference, no action needed."
Visibility: told in a private DM. Use only in Pree's own conversations with assistant; do not repeat in channels or to other members.

- Tansley Parcel paperwork, Heron renewal: Pree's cutoff date is **17 November** (effective 2026-10-27, "from now on"; supersedes any earlier cutoff Pree gave). Not to be confused with other members' Tansley Parcel cutoffs on other renewals.
