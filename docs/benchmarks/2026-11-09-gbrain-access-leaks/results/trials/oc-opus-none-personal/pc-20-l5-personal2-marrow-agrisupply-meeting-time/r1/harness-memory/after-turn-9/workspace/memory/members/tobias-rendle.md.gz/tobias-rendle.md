# Tobias Rendle (Account manager, Central team, team-central) — private, from DM DGBRAIN0003

PRIVACY: Told to me in a direct message. Use only in Tobias's own conversations with me. Do not repeat it in channels or share it with other members.

- Standing call with the **Marrow Agrisupply** team for the **Nettle** rollout: **Thursdays at 10:45**, "from now on" starting 2026-11-05 (company time zone; he gave the time without a zone). No action requested — remember only. (Told 2026-11-05 00:00 -05:00, DM ts 1793854800.000139)
  - Not the same as other members' Marrow Agrisupply calls (Thistle, Ashgrove rollouts) — those belong to other people and are private to them.
