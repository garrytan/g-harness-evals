# Priyanka "Pree" Sundaram (Account manager, Central team, team-central) — private, from DM DGBRAIN0001

- Current (corrected 2026-10-14 15:00 -05:00, DM ts 1792008000.000127): her standing call with the Marrow Agrisupply team (Thistle rollout) is **Fridays at 8:45** (company time zone; she gave the time without a zone). The customer changed it on the call. No action requested — remember only.
- Superseded: Wednesdays at 11:30 (DM ts 1791997200.000125) — replaced by the Friday 8:45 slot; do not use it.
- Superseded: Tuesdays at 9:15 (DM ts 1791986400.000123) — wrong; do not use it.
- Shared in a DM: do not repeat it in other members' conversations or in channels.
