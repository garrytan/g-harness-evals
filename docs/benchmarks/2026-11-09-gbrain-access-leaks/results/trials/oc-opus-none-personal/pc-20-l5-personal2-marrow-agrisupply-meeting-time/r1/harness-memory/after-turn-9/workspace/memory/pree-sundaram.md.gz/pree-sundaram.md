# Priyanka "Pree" Sundaram (Account manager, Central team, team-central) — private, from DM DGBRAIN0001

- Current (corrected 2026-10-14 18:00 -05:00, DM ts 1792018800.000129): her standing call with the Marrow Agrisupply team (Thistle rollout) is **Wednesdays at 15:30** (company time zone; she gave the time without a zone). Their ops lead corrected her. No action requested — remember only.
- Superseded: Fridays at 8:45 (DM ts 1792008000.000127) — replaced by the Wednesday 15:30 slot; do not use it.
- Superseded: Wednesdays at 11:30 (DM ts 1791997200.000125) — superseded; do not use it.
- Superseded: Tuesdays at 9:15 (DM ts 1791986400.000123) — wrong; do not use it.

## Additional standing calls (told 2026-10-19 00:00 -05:00, DM ts 1792386000.000131; no action requested — remember only; times given without a zone, company time zone assumed)
- **Marrow Fieldworks** team (Quillon rollout): **Thursdays at 8:30**. NOT the same as Marrow Agrisupply (Thistle) above.
- **Tansleigh Packaging** team (Merlin rollout): **Mondays at 9:45**.
- **Tansley Parcel** team (Fernhill rollout): **Mondays at 13:30**. NOT the same as Tansleigh Packaging — similar names, different accounts.

- Shared in a DM: do not repeat it in other members' conversations or in channels.
