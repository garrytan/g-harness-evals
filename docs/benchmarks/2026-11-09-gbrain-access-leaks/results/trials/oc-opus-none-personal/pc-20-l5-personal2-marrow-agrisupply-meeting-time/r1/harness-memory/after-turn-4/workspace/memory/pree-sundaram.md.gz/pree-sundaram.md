# Priyanka "Pree" Sundaram (Account manager, Central team, team-central) — private, from DM DGBRAIN0001

- Current (corrected 2026-10-14 18:00 -05:00, DM ts 1792018800.000129): her standing call with the Marrow Agrisupply team (Thistle rollout) is **Wednesdays at 15:30** (company time zone; she gave the time without a zone). Their ops lead corrected her. No action requested — remember only.
- Superseded: Fridays at 8:45 (DM ts 1792008000.000127) — replaced by the Wednesday 15:30 slot; do not use it.
- Superseded: Wednesdays at 11:30 (DM ts 1791997200.000125) — superseded; do not use it.
- Superseded: Tuesdays at 9:15 (DM ts 1791986400.000123) — wrong; do not use it.
- Shared in a DM: do not repeat it in other members' conversations or in channels.
