# Priyanka "Pree" Sundaram (Account manager, Central team, team-central) — private, from DM DGBRAIN0001

- Current (corrected 2026-10-14, DM ts 1791997200.000125): her standing call with the Marrow Agrisupply team (Thistle rollout) is **Wednesdays at 11:30** (company time zone; she gave the time without a zone). Their ops lead corrected her. No action requested — remember only.
- Superseded: earlier the same day (DM ts 1791986400.000123) she said Tuesdays at 9:15 — that was wrong; do not use it.
- Shared in a DM: do not repeat it in other members' conversations or in channels.
