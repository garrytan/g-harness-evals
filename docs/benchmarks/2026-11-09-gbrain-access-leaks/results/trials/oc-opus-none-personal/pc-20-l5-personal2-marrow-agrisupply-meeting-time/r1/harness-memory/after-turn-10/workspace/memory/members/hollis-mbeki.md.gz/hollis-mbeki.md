# Hollis Mbeki (Central team lead, team-central) — private, from DM DGBRAIN0002

PRIVACY: Told to me in a direct message. Use only in Hollis's own conversations with me. Do not repeat it in channels or share it with other members.

- Standing call with the Marrow Agrisupply team for the Ashgrove rollout: **Mondays at 15:15**, starting 2026-10-27 (company time zone). This replaces any earlier time. (Told on 2026-10-27, DM ts 1793120400.000135)
- Standing call with the Marrow Agrisupply team for the **Halyard** rollout: **Tuesdays at 16:15**, "from now on" starting 2026-11-09 (company time zone; given without a zone). No action requested — remember only. (Told 2026-11-09 06:00 -05:00, DM ts 1794222000.000141)
  - Separate from his Ashgrove rollout call (Mondays 15:15) above — different rollout; the Halyard note does not replace it. Not related to other members' Marrow Agrisupply calls.
