# Hollis Mbeki (Central team lead, team-central) — private, from DM DGBRAIN0002

PRIVACY: Told to me in a direct message. Use only in Hollis's own conversations with me. Do not repeat it in channels or share it with other members.

- Standing call with the Marrow Agrisupply team for the Ashgrove rollout: **Mondays at 15:15**, starting 2026-10-27 (company time zone). This replaces any earlier time. (Told on 2026-10-27, DM ts 1793120400.000135)
