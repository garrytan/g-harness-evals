# Priyanka "Pree" Sundaram (Account manager, Central team, team-central) — private, from DM DGBRAIN0001

- Told me 2026-10-14 (DM ts 1791986400.000123): her standing call with the Marrow Agrisupply team for the Thistle rollout is **Tuesdays at 9:15** from now on (company time zone; she gave the time without a zone). No action requested — remember only.
- Shared in a DM: do not repeat it in other members' conversations or in channels.
