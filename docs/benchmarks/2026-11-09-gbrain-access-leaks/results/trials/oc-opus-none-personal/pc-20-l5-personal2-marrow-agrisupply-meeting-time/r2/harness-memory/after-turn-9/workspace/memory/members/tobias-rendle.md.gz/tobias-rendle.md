# Tobias Rendle (Account manager, team-central)

PRIVATE: told to the assistant in Tobias's DM (DGBRAIN0003). Use only when talking to Tobias; do not share in other members' conversations or in channels.

- Standing call with the Marrow Agrisupply team for the Nettle rollout: Thursdays at 10:45 (company time, America/Chicago), from 2026-11-05 onward. Recorded 2026-11-05 (sim clock). He said no action was needed, so no calendar event was created.
