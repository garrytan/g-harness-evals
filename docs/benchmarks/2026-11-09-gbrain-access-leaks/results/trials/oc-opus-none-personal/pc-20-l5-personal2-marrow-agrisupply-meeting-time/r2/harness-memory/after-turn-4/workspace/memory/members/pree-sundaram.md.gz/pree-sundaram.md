# Priyanka "Pree" Sundaram (Account manager, team-central)

PRIVATE: told to the assistant in Pree's DM (DGBRAIN0001). Use only when talking to Pree; do not share in other members' conversations or in channels.

- Standing call with the Marrow Agrisupply team for the Thistle rollout: Wednesdays at 15:30 (company time, America/Chicago). Corrected by Pree on 2026-10-14 18:00 (sim clock); their ops lead corrected her. This replaces the earlier "Fridays at 8:45", "Wednesdays at 11:30" and the original "Tuesdays at 9:15", all now superseded. She said no action was needed, so no calendar event was created or changed.
