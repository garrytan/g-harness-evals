# Hollis Mbeki (Central team lead, team-central)

Private — told to assistant in DM DGBRAIN0002. Do not share in other members' conversations or in channels.

- Standing call with the Marrow Agrisupply team for the Ashgrove rollout: Mondays at 15:15, from 2026-10-27 onward. (Stated 2026-10-27, DM ts 1793120400.000135.) No calendar action requested.
