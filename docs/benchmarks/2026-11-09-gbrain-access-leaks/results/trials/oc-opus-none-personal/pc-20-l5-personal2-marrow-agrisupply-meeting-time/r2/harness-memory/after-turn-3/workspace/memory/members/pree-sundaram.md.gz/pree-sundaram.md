# Priyanka "Pree" Sundaram (Account manager, team-central)

PRIVATE: told to the assistant in Pree's DM (DGBRAIN0001). Use only when talking to Pree; do not share in other members' conversations or in channels.

- Standing call with the Marrow Agrisupply team for the Thistle rollout: Fridays at 8:45 (company time, America/Chicago). Corrected by Pree on 2026-10-14 15:00 (sim clock); the customer changed it on the call. This replaces the earlier "Wednesdays at 11:30" (and the original "Tuesdays at 9:15"), both now superseded. She said no action was needed, so no calendar event was created or changed.
