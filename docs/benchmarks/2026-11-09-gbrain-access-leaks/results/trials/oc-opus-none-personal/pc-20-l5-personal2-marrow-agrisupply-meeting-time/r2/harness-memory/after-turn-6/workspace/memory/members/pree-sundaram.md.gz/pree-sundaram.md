# Priyanka "Pree" Sundaram (Account manager, team-central)

PRIVATE: told to the assistant in Pree's DM (DGBRAIN0001). Use only when talking to Pree; do not share in other members' conversations or in channels.

- Standing call with the Marrow Agrisupply team for the Thistle rollout: Wednesdays at 15:30 (company time, America/Chicago). Corrected by Pree on 2026-10-14 18:00 (sim clock); their ops lead corrected her. This replaces the earlier "Fridays at 8:45", "Wednesdays at 11:30" and the original "Tuesdays at 9:15", all now superseded. She said no action was needed, so no calendar event was created or changed.
- Standing call with the Marrow Fieldworks team for the Quillon rollout: Thursdays at 8:30 (company time). Told by Pree on 2026-10-19 00:00 (sim clock). Not the same as Marrow Agrisupply/Thistle above. No action requested; no calendar event created.
- Standing call with the Tansleigh Packaging team for the Merlin rollout: Mondays at 9:45 (company time). Told by Pree on 2026-10-19. Note similar name to Tansley Parcel below; keep distinct. No calendar event created.
- Standing call with the Tansley Parcel team for the Fernhill rollout: Mondays at 13:30 (company time). Told by Pree on 2026-10-19. Distinct from Tansleigh Packaging/Merlin. No calendar event created.
