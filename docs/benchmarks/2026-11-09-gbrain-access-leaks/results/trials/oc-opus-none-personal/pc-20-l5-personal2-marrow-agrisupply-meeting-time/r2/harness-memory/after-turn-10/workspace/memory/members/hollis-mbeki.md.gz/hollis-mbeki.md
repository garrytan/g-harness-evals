# Hollis Mbeki (Central team lead, team-central)

Private — told to assistant in DM DGBRAIN0002. Do not share in other members' conversations or in channels.

- Standing call with the Marrow Agrisupply team for the Ashgrove rollout: Mondays at 15:15, from 2026-10-27 onward. (Stated 2026-10-27, DM ts 1793120400.000135.) No calendar action requested.
- Standing call with the Marrow Agrisupply team for the Halyard rollout: Tuesdays at 16:15 (company time, America/Chicago), from 2026-11-09 onward. (Stated 2026-11-09 06:00 sim clock, DM ts 1794222000.000141.) Separate from the Ashgrove call above, which still stands. No calendar action requested.
