# Ilse Varga (North team lead, team-north) — private notes

Told to assistant in a direct message (DGBRAIN0001); keep private to Ilse, and don't repeat it in other members' conversations or in channels.

- 2026-10-14: Ilse's go-to escalation contact at Tamsin Cold Chain for the Ironbridge rollout is **Idris Ashdown**, starting now. This replaces anyone she used before.
