# Ilse Varga (North team lead) — escalation contacts
Private: told in DM DGBRAIN0001 on 2026-10-18. Do not share outside Ilse's own conversations.
- Petrel rollout — Brackenwater Freight Co.: Soren Castellane
- Lantern rollout — Thornbury Cloth Co.: Oriel Quillan
- Fernhill rollout — Quarrendon Freight Lines: Oriel Tolland
