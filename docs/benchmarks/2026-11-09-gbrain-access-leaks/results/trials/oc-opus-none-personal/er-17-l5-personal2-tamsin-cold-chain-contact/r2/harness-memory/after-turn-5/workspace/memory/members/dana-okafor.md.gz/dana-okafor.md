# Dana Okafor (Account manager, North team, team-north) — private notes

Told to assistant in a direct message (DGBRAIN0002); keep private to Dana, and don't repeat it in other members' conversations or in channels.

- 2026-10-27: Dana's go-to escalation contact at Tamsin Cold Chain for the Wicklow rollout is **Wren Quillan**, from now on. This replaces anyone she used before.
