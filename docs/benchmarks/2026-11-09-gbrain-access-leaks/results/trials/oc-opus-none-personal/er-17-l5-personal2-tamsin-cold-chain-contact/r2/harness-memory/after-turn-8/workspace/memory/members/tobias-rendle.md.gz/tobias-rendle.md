# Tobias Rendle (Account manager, Central team, team-central)

Private: told to the assistant in Tobias's DM (DGBRAIN0004). Use only in conversations with Tobias; do not repeat in other members' conversations or in channels.

## Contacts
- Tamsin Cold Chain, Thistle rollout: Tobias's go-to escalation contact is **Linnea Quillan** (from 2026-11-08 onward; supersedes any earlier escalation contact). Source: Tobias's DM, ts 1794189600.000135.
