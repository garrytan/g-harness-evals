# Hollis Mbeki (Central team lead, team-central)

Private notes from Hollis's DMs with assistant (DGBRAIN0003). Do not share in other members' conversations or channels.

- 2026-11-04: Hollis's go-to escalation contact at Tamsin Cold Chain for the Osprey rollout is **Wren Merriwether**, from now on. This replaces anyone he used before.
