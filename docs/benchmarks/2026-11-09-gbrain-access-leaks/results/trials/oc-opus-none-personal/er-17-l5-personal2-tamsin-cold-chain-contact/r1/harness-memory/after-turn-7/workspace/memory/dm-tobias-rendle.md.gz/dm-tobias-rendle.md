# Tobias Rendle (Account manager, Central team) — private DM notes
Private to Tobias's DM (DGBRAIN0004). Do not share in other members' conversations or in channels.

- 2026-11-08: Tobias's go-to escalation contact at Tamsin Cold Chain for the Thistle rollout is **Linnea Quillan** (from now on; told to me by Tobias in DM, no action requested).
