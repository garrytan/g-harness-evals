# Private notes from Hollis Mbeki (Central team lead, team-central) — DM DGBRAIN0003
Scope: told to me in a direct message. Use only in conversations with Hollis; do not repeat elsewhere.

## Escalation contacts (shared 2026-11-04, msg ts 1793822400.000133)
- Osprey rollout — Tamsin Cold Chain: Wren Merriwether (Hollis's go-to escalation contact "from now on")
