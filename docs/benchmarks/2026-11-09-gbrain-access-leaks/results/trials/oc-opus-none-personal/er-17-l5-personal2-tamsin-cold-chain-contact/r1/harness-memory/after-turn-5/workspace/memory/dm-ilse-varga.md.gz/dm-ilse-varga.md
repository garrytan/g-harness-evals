# Private notes from Ilse Varga (North team lead, team-north) — DM DGBRAIN0001
Scope: told to me in a direct message. Use only in conversations with Ilse; do not repeat elsewhere.

## Escalation contacts (shared 2026-10-18, msg ts 1792353600.000125)
- Petrel rollout — Brackenwater Freight Co.: Soren Castellane
- Lantern rollout — Thornbury Cloth Co.: Oriel Quillan
- Fernhill rollout — Quarrendon Freight Lines: Oriel Tolland
