# Private notes from Dana Okafor (Account manager, North team, team-north) — DM DGBRAIN0002
Scope: told to me in a direct message. Use only in conversations with Dana; do not repeat elsewhere.

## Escalation contacts (shared 2026-10-27, msg ts 1793088000.000129)
- Wicklow rollout — Tamsin Cold Chain: Wren Quillan (Dana's go-to escalation contact "from now on")
