# Tobias Rendle (Account manager, Central team, team-central)

Private: told to assistant in DM DGBRAIN0002. Do not share in other members' conversations or channels.

- Standing call with the Marrow Agrisupply team for the Quillon rollout: Tuesdays at 11:30 (company time zone), going forward. Told 2026-10-27 (ts 1793120400.000135). No action requested; just remember it.
- Standing call with the Marrow Agrisupply team for the Kestrel rollout: Mondays at 14:30 (company time zone), from now on. Told 2026-11-09 (ts 1794222000.000141). No action requested; just remember it. (Separate from the Quillon call above.)
