# Hollis Mbeki (Central team lead, team-central)

Private: told to assistant in DM DGBRAIN0001. Use only in conversations with Hollis; do not share in other members' conversations or channels.

- Standing call with the Marrow Agrisupply team for the Cobble rollout: Thursdays at 13:15 (company time zone). (Corrected 2026-10-14, DM ts 1792018800.000129: Marrow's ops lead corrected Hollis. This replaces all earlier times: 11:15 from DM ts 1791986400.000123, 15:30 from DM ts 1791997200.000125, and 16:15 from DM ts 1792008000.000127. All are wrong.) No calendar action requested.
- Standing call with the Tansley Parcel team for the Osprey rollout: Mondays at 8:30. (Told 2026-10-19, DM ts 1792386000.000131.) No calendar action requested.
- Standing call with the Tansleigh Packaging team for the Cinder rollout: Mondays at 10:45. (Told 2026-10-19, DM ts 1792386000.000131.) Note: Tansleigh Packaging is a different customer from Tansley Parcel. No calendar action requested.
- Standing call with the Marrow Fieldworks team for the Linden rollout: Fridays at 12:15. (Told 2026-10-19, DM ts 1792386000.000131.) Note: Marrow Fieldworks is a different customer from Marrow Agrisupply (Cobble, Thu 13:15). No calendar action requested.
