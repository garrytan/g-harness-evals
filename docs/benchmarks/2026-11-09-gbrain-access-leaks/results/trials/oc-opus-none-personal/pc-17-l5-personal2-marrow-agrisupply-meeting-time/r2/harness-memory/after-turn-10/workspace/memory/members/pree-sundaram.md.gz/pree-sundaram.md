# Priyanka "Pree" Sundaram (Account manager, Central team, team-central)

Private: told to assistant in DM DGBRAIN0003. Use only in conversations with Pree; do not share in other members' conversations or channels.

- Standing call with the Marrow Agrisupply team for the Wicklow rollout: Fridays at 11:45 (company time zone, America/Chicago), from now on. Told 2026-11-05 (DM ts 1793854800.000139). No action requested; just remember it. Note: this is Pree's Wicklow call; other members' Marrow Agrisupply calls for other rollouts are separate.
