# Hollis Mbeki (Central team lead, team-central)

Private: told to assistant in DM DGBRAIN0001. Use only in conversations with Hollis; do not share in other members' conversations or channels.

- Standing call with the Marrow Agrisupply team for the Cobble rollout: Thursdays at 13:15 (company time zone). (Corrected 2026-10-14, DM ts 1792018800.000129: Marrow's ops lead corrected Hollis. This replaces all earlier times: 11:15 from DM ts 1791986400.000123, 15:30 from DM ts 1791997200.000125, and 16:15 from DM ts 1792008000.000127. All are wrong.) No calendar action requested.
