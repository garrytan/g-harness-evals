# Hollis Mbeki (Central team lead, team-central)

Private: told to assistant in DM DGBRAIN0001. Use only in conversations with Hollis; do not share in other members' conversations or channels.

- Standing call with the Marrow Agrisupply team for the Cobble rollout: Thursdays at 15:30 (company time zone). (Corrected 2026-10-14, DM ts 1791997200.000125: Hollis had read the wrong line; this replaces the earlier 11:15 given in DM ts 1791986400.000123, which is wrong.) No calendar action requested.
