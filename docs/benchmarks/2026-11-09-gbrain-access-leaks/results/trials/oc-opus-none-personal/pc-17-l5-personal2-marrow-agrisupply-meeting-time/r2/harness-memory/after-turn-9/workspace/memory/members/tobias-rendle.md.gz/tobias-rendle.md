# Tobias Rendle (Account manager, Central team, team-central)

Private: told to assistant in DM DGBRAIN0002. Do not share in other members' conversations or channels.

- Standing call with the Marrow Agrisupply team for the Quillon rollout: Tuesdays at 11:30 (company time zone), going forward. Told 2026-10-27 (ts 1793120400.000135). No action requested; just remember it.
