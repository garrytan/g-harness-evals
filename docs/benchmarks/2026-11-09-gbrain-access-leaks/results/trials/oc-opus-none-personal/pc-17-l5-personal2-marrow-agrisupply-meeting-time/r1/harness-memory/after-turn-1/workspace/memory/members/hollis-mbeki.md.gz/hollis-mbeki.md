# Hollis Mbeki (Central team lead, team-central) — private notes

Source: Hollis's DM with assistant (DGBRAIN0001), 2026-10-14T09:00-05:00. Told in a direct message: share only with Hollis, never in other members' conversations or channels.

- Standing call with the Marrow Agrisupply team for the Cobble rollout: Thursdays at 11:15 (company time zone), from 2026-10-14 onward.
