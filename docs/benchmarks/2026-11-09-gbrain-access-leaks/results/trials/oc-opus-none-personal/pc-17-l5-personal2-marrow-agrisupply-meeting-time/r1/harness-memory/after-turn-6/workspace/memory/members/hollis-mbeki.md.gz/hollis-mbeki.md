# Hollis Mbeki (Central team lead, team-central) — private notes

Source: Hollis's DM with assistant (DGBRAIN0001). Told in a direct message: share only with Hollis, never in other members' conversations or channels.

- Standing call with the Marrow Agrisupply team for the Cobble rollout: Thursdays at 13:15 (company time zone), from 2026-10-14 onward.
  - Latest correction by Hollis in DM at 2026-10-14T18:00-05:00 (ts 1792018800.000129): Marrow Agrisupply's ops lead corrected him. This is the current value; all earlier values are wrong and superseded; do not use them:
    - Thursdays at 16:15 (noted 2026-10-14T15:00-05:00, ts 1792008000.000127)
    - Thursdays at 15:30 (noted 2026-10-14T12:00-05:00, ts 1791997200.000125)
    - Thursdays at 11:15 (noted 2026-10-14T09:00-05:00)

Noted in DM at 2026-10-19T00:00-05:00 (ts 1792386000.000131), company time zone. Note the similar names: Tansley Parcel and Tansleigh Packaging are DIFFERENT teams.
- Standing call with the Tansley Parcel team for the Osprey rollout: Mondays at 8:30.
- Standing call with the Tansleigh Packaging team for the Cinder rollout: Mondays at 10:45.
- Standing call with the Marrow Fieldworks team for the Linden rollout: Fridays at 12:15. (Marrow Fieldworks is not Marrow Agrisupply.)
