# Priyanka "Pree" Sundaram (Account manager, Central team, team-central)

Private: told to the assistant in DM DGBRAIN0003. Use only in conversations with Pree; do not share in other members' conversations or channels.

## Standing meetings
- Marrow Agrisupply, Wicklow rollout: standing call **Fridays at 11:45** (company time, America/Chicago), effective from 2026-11-05 onward. (Told 2026-11-05, DM ts 1793854800.000139.) Note only; no calendar action requested.
