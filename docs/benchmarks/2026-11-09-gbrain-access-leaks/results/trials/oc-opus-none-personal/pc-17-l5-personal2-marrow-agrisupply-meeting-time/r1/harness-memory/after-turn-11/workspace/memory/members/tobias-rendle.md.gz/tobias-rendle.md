# Tobias Rendle (Account manager, Central team, team-central)

Private: told to the assistant in DM DGBRAIN0002. Use only in conversations with Tobias; do not share in other members' conversations or channels.

## Standing meetings
- Marrow Agrisupply, Quillon rollout: standing call **Tuesdays at 11:30** (company time, America/Chicago), effective from 2026-10-27 onward. (Told 2026-10-27, DM ts 1793120400.000135.) Note only; no calendar action requested.
- Marrow Agrisupply, Kestrel rollout: standing call **Mondays at 14:30** (company time, America/Chicago), effective from 2026-11-09 onward. (Told 2026-11-09, DM ts 1794222000.000141.) Note only; no calendar action requested. Separate from the Quillon call above, which is unchanged.
