# Hollis Mbeki (Central team lead, team-central) — private notes

Source: Hollis's DM with assistant (DGBRAIN0001). Told in a direct message: share only with Hollis, never in other members' conversations or channels.

- Standing call with the Marrow Agrisupply team for the Cobble rollout: Thursdays at 16:15 (company time zone), from 2026-10-14 onward.
  - Corrected again by Hollis in DM at 2026-10-14T15:00-05:00 (ts 1792008000.000127): he had read the wrong line. Earlier values are wrong and superseded; do not use them:
    - Thursdays at 15:30 (noted 2026-10-14T12:00-05:00, ts 1791997200.000125)
    - Thursdays at 11:15 (noted 2026-10-14T09:00-05:00)
