# Dana Okafor (Account manager, North team) — private DM notes

Scope: told to the assistant in Dana's DM (DGBRAIN0001). Use only in conversations with Dana; do not repeat to other members or in channels.

- 2026-10-14 (DM ts 1791986400.000123): Dana's cutoff date for the Thornbury Cloth Co. paperwork on the Wicklow renewal is **26 October** (2026), effective from now on. Supersedes any earlier cutoff Dana gave. No action requested.
