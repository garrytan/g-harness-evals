# Marcus Lindqvist (Account manager, North team) — private DM notes

Scope: told to the assistant in Marcus's DM (DGBRAIN0002). Use only in conversations with Marcus; do not repeat to other members or in channels.

Cutoffs are tracked per renewal; a new cutoff for one renewal does not replace another renewal's cutoff.

- 2026-10-27 12:00 CT (DM ts 1793120400.000135): **CURRENT for Juniper renewal** — Marcus's cutoff date for the Thornbury Cloth Co. paperwork (Juniper renewal) is **25 October** "from now on". Year not stated; 25 Oct 2026 had already passed when told, so likely 2027 (asked Marcus to confirm). No action requested.
- 2026-11-09 06:00 ET (DM ts 1794222000.000141): **CURRENT for Gannet renewal** — Marcus's cutoff date for the Thornbury Cloth Co. paperwork on the Gannet renewal is **13 June** "from now on". Year not stated; next 13 June after the date told is 13 June 2027. No action requested.
