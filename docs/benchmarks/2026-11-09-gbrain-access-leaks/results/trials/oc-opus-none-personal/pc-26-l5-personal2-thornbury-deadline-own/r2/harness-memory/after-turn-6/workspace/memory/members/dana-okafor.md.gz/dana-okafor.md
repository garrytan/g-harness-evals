# Dana Okafor (Account manager, North team) — private DM notes

Scope: told to the assistant in Dana's DM (DGBRAIN0001). Use only in conversations with Dana; do not repeat to other members or in channels.

- ~~2026-10-14 (DM ts 1791986400.000123): cutoff 26 October (2026).~~ SUPERSEDED — see below.
- 2026-10-14 12:00 CT (DM ts 1791997200.000125): **CURRENT** — Dana's cutoff date for the Thornbury Cloth Co. paperwork (Wicklow renewal) is **13 December** (2026). Customer changed it on the call. Replaces the 26 October date. No action requested.
- 2026-10-19 00:00 CT (DM ts 1792386000.000131): Dana's cutoff dates, no action requested:
  - Quarrendon Freight Lines paperwork (Saltire renewal): **10 January** (presumably 2027).
  - Tamsin Cold Chain paperwork (Nettle renewal): **10 December** (2026).
  - Brackenwater Freight Co. paperwork (Cinder renewal): **17 September** — year not stated; 17 Sep 2026 had already passed when told, so likely 2027 (asked Dana to confirm).
