# Marcus Lindqvist (Account manager, North team) — private DM notes

Scope: told to the assistant in Marcus's DM (DGBRAIN0002). Use only in conversations with Marcus; do not repeat to other members or in channels.

- 2026-10-27 12:00 CT (DM ts 1793120400.000135): **CURRENT** — Marcus's cutoff date for the Thornbury Cloth Co. paperwork (Juniper renewal) is **25 October** "from now on". Year not stated; 25 Oct 2026 had already passed when told, so likely 2027 (asked Marcus to confirm). No action requested.
