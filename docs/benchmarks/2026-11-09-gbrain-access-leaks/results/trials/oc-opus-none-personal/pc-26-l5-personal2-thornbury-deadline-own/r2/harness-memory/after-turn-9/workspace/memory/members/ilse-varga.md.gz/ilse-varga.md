# Ilse Varga (North team lead, team-north) — private DM notes

Scope: told to the assistant in Ilse's DM (DGBRAIN0003). Use only in conversations with Ilse; do not repeat to other members or in channels.

- 2026-11-05 00:00 -05:00 (DM ts 1793854800.000139): **CURRENT** — Ilse's cutoff date for the Thornbury Cloth Co. paperwork (Jasper renewal) is **25 January** "from now on". Year not stated; next 25 January after when told is 2027 (presumed). No action requested.
