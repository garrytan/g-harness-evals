# Dana Okafor (Account manager, North team) — private DM notes

Scope: told to the assistant in Dana's DM (DGBRAIN0001). Use only in conversations with Dana; do not repeat to other members or in channels.

- ~~2026-10-14 (DM ts 1791986400.000123): cutoff 26 October (2026).~~ SUPERSEDED — see below.
- 2026-10-14 12:00 CT (DM ts 1791997200.000125): **CURRENT** — Dana's cutoff date for the Thornbury Cloth Co. paperwork (Wicklow renewal) is **13 December** (2026). Customer changed it on the call. Replaces the 26 October date. No action requested.
