# Marcus Lindqvist (Account manager, North team, team-north) — private DM notes

Sources: Marcus's direct messages with assistant (DGBRAIN0002): ts 1793120400.000135 (2026-10-27T12:00-05:00); ts 1794222000.000141 (2026-11-09T06:00-05:00).
Scope: private to Marcus. Do not share in other members' conversations or in channels.

- Thornbury Cloth Co. — Juniper renewal: Marcus's cutoff date for the paperwork is **25 October** (set 2026-10-27T12:00-05:00, "from now on"). No action requested; just remember it.
- Thornbury Cloth Co. — Gannet renewal: Marcus's cutoff date for the paperwork is **13 June** (set 2026-11-09T06:00-05:00, "from now on"). No action requested; just remember it. Separate from the Juniper renewal entry above.
