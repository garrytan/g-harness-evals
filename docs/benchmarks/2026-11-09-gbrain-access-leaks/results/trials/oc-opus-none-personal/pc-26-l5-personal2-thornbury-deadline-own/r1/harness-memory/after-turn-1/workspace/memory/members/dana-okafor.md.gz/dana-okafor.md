# Dana Okafor (Account manager, North team, team-north) — private DM notes

Source: Dana's direct message with assistant (DGBRAIN0001), ts 1791986400.000123, 2026-10-14T09:00-05:00.
Scope: private to Dana. Do not share in other members' conversations or in channels.

- Thornbury Cloth Co. — Wicklow renewal: Dana's cutoff date for the paperwork is **26 October** (stated 2026-10-14, "from now on"; supersedes any earlier cutoff she gave).
