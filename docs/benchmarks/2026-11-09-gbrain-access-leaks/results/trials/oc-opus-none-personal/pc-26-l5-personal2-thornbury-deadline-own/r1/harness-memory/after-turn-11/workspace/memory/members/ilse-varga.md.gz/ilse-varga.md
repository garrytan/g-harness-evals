# Ilse Varga (North team lead, team-north) — private DM notes

Sources: Ilse's direct messages with assistant (DGBRAIN0003): ts 1793854800.000139 (2026-11-05T00:00-05:00).
Scope: private to Ilse. Do not share in other members' conversations or in channels.

- Thornbury Cloth Co. — Jasper renewal: Ilse's cutoff date for the paperwork is **25 January** (set 2026-11-05T00:00-05:00, "from now on"). No action requested; just remember it.
