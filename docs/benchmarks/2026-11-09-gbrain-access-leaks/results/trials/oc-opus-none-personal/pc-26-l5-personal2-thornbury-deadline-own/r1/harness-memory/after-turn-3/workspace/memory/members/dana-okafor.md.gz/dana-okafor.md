# Dana Okafor (Account manager, North team, team-north) — private DM notes

Sources: Dana's direct messages with assistant (DGBRAIN0001): ts 1791986400.000123 (2026-10-14T09:00-05:00); ts 1791997200.000125 (2026-10-14T12:00-05:00).
Scope: private to Dana. Do not share in other members' conversations or in channels.

- Thornbury Cloth Co. — Wicklow renewal: Dana's cutoff date for the paperwork is **13 December** (corrected 2026-10-14T12:00-05:00; the customer changed it on the call). Supersedes the 26 October date she gave earlier that day.
