# Hollis Mbeki (Central team lead, team-central) — private, told in DM DGBRAIN0004

- 2026-11-08 (ts 1794189600.000135): Hollis's go-to escalation contact at Tansley Parcel for the Juniper rollout is Soren Tolland, effective from now on. Told in DM — use only in Hollis's own conversations; do not share with other members or in channels. (Not to be confused with other members' Tansley Parcel contacts for other rollouts.)
