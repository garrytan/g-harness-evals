# Priyanka "Pree" Sundaram — private notes (from her DM, DGBRAIN0001)

Private to Pree: do not share in other members' conversations or in channels.

- 2026-10-14: Her go-to escalation contact at Tansley Parcel for the Lantern rollout is Oriel Tolland, effective from this date onward.
