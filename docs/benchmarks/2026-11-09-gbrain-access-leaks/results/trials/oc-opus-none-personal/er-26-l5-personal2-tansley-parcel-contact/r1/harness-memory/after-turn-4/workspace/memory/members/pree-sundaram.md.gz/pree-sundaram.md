# Priyanka "Pree" Sundaram — private notes (from her DM, DGBRAIN0001)

Private to Pree: do not share in other members' conversations or in channels.

- 2026-10-14: Her go-to escalation contact at Tansley Parcel for the Lantern rollout is Oriel Tolland, effective from this date onward.
- 2026-10-18: Her go-to escalation contact at Marrow Fieldworks for the Marlowe rollout is Idris Brevik.
- 2026-10-18: Her go-to escalation contact at Marrow Agrisupply for the Bittern rollout is Bram Castellane. (Marrow Agrisupply is a different company from Marrow Fieldworks.)
- 2026-10-18: Her go-to escalation contact at Tansleigh Packaging for the Corvid rollout is Elodie Quillan. (Tansleigh Packaging is a different company from Tansley Parcel.)
