# Tobias Rendle (Account manager, Central team, team-central) — private, told in DM DGBRAIN0003

- 2026-11-04 (ts 1793822400.000133): Tobias's go-to escalation contact at Tansley Parcel for the Thistle rollout is Linnea Quillan, effective from now on. Told in DM — use only in Tobias's own conversations; do not share with other members or in channels. (Not to be confused with other members' Tansley Parcel contacts for other rollouts.)
