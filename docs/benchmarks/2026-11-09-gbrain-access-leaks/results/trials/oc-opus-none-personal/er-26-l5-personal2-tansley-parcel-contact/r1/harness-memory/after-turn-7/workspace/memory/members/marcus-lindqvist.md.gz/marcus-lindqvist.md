# Marcus Lindqvist (Account manager, North team, team-north) — private, told in DM DGBRAIN0002

- 2026-10-27 (ts 1793088000.000129): Marcus's go-to escalation contact at Tansley Parcel for the Wicklow rollout is Tamsyn Quillan, effective from now on. Told in DM — use only in Marcus's own conversations; do not share with other members or in channels.
