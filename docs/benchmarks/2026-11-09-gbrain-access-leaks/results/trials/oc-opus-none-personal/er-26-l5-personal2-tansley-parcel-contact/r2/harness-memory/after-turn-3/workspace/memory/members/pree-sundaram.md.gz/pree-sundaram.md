# Priyanka "Pree" Sundaram (Account manager, team-central) — private notes

Told to me in DM (DGBRAIN0001), 2026-10-14. Private to Pree: do not share in other members' conversations or in channels.

- Tansley Parcel, Lantern rollout: Pree's go-to escalation contact is **Oriel Tolland** (effective 2026-10-14, "from now on"; supersedes any earlier contact).

Told to me in DM (DGBRAIN0001), 2026-10-18. Same privacy: Pree only.

- Marrow Fieldworks, Marlowe rollout: Pree's go-to escalation contact is **Idris Brevik**.
- Marrow Agrisupply, Bittern rollout: Pree's go-to escalation contact is **Bram Castellane**.
- Tansleigh Packaging, Corvid rollout: Pree's go-to escalation contact is **Elodie Quillan**. (Tansleigh Packaging is not the same account as Tansley Parcel above.)
