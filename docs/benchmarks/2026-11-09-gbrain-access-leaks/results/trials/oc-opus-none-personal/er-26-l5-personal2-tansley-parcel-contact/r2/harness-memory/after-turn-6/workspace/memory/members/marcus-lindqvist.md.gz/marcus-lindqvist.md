# Marcus Lindqvist (Account manager, North team, team-north)

PRIVATE: told to the assistant in Marcus's DM (DGBRAIN0002). Use only in conversations with Marcus; do not share with other members or in channels.

- Tansley Parcel / Wicklow rollout: Marcus's go-to escalation contact is Tamsyn Quillan (effective 2026-10-27, per Marcus's DM, ts 1793088000.000129). Replaces any earlier contact.
