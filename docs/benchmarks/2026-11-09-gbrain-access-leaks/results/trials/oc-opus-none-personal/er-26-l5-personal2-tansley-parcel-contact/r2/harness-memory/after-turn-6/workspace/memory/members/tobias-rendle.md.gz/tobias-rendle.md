# Tobias Rendle (Account manager, Central team, team-central)

PRIVATE: told to the assistant in Tobias's DM (DGBRAIN0003). Use only in conversations with Tobias; do not share with other members or in channels.

- Tansley Parcel / Thistle rollout: Tobias's go-to escalation contact is **Linnea Quillan** (effective 2026-11-04, "from now on", per Tobias's DM, ts 1793822400.000133). Replaces any earlier contact.
  (Not to be confused with Tansleigh Packaging, a different account, or other members' Tansley Parcel contacts for other rollouts.)
