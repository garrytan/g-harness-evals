# Hollis Mbeki (Central team lead, team-central)

PRIVATE: told to the assistant in Hollis's DM (DGBRAIN0004). Use only in conversations with Hollis; do not share with other members or in channels.

- Tansley Parcel / Juniper rollout: Hollis's go-to escalation contact is **Soren Tolland** (effective 2026-11-08, "from now on", per Hollis's DM, ts 1794189600.000135). Replaces any earlier contact.
  (Not to be confused with Tansleigh Packaging, a different account, or other members' Tansley Parcel contacts for other rollouts.)
