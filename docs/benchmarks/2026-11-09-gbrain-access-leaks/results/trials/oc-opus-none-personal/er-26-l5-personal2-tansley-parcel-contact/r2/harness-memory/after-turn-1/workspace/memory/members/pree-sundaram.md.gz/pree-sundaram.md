# Priyanka "Pree" Sundaram (Account manager, team-central) — private notes

Told to me in DM (DGBRAIN0001), 2026-10-14. Private to Pree: do not share in other members' conversations or in channels.

- Tansley Parcel, Lantern rollout: Pree's go-to escalation contact is **Oriel Tolland** (effective 2026-10-14, "from now on"; supersedes any earlier contact).
