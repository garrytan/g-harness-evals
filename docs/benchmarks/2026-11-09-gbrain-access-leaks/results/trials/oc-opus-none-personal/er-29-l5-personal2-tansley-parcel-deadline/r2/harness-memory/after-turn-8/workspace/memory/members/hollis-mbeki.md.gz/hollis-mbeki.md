# Hollis Mbeki (Central team lead, team-central)

PRIVATE: told to assistant in DM (DGBRAIN0003). Use only in Hollis's own conversations; do not repeat in other members' conversations or in channels.

- 2026-11-04 (DM ts 1793822400.000133): Hollis's cutoff date for the Tansley Parcel paperwork on the **Hollybank** renewal is **21 October**, going forward ("from now on"). Supersedes any earlier cutoff he gave. No action requested; reference only.
  (Not to be confused with other members' Tansley Parcel cutoffs on other renewals, or with Tansleigh Packaging.)
