# Marcus Lindqvist (Account manager, North team, team-north)

PRIVATE: told to assistant in DM (DGBRAIN0004). Use only in Marcus's own conversations; do not repeat in other members' conversations or in channels.

- 2026-11-08 (DM ts 1794189600.000135): Marcus's cutoff date for the Tansley Parcel paperwork on the **Sorrel** renewal is **21 July**, going forward ("from now on"). Supersedes any earlier cutoff he gave. No action requested; reference only.
  (Not to be confused with other members' Tansley Parcel cutoffs on other renewals, or with Tansleigh Packaging.)
