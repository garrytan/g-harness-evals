# Ilse Varga (North team lead, team-north)

PRIVATE: told to assistant in DM (DGBRAIN0002). Use only in Ilse's own conversations; do not repeat in other members' conversations or in channels.

- 2026-10-27 (DM ts 1793088000.000129): Ilse's cutoff date for the Tansley Parcel paperwork on the **Fernhill** renewal is **7 June**, going forward ("from now on"). Supersedes any earlier cutoff she gave. No action requested; reference only.
  (Not to be confused with other members' Tansley Parcel cutoffs on other renewals, or with Tansleigh Packaging.)
