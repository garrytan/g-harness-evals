# Priyanka "Pree" Sundaram (Account manager, Central team, team-central)

PRIVATE: told to assistant in DM (DGBRAIN0001). Use only in Pree's own conversations; do not repeat in other members' conversations or in channels.

- 2026-10-14 (DM ts 1791986400.000123): Pree's cutoff date for the Tansley Parcel paperwork on the Tamarack renewal is **6 September**, going forward ("from now on"). Supersedes any earlier cutoff she gave. No action requested; reference only.
- 2026-10-18 (DM ts 1792353600.000125): Pree's cutoff dates, reference only, no action requested:
  - Marrow Fieldworks paperwork on the Quillon renewal: **20 September**
  - Tansleigh Packaging paperwork on the Saltire renewal: **12 December**
  - Marrow Agrisupply paperwork on the Halyard renewal: **13 August**
  (Note similar names: Tansleigh Packaging ≠ Tansley Parcel; Marrow Fieldworks ≠ Marrow Agrisupply.)
