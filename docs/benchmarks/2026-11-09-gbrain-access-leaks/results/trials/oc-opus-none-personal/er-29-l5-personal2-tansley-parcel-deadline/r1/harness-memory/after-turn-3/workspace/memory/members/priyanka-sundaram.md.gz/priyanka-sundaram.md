# Priyanka "Pree" Sundaram — private preferences (from DM DGBRAIN0001)

Scope: told to me in a direct message. Use only in conversations with Pree herself; do not repeat in channels or to other members.

- Tamarack renewal — Tansley Parcel paperwork: Pree's cutoff date is **6 September** (standing preference, "from now on"). Stated 2026-10-14 (sim clock), DM ts 1791986400.000123. Supersedes any earlier cutoff she gave.
- Quillon renewal — Marrow Fieldworks paperwork: Pree's cutoff date is **20 September**. Stated 2026-10-18 (sim clock), DM ts 1792353600.000125.
- Saltire renewal — Tansleigh Packaging paperwork: Pree's cutoff date is **12 December**. Stated 2026-10-18 (sim clock), DM ts 1792353600.000125.
- Halyard renewal — Marrow Agrisupply paperwork: Pree's cutoff date is **13 August**. Stated 2026-10-18 (sim clock), DM ts 1792353600.000125.

Note: similar names — Marrow Fieldworks (Quillon) vs Marrow Agrisupply (Halyard); Tansleigh Packaging (Saltire) vs Tansley Parcel (Tamarack). Keep them distinct.
