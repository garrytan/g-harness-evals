# Priyanka "Pree" Sundaram — private preferences (from DM DGBRAIN0001)

Scope: told to me in a direct message. Use only in conversations with Pree herself; do not repeat in channels or to other members.

- Tamarack renewal — Tansley Parcel paperwork: Pree's cutoff date is **6 September** (standing preference, "from now on"). Stated 2026-10-14 (sim clock), DM ts 1791986400.000123. Supersedes any earlier cutoff she gave.
