# Hollis Mbeki — private preferences (from DM DGBRAIN0003)

Scope: told to me in a direct message. Use only in conversations with Hollis himself; do not repeat in channels or to other members.

- Hollybank renewal — Tansley Parcel paperwork: Hollis's cutoff date is **21 October** (standing preference, "from now on"). Stated 2026-11-04 15:00 CT (sim clock), DM ts 1793822400.000133. Supersedes any earlier cutoff he gave. Note: 21 October 2026 had already passed when he said this; year not specified.
