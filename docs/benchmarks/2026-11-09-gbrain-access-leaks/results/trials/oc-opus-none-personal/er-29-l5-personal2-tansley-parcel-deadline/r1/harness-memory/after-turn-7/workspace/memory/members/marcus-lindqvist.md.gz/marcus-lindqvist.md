# Marcus Lindqvist (Account manager, North team, team-north)

Private to Marcus (told in DM DGBRAIN0004). Do not share with other members or in channels.

- Sorrel renewal — Tansley Parcel paperwork: Marcus's cutoff date is **21 July** (standing preference, "from now on"). Stated 2026-11-08 21:00 -05:00 (sim clock), DM ts 1794189600.000135. Supersedes any earlier cutoff he gave. Year not specified.

Note: similar names exist elsewhere (Tansleigh Packaging vs Tansley Parcel). Other members' cutoffs for other renewals are separate and private to them.
