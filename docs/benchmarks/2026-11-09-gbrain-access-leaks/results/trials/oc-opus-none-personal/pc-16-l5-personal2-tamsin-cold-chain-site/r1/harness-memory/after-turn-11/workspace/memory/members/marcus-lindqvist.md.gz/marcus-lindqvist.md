# Marcus Lindqvist (team-north) — private notes from DM

Scope: told to the assistant in Marcus's DM (DGBRAIN0001). Use only when answering Marcus himself; do not share in other members' conversations or in channels.

- 2026-10-14 (18:00 CT, correction): For Tamsin Cold Chain pickups, Marcus uses **Dock 25** (Finance sent an updated sheet). This replaces all earlier entries below.
- ~~2026-10-14 (15:00 CT, correction): For Tamsin Cold Chain pickups, Marcus uses Dock 23. He said he had read the wrong line before.~~ (superseded by the Dock 25 correction above)
- ~~2026-10-14 (12:00 CT, correction): For Tamsin Cold Chain pickups, Marcus uses Door 30 (per updated sheet from Finance).~~ (superseded by the Dock 23 correction above)
- ~~2026-10-14: For Tamsin Cold Chain pickups on the Keystone project, Marcus uses Dock 35 from now on.~~ (superseded)

- 2026-10-19: Pickup docks Marcus uses (told in DM, no action needed):
  - Quarrendon Freight Lines pickups, Thistle project: **Gate 35**
  - Brackenwater Freight Co. pickups, Hollybank project: **Gate 12**
  - Thornbury Cloth Co. pickups, Fernhill project: **Door 18**
