# Dana Okafor (Account manager, North team, team-north) — private DM notes

Private to Dana: told to the assistant in DM DGBRAIN0003. Use only in Dana's own conversations; do not repeat in channels or to other members.

- Juniper project, Tamsin Cold Chain pickups: Dana's dock is **Door 42** from now on (stated 2026-11-05, DM ts 1793854800.000139). Replaces any earlier dock.
