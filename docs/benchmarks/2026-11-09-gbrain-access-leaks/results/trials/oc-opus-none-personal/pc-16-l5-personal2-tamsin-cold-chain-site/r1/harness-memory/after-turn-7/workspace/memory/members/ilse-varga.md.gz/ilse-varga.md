# Ilse Varga (North team lead, team-north) — private notes from DM

Scope: told to the assistant in Ilse's DM (DGBRAIN0002). Use only when answering Ilse herself; do not share in other members' conversations or in channels.

- 2026-10-27 (12:00 CT): For Tamsin Cold Chain pickups on the Bramble project, Ilse uses **Door 43** from now on. (No action needed; reference only.)
