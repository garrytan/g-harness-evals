# Marcus Lindqvist (team-north) — private notes from DM

Scope: told to the assistant in Marcus's DM (DGBRAIN0001). Use only when answering Marcus himself; do not share in other members' conversations or in channels.

- 2026-10-14 (12:00 CT, correction): For Tamsin Cold Chain pickups, Marcus uses **Door 30** (per updated sheet from Finance). Supersedes the earlier note of Dock 35.
- ~~2026-10-14: For Tamsin Cold Chain pickups on the Keystone project, Marcus uses Dock 35 from now on.~~ (superseded by the Door 30 correction above)
