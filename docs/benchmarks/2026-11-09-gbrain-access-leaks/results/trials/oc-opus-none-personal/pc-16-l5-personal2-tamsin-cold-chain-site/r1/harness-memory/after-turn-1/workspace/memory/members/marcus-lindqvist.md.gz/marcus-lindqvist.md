# Marcus Lindqvist (team-north) — private notes from DM

Scope: told to the assistant in Marcus's DM (DGBRAIN0001). Use only when answering Marcus himself; do not share in other members' conversations or in channels.

- 2026-10-14: For Tamsin Cold Chain pickups on the Keystone project, Marcus uses **Dock 35** from now on. (Supersedes any earlier dock.)
