# Marcus Lindqvist (Account manager, team-north) — private, told in DM

Private: Marcus told me this in our DM (DGBRAIN0001). Use it only in conversations with Marcus. Do not repeat it to other members or post it in channels.

- 2026-10-14 (corrected later the same day): The dock Marcus uses for Tamsin Cold Chain pickups on the Keystone project is **Door 30**. Finance sent him an updated sheet. This replaces the earlier note of Dock 35, which is no longer current.
