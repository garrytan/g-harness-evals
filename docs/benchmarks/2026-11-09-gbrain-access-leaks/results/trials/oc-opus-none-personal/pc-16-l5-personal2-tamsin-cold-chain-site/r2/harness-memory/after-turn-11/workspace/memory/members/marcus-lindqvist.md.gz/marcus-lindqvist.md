# Marcus Lindqvist (Account manager, team-north) — private, told in DM

Private: Marcus told me this in our DM (DGBRAIN0001). Use it only in conversations with Marcus. Do not repeat it to other members or post it in channels.

- 2026-10-14 (latest correction, from Marcus in DM ts 1792018800.000129): The dock Marcus uses for Tamsin Cold Chain pickups on the Keystone project is **Dock 25**, per an updated sheet from Finance. This replaces all earlier notes (Dock 35, then Door 30, then Dock 23), which are no longer current.
- 2026-10-19 (from Marcus in DM ts 1792386000.000131): Dock Marcus uses for Quarrendon Freight Lines pickups on the Thistle project is **Gate 35**.
- 2026-10-19 (same message): Dock Marcus uses for Brackenwater Freight Co. pickups on the Hollybank project is **Gate 12**.
- 2026-10-19 (same message): Dock Marcus uses for Thornbury Cloth Co. pickups on the Fernhill project is **Door 18**.
