# Dana Okafor (Account manager, North team, team-north): private, told in DM

Private: Dana told me this in our DM (DGBRAIN0003). Use it only in conversations with Dana. Do not repeat it to other members or post it in channels.

- 2026-11-05 (from Dana in DM ts 1793854800.000139): The dock Dana uses for Tamsin Cold Chain pickups on the Juniper project is **Door 42**, from now on.
