# Marcus Lindqvist (Account manager, team-north) — private, told in DM

Private: Marcus told me this in our DM (DGBRAIN0001). Use it only in conversations with Marcus. Do not repeat it to other members or post it in channels.

- 2026-10-14 (latest correction, from Marcus in DM ts 1792008000.000127): The dock Marcus uses for Tamsin Cold Chain pickups on the Keystone project is **Dock 23**. He said he had read the wrong line before. This replaces all earlier notes (Dock 35, then Door 30), which are no longer current.
