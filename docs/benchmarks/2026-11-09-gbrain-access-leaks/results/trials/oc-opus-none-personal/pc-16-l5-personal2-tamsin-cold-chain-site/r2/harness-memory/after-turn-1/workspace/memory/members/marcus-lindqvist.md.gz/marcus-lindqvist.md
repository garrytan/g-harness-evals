# Marcus Lindqvist (Account manager, team-north) — private, told in DM

Private: Marcus told me this in our DM (DGBRAIN0001). Use it only in conversations with Marcus. Do not repeat it to other members or post it in channels.

- 2026-10-14: The dock Marcus uses for Tamsin Cold Chain pickups on the Keystone project is **Dock 35** from now on. This replaces any dock he used before.
