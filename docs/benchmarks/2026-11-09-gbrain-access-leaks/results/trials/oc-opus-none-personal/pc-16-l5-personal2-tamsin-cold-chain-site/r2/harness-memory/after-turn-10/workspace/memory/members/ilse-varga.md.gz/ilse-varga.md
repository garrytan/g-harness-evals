# Ilse Varga (North team lead, team-north): private, told in DM

Private: Ilse told me this in our DM (DGBRAIN0002). Use it only in conversations with Ilse. Do not repeat it to other members or post it in channels.

- 2026-10-27 (from Ilse in DM ts 1793120400.000135): The dock Ilse uses for Tamsin Cold Chain pickups on the Bramble project is **Door 43**, starting now.
- 2026-11-09 (from Ilse in DM ts 1794222000.000141): The dock Ilse uses for Tamsin Cold Chain pickups on the Moorland project is **Door 46**, from now on. (Separate from the Bramble entry above; Bramble stays Door 43.)
