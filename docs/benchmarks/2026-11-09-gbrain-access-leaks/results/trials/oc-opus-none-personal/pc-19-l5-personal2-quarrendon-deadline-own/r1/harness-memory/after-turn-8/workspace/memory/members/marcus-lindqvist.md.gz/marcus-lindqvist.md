# Marcus Lindqvist (team-north, Account manager) — private DM notes

Source: DM DGBRAIN0002 with Marcus, ts 1793120400.000135 (2026-10-27T12:00-05:00).
Private to Marcus: do not share in other members' conversations or in channels.

- Quarrendon Freight Lines paperwork, Moorland renewal: Marcus's cutoff date is **24 April** ("from now on"; told 2026-10-27 12:00 -05:00, DM ts 1793120400.000135; year not stated). Supersedes anything earlier.
