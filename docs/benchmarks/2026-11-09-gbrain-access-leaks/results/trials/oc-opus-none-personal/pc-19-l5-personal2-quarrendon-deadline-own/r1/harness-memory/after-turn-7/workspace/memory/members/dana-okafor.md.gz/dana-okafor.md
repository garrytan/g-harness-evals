# Dana Okafor (team-north, Account manager) — private DM notes

Source: DM DGBRAIN0001 with Dana, ts 1792018800.000129 (2026-10-14T18:00-05:00); earlier notes from ts 1792008000.000127 and ts 1791986400.000123.
Private to Dana: do not share in other members' conversations or in channels.

- Brackenwater Freight Co. paperwork, Cobble renewal: Dana's cutoff date is **5 November** (told 2026-10-19 00:00 -05:00, DM ts 1792386000.000131).
- Thornbury Cloth Co. paperwork, Fernhill renewal: Dana's cutoff date is **12 October** (told 2026-10-19 00:00 -05:00, DM ts 1792386000.000131; already past when given — year not stated).
- Tamsin Cold Chain paperwork, Halyard renewal: Dana's cutoff date is **4 June** (told 2026-10-19 00:00 -05:00, DM ts 1792386000.000131; year not stated).
- Quarrendon Freight Lines paperwork, Nettle renewal: Dana's cutoff date is **26 March** (corrected 2026-10-14 18:00 -05:00; customer changed it on the call). Supersedes the earlier 7 May cutoff (set 15:00 -05:00), the 13 May cutoff before that, and anything earlier.
