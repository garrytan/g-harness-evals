# Marcus Lindqvist (Account manager, North team, team-north) — private DM notes

Told to the assistant in DM (DGBRAIN0002). Private to Marcus: do not share in other members' conversations or in channels.

- Quarrendon Freight Lines paperwork cutoff date, Moorland renewal: **24 April** ("from now on"). Set by Marcus 2026-10-27 12:00 (-05:00), msg ts 1793120400.000135. No action requested.
  - This is Marcus's own date and is separate from any other member's Quarrendon notes.
