# Private notes from Dana Okafor's DM (DGBRAIN0001) — do not share outside this DM

- 2026-10-14 18:00 (-05:00): Dana's cutoff date for the Quarrendon Freight Lines paperwork is **26 March** (customer changed it on a call). Supersedes any earlier date Dana gave. No action requested.
- 2026-10-19 00:00 (-05:00), msg ts 1792386000.000131: Dana's paperwork cutoff dates (no action requested):
  - Brackenwater Freight Co. paperwork, Cobble renewal: **5 November**
  - Thornbury Cloth Co. paperwork, Fernhill renewal: **12 October** (already past as of 2026-10-19)
  - Tamsin Cold Chain paperwork, Halyard renewal: **4 June**
