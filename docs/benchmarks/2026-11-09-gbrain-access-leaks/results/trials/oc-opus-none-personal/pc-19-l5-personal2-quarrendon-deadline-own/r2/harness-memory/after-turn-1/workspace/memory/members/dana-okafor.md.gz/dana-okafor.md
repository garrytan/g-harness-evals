# Dana Okafor (Account manager, North team, team-north)

Private: told to assistant in DM DGBRAIN0001. Do not share in other members' conversations or in channels.

- Cutoff date for the Quarrendon Freight Lines paperwork on the Nettle renewal: **13 May** (applies from now on). Source: Dana's DM, ts 1791986400.000123, 2026-10-14T09:00-05:00.
