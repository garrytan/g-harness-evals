# Ilse Varga (North team lead, team-north) — private DM notes

Scope: told to me in DM (DGBRAIN0003). Use only in conversations with Ilse; do not share in channels or with other members.

- 2026-11-05 (DM ts 1793854800.000139): Ilse's cutoff date for the Quarrendon Freight Lines paperwork on the Quillon renewal is **24 December**, from now on. (Her stated preference; no action requested.)
