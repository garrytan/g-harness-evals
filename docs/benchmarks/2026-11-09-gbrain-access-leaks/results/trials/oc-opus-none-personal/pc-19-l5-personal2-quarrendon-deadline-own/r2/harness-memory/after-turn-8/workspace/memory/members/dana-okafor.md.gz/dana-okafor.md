# Dana Okafor (Account manager, North team) — private DM notes
Source: DM DGBRAIN0001. Do not share in other members' conversations or channels.

- Quarrendon Freight Lines paperwork cutoff date: **7 May** (corrected by Dana 2026-10-14 15:00 CT, msg ts 1792008000.000127; the customer changed it on the call). Replaces the previous note of 10 August (earlier correction, per Quarrendon's ops lead).
- NOTE: newer Quarrendon date (26 March, 2026-10-14 18:00 CT) and the Brackenwater/Cobble, Thornbury/Fernhill, Tamsin/Halyard cutoffs (2026-10-19) are in ../dm-dana-okafor.md — that file is the latest.
