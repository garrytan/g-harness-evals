# Marcus Lindqvist (Account manager, North team, team-north) — private, DM-only

Told to assistant in DM DGBRAIN0002 (ts 1793088000.000129, 2026-10-27T03:00-05:00). "For future reference, no action needed."
Do not share this in other members' conversations or in channels.

- Wicklow renewal: Marcus's cutoff date for the Brackenwater Freight Co. paperwork is **16 October** (his standing preference, "from now on"). Year not stated; note 16 October 2026 was already past when he said this.
