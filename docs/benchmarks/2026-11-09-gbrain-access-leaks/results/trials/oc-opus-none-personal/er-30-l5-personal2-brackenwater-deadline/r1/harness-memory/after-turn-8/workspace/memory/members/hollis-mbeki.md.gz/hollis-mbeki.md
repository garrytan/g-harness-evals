# Hollis Mbeki (Central team lead, team-central) — private, DM-only

Told to assistant in DM DGBRAIN0004 (ts 1794189600.000135, 2026-11-08T21:00-05:00). "For future reference, no action needed."
Do not share this in other members' conversations or in channels.

- Marlowe renewal: Hollis's cutoff date for the Brackenwater Freight Co. paperwork is **8 June** (his standing preference, "from now on"). Year not stated; 8 June 2026 was already past when he said this, so the next one is 8 June 2027.
