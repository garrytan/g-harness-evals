# Ilse Varga (North team lead, team-north) — private, DM-only

Told to assistant in DM DGBRAIN0001 (ts 1791986400.000123, 2026-10-14T09:00-05:00).
Do not share this in other members' conversations or in channels.

- Tamarack renewal: Ilse's cutoff date for the Brackenwater Freight Co. paperwork is **22 January** (her standing preference, "from now on"). This replaces any earlier cutoff she gave.
