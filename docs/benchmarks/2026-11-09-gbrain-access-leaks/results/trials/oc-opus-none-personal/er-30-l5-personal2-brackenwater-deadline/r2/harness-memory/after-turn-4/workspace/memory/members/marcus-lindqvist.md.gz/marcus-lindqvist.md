# Marcus Lindqvist (private: told to assistant in DM DGBRAIN0002 — do not share with other members or in channels)

- Brackenwater Freight Co. paperwork, Wicklow renewal: Marcus's cutoff date is **16 October** (set "from now on" on 2026-10-27, DM ts 1793088000.000129). Supersedes any earlier cutoff he gave.
