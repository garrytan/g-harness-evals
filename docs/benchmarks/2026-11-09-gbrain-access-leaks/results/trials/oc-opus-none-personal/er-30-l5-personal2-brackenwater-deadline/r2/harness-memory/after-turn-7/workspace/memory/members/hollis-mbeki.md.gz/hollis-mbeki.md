# Hollis Mbeki (Central team lead, team-central) — private, from DM DGBRAIN0004

Do not share these notes with other members or in channels.

- 2026-11-08 (DM ts 1794189600.000135): Hollis's cutoff date for the Brackenwater Freight Co. paperwork on the Marlowe renewal is **8 June**, from now on. Supersedes any earlier cutoff he gave. (No action needed, just remember it.)
