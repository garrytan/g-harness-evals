# Priyanka "Pree" Sundaram (Account manager, Central team, team-central) — private notes

PRIVATE: told to me by Pree in a DM (DGBRAIN0002). Use only in Pree's own conversations. Do not repeat to other members or in channels.

- Brackenwater Freight Co., Merlin renewal: Pree's cutoff date for the paperwork is **7 August**, from now on (set 2026-10-27, DM ts 1793088000.000129). This replaces any earlier cutoff Pree gave. (Not to be confused with other members' cutoffs for other Brackenwater renewals.)
