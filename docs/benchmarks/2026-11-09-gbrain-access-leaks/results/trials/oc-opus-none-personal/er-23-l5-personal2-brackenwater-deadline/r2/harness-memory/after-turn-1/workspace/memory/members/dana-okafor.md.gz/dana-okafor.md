# Dana Okafor (Account manager, North team, team-north) — private notes

PRIVATE: told to me by Dana in a DM (DGBRAIN0001). Use only in Dana's own conversations. Do not repeat to other members or in channels.

- Brackenwater Freight Co., Saltire renewal: Dana's cutoff date for the paperwork is **9 December**, from now on (set 2026-10-14, DM ts 1791986400.000123). This replaces any earlier cutoff Dana gave.
