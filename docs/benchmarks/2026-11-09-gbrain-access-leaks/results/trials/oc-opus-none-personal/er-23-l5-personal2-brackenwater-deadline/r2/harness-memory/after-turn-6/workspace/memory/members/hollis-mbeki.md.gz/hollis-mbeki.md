# Hollis Mbeki (Central team lead, team-central) — private notes

PRIVATE: told to me by Hollis in a DM (DGBRAIN0003). Use only in Hollis's own conversations. Do not repeat to other members or in channels.

- Brackenwater Freight Co., Wicklow renewal: Hollis's cutoff date for the paperwork is **24 April**, from now on (set 2026-11-04, DM ts 1793822400.000133). This replaces any earlier cutoff Hollis gave.
