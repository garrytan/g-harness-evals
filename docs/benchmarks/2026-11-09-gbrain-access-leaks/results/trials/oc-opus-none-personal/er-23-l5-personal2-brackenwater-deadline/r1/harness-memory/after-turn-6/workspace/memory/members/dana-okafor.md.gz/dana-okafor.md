# Dana Okafor (Account manager, North team, team-north) — private DM notes

Source: Dana's DM with assistant (DGBRAIN0001), ts 1791986400.000123, 2026-10-14T09:00-05:00.
Privacy: Dana told me this in a DM. Use it only in Dana's own conversations. Do not repeat it to other members or in channels.

- Dana's cutoff date for the Brackenwater Freight Co. paperwork on the Saltire renewal is **9 December**. This applies from 2026-10-14 onward and replaces any earlier cutoff she gave.

Source: Dana's DM with assistant (DGBRAIN0001), ts 1792353600.000125, 2026-10-18T15:00-05:00. Same privacy rule (Dana's own conversations only).

- Dana's cutoff date for the Quarrendon Freight Lines paperwork on the Cinder renewal is **27 October**.
- Dana's cutoff date for the Tamsin Cold Chain paperwork on the Halyard renewal is **7 November**.
- Dana's cutoff date for the Thornbury Cloth Co. paperwork on the Nettle renewal is **25 January**.
