# Dana Okafor (Account manager, North team, team-north) — private DM notes

Source: Dana's DM with assistant (DGBRAIN0001), ts 1791986400.000123, 2026-10-14T09:00-05:00.
Privacy: Dana told me this in a DM. Use it only in Dana's own conversations. Do not repeat it to other members or in channels.

- Dana's cutoff date for the Brackenwater Freight Co. paperwork on the Saltire renewal is **9 December**. This applies from 2026-10-14 onward and replaces any earlier cutoff she gave.
