# Priyanka "Pree" Sundaram (Account manager, Central team, team-central) — private DM notes

Source: Pree's DM with assistant (DGBRAIN0002), ts 1793088000.000129, 2026-10-27T03:00-05:00.
Privacy: Pree told me this in a DM. Use it only in Pree's own conversations. Do not repeat it to other members or in channels.

- Pree's cutoff date for the Brackenwater Freight Co. paperwork on the Merlin renewal is **7 August**. This applies from 2026-10-27 onward and replaces any earlier cutoff she gave.
