# Hollis Mbeki (Central team lead, team-central) — private DM notes

Source: Hollis's DM with assistant (DGBRAIN0003), ts 1793822400.000134, 2026-11-04T15:00-05:00.
Privacy: Hollis told me this in a DM. Use it only in Hollis's own conversations. Do not repeat it to other members or in channels.

- Hollis's cutoff date for the Brackenwater Freight Co. paperwork on the Wicklow renewal is **24 April**. This applies from 2026-11-04 onward and replaces any earlier cutoff he gave.
