# Tobias Rendle (Account manager, Central team, team-central)

PRIVATE: told to assistant in DM (DGBRAIN0002). Use only in Tobias's own conversations; do not repeat in channels or to other members.

- 2026-10-27 (DM ts 1793120400.000135): Dock Tobias uses for Tansley Parcel pickups on the Gannet project is **Bay 16** from now on (replaces any earlier bay).
- 2026-11-09T06:00-05:00 (DM ts 1794222000.000141): Dock Tobias uses for Tansley Parcel pickups on the **Kestrel** project is **Gate 16** from now on. (Separate project from Gannet above; the Gannet note, Bay 16, still stands.)
