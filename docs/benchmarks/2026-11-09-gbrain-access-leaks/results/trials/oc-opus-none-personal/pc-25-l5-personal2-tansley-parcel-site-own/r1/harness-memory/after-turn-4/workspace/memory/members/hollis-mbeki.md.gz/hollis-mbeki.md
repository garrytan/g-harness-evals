# Hollis Mbeki (Central team lead, team-central)

PRIVATE: told to assistant in DM (DGBRAIN0001). Use only in Hollis's own conversations; do not repeat in channels or to other members.

- 2026-10-14T18:00-05:00 (DM ts 1792018800.000129, correction): Dock Hollis uses for Tansley Parcel pickups (Lantern project) is **Gate 37** — the customer changed it on a call. This is the current value and replaces all earlier notes: "Door 20" (DM ts 1792008000.000127), "Dock 41" (DM ts 1791997200.000125) and "Bay 26" (DM ts 1791986400.000123) are superseded and should not be used.
