# Hollis Mbeki (Central team lead, team-central)

PRIVATE: told to assistant in DM (DGBRAIN0001). Use only in Hollis's own conversations; do not repeat in channels or to other members.

- 2026-10-14 (DM ts 1791997200.000125, correction): Dock Hollis uses for Tansley Parcel pickups (Lantern project) is **Dock 41**. Hollis had read the wrong line earlier; this replaces the earlier "Bay 26" note (DM ts 1791986400.000123), which is superseded and should not be used.
