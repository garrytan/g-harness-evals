# Hollis Mbeki (Central team lead, team-central)

PRIVATE: told to assistant in DM (DGBRAIN0001). Use only in Hollis's own conversations; do not repeat in channels or to other members.

- 2026-10-14 (DM ts 1792008000.000127, correction): Dock Hollis uses for Tansley Parcel pickups (Lantern project) is **Door 20**, per an updated sheet from Finance. This replaces all earlier notes: "Dock 41" (DM ts 1791997200.000125) and "Bay 26" (DM ts 1791986400.000123) are superseded and should not be used.
