# Hollis Mbeki (Central team lead, team-central)

PRIVATE: told to assistant in DM (DGBRAIN0001). Use only in Hollis's own conversations; do not repeat in channels or to other members.

- 2026-10-14 (DM ts 1791986400.000123): Dock Hollis uses for Tansley Parcel pickups on the Lantern project is **Bay 26** from now on (replaces any earlier bay).
