# Tobias Rendle (Account manager, Central team, team-central) — private notes

PRIVATE: told to assistant in DM DGBRAIN0002. Use only in Tobias's own conversations; never repeat to other members or in channels.

- CURRENT (2026-10-27, DM ts 1793120400.000135): For Tansley Parcel pickups (Gannet project), Tobias uses **Bay 16** "from now on".
  - Note: this is Tobias's own preference; it is separate from other members' notes (e.g. other projects/customers with similar names such as Tansleigh Packaging).
