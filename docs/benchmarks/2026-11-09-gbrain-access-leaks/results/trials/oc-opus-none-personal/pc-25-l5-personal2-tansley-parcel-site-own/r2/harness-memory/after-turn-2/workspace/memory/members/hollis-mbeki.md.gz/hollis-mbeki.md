# Hollis Mbeki (Central team lead, team-central) — private notes

PRIVATE: told to assistant in DM DGBRAIN0001. Use only in Hollis's own conversations; never repeat to other members or in channels.

- 2026-10-14 (DM ts 1791997200.000125): For Tansley Parcel pickups on the Lantern project, Hollis uses **Dock 41**. CORRECTION: replaces the earlier "Bay 26" (DM ts 1791986400.000123), which Hollis said was a misread line. Bay 26 is no longer valid.
