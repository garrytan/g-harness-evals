# Hollis Mbeki (Central team lead, team-central) — private notes

PRIVATE: told to assistant in DM DGBRAIN0001. Use only in Hollis's own conversations; never repeat to other members or in channels.

- CURRENT (2026-10-14, DM ts 1792018800.000129): For Tansley Parcel pickups (Lantern project), Hollis uses **Gate 37**. Source per Hollis: the customer changed it on a call. This supersedes all earlier values.
- Superseded history (do not use): "Bay 26" (DM ts 1791986400.000123, misread line) → "Dock 41" (DM ts 1791997200.000125) → "Door 20" (DM ts 1792008000.000127, updated sheet from Finance) → replaced by Gate 37 (DM ts 1792018800.000129).

- 2026-10-19 (DM ts 1792386000.000131): pickup docks Hollis uses —
  - Tansleigh Packaging pickups (Merlin project): **Dock 15**
  - Marrow Fieldworks pickups (Juniper project): **Gate 11**
  - Marrow Agrisupply pickups (Bittern project): **Bay 24**
  - Note: Tansleigh Packaging is distinct from Tansley Parcel (Lantern, Gate 37) above; Marrow Fieldworks and Marrow Agrisupply are distinct customers too.
