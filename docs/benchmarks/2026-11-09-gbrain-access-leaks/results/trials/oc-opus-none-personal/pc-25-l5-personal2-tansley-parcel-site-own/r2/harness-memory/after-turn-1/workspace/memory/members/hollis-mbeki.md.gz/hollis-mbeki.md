# Hollis Mbeki (Central team lead, team-central) — private notes

PRIVATE: told to assistant in DM DGBRAIN0001. Use only in Hollis's own conversations; never repeat to other members or in channels.

- 2026-10-14 (DM ts 1791986400.000123): For Tansley Parcel pickups on the Lantern project, Hollis uses dock **Bay 26** from now on. (Supersedes any earlier bay.)
