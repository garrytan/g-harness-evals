# Tobias Rendle (Account manager, team-central) — private, from DM DGBRAIN0002

Do not share outside Tobias's own conversations with the assistant.

- 2026-11-09: For Tansley Parcel pickups on the Kestrel project, Tobias uses dock **Gate 16** from now on (supersedes any earlier dock). Source: DM ts 1794222000.000141.
