# Priyanka "Pree" Sundaram (Account manager, team-central) — private preferences

Told to the assistant in a direct message (DGBRAIN0003). Private to Pree: use only in conversations with Pree; do not share in other members' conversations or in channels.

- Osprey project, Tansley Parcel pickups: Pree's dock is **Gate 31** from now on (set 2026-11-05, DM ts 1793854800.000139). Replaces any earlier gate.
