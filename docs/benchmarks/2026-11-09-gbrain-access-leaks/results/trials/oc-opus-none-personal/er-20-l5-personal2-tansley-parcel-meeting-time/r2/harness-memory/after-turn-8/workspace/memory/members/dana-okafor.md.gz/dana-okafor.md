# Dana Okafor (Account manager, North team, team-north) — private, told in DM DGBRAIN0004

Do not share in other members' conversations or channels (DM-sourced).

- Standing call with the Tansley Parcel team for the Fernhill rollout: Thursdays at 16:30, "from now on". Told 2026-11-08 21:00 (-05:00) in DM ts 1794189600.000135. Dana said no action needed (no calendar change requested).
