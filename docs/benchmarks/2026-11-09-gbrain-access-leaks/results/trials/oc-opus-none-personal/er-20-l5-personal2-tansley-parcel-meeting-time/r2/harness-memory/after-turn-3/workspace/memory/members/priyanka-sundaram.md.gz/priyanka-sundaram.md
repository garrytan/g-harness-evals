# Priyanka "Pree" Sundaram (Account manager, Central team, team-central)

Private: told to assistant in DM DGBRAIN0001. Do not share in other members' conversations or channels.

- Standing call with the Tansley Parcel team for the Nettle rollout: Thursdays at 10:15 (company time), effective from 2026-10-14 onward. (Told 2026-10-14, msg ts 1791986400.000123.)
- Standing call with the Marrow Agrisupply team for the Saltire rollout: Wednesdays at 9:30 (company time). (Told 2026-10-18, msg ts 1792353600.000125.)
- Standing call with the Tansleigh Packaging team for the Kestrel rollout: Fridays at 11:45 (company time). (Told 2026-10-18, msg ts 1792353600.000125.)
- Standing call with the Marrow Fieldworks team for the Ironbridge rollout: Wednesdays at 14:45 (company time). (Told 2026-10-18, msg ts 1792353600.000125.)
  Note: Marrow Agrisupply (Saltire, Wed 9:30) and Marrow Fieldworks (Ironbridge, Wed 14:45) are different customers; don't mix them up.
