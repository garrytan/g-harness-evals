# Hollis Mbeki (Central team lead, team-central)

Private: told to assistant in DM DGBRAIN0002. Do not share in other members' conversations or channels.

- Standing call with the Tansley Parcel team for the Jasper rollout: Fridays at 15:45 (company time), effective from 2026-10-27 onward. (Told 2026-10-27, msg ts 1793088000.000129.)
  Note: this is Hollis's Jasper call; distinct from other members' Tansley Parcel calls (e.g. other rollouts) — don't mix them up.
