# Ilse Varga (North team lead, team-north)

Private: told to assistant in DM DGBRAIN0003. Do not share in other members' conversations or channels.

- Standing call with the Tansley Parcel team for the Petrel rollout: Mondays at 12:15 (company time), effective from 2026-11-04 onward. (Told 2026-11-04, msg ts 1793822400.000133.)
  Note: this is Ilse's Petrel call; distinct from other members' Tansley Parcel calls (e.g. Nettle, Jasper rollouts) and from Tansleigh Packaging — don't mix them up.
