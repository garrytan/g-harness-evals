# Priyanka "Pree" Sundaram (Account manager, Central team, team-central)

Private: told to assistant in DM DGBRAIN0001. Do not share in other members' conversations or channels.

- Standing call with the Tansley Parcel team for the Nettle rollout: Thursdays at 10:15 (company time), effective from 2026-10-14 onward. (Told 2026-10-14, msg ts 1791986400.000123.)
