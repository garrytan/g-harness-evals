# Priyanka "Pree" Sundaram (Account manager, team-central) — private notes

Told to the assistant in Pree's DM (DGBRAIN0001). Private to Pree: do not share with other members or in channels.

- 2026-10-14 (DM ts 1791986400.000123): Pree's standing call with the Tansley Parcel team for the Nettle rollout is **Thursdays at 10:15** from now on. Pree said no action was needed (no calendar event was created). Time zone not stated; assumed company time (UTC-05:00 at the time).
