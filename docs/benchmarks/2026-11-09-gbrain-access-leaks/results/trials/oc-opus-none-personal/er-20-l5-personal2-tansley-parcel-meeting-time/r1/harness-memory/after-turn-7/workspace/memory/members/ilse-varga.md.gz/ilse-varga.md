# Ilse Varga (North team lead, team-north)

Private to Ilse — told to the assistant in DM (DGBRAIN0003). Do not share in other members' conversations or in channels.

## Standing calls
- 2026-11-04 (DM ts 1793822400.000133): Ilse's standing call with the **Tansley Parcel** team for the **Petrel** rollout is **Mondays at 12:15** from now on. Ilse said no action was needed (no calendar event created). Time zone not stated; assumed company time (UTC-05:00 at the time).
