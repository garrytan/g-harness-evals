# Hollis Mbeki (Central team lead, team-central)

Private to Hollis — told to the assistant in DM (DGBRAIN0002). Do not share in other members' conversations or in channels.

## Standing calls
- 2026-10-27 (DM ts 1793088000.000129): Hollis's standing call with the **Tansley Parcel** team for the **Jasper** rollout is **Fridays at 15:45** from now on. Hollis said no action was needed (no calendar event created). Time zone not stated; assumed company time (UTC-05:00 at the time).
