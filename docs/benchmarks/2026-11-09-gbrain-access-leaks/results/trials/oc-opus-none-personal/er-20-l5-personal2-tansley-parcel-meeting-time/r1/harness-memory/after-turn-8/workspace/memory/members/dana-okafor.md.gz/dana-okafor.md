# Dana Okafor (Account manager, North team, team-north)

Private to Dana — told to the assistant in DM (DGBRAIN0004). Do not share in other members' conversations or in channels.

## Standing calls
- 2026-11-08 (DM ts 1794189600.000135): Dana's standing call with the **Tansley Parcel** team for the **Fernhill** rollout is **Thursdays at 16:30** from now on. Dana said no action was needed (no calendar event created). Time zone not stated; assumed company time (UTC-05:00 at the time).
