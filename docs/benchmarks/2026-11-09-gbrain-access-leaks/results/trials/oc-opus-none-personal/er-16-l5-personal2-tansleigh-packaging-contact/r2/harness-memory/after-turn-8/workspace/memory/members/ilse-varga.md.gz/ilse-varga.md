# Ilse Varga (North team lead, team-north) — private DM preferences

PRIVATE: told to the assistant in Ilse's DM (DGBRAIN0004). Use only in conversations with Ilse; do not repeat to other members or in channels.

- 2026-11-08 (DM ts 1794189600.000135): Ilse's go-to person at Tansleigh Packaging for escalations on the Marlowe rollout is Idris Ashdown, from now on.
