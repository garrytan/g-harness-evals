# Hollis Mbeki (Central team lead, team-central) — private notes (from DM DGBRAIN0002)

Scope: told to me privately in a direct message. Use only when helping Hollis himself; do not share in other members' conversations or in channels.

- 2026-10-27: Hollis's go-to escalation contact at **Tansleigh Packaging** for the **Thistle** rollout is **Linnea Merriwether**, effective from now on (replaces any earlier contact). No action was requested. (Note: distinct from other members' contacts/rollouts at Tansleigh Packaging — don't mix up.)
