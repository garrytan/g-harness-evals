# Priyanka "Pree" Sundaram — private notes (from DM DGBRAIN0001)

Scope: told to me privately in a direct message. Use only when helping Pree herself; do not share in other members' conversations or in channels.

- 2026-10-14: Pree's go-to escalation contact at Tansleigh Packaging for the Saltire rollout is **Linnea Tolland**, effective from now on (replaces any earlier contact). No action was requested.
- 2026-10-18: Pree's go-to escalation contact at **Marrow Fieldworks** for the **Petrel** rollout is **Maren Varno**. No action requested.
- 2026-10-18: Pree's go-to escalation contact at **Marrow Agrisupply** for the **Larchmont** rollout is **Wren Varno**. No action requested. (Note: Marrow Agrisupply and Marrow Fieldworks are different companies; Maren and Wren Varno are different people — don't mix them up.)
- 2026-10-18: Pree's go-to escalation contact at **Tansley Parcel** for the **Bramble** rollout is **Tamsyn Quillan**. No action requested. (Note: Tansley Parcel is distinct from Tansleigh Packaging/Saltire above.)
