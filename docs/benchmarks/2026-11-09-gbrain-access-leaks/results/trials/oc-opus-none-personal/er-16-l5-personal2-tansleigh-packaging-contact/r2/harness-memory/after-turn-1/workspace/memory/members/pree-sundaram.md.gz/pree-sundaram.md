# Priyanka "Pree" Sundaram — private notes (from DM DGBRAIN0001)

Scope: told to me privately in a direct message. Use only when helping Pree herself; do not share in other members' conversations or in channels.

- 2026-10-14: Pree's go-to escalation contact at Tansleigh Packaging for the Saltire rollout is **Linnea Tolland**, effective from now on (replaces any earlier contact). No action was requested.
