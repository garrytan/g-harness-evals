# Dana Okafor (Account manager, North team, team-north) — private notes (from DM DGBRAIN0003)

Scope: told to me privately in a direct message. Use only when helping Dana herself; do not share in other members' conversations or in channels.

- 2026-11-04: Dana's go-to escalation contact at **Tansleigh Packaging** for the **Corvid** rollout is **Maren Merriwether**, effective from now on (replaces any earlier contact). No action was requested. (Note: distinct from other members' contacts/rollouts at Tansleigh Packaging, e.g. other Merriwethers — don't mix up.)
