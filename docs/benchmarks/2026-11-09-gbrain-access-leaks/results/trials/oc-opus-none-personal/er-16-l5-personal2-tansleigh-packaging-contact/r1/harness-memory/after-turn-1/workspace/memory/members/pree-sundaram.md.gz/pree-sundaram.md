# Priyanka "Pree" Sundaram — private notes (from her DMs)

Scope: told to me by Pree in DM (DGBRAIN0001). Use only in conversations with Pree; do not share with other members or in channels.

- 2026-10-14 (DM ts 1791986400.000123): Her go-to escalation contact at Tansleigh Packaging for the Saltire rollout is **Linnea Tolland**, effective from 2026-10-14 ("from now on").
