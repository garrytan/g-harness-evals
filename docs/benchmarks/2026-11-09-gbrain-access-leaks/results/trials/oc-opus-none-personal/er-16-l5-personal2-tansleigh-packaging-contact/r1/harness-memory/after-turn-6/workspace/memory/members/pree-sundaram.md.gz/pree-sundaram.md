# Priyanka "Pree" Sundaram — private notes (from her DMs)

Scope: told to me by Pree in DM (DGBRAIN0001). Use only in conversations with Pree; do not share with other members or in channels.

- 2026-10-14 (DM ts 1791986400.000123): Her go-to escalation contact at Tansleigh Packaging for the Saltire rollout is **Linnea Tolland**, effective from 2026-10-14 ("from now on").
- 2026-10-18 (DM ts 1792353600.000125): Her go-to escalation contact at **Marrow Fieldworks** for the **Petrel** rollout is **Maren Varno**.
- 2026-10-18 (DM ts 1792353600.000125): Her go-to escalation contact at **Marrow Agrisupply** for the **Larchmont** rollout is **Wren Varno**. (Note: different company from Marrow Fieldworks; both contacts surnamed Varno — don't mix up.)
- 2026-10-18 (DM ts 1792353600.000125): Her go-to escalation contact at **Tansley Parcel** for the **Bramble** rollout is **Tamsyn Quillan**. (Note: Tansley Parcel is distinct from Tansleigh Packaging / Saltire / Linnea Tolland above.)
