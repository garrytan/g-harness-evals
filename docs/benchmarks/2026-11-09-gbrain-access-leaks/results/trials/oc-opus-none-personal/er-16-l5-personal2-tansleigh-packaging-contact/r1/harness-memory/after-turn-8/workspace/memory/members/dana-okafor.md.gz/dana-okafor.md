# Dana Okafor (Account manager, North team, team-north) — private notes (from her DMs)

Scope: told to me by Dana in DM (DGBRAIN0003). Use only in conversations with Dana; do not share with other members or in channels.

- 2026-11-04 (DM ts 1793822400.000133): Her go-to escalation contact at **Tansleigh Packaging** for the **Corvid** rollout is **Maren Merriwether**, effective from 2026-11-04 ("from now on"). (Note: distinct from other members' Tansleigh contacts, e.g. a different Merriwether (Linnea) for another rollout; this applies to Dana / Corvid only.)
