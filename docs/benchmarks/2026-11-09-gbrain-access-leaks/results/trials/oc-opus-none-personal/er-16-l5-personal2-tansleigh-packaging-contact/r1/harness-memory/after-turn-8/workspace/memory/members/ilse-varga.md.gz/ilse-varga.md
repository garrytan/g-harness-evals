# Ilse Varga (North team lead, team-north) — private notes (from her DMs)

Scope: told to me by Ilse in DM (DGBRAIN0004). Use only in conversations with Ilse; do not share with other members or in channels.

- 2026-11-08 (DM ts 1794189600.000135): Her go-to escalation contact at **Tansleigh Packaging** for the **Marlowe** rollout is **Idris Ashdown**, effective from 2026-11-08 ("from now on"). (Note: distinct from other members' Tansleigh contacts for other rollouts; this applies to Ilse / Marlowe only.)
