# Hollis Mbeki (Central team lead, team-central) — private notes (from his DMs)

Scope: told to me by Hollis in DM (DGBRAIN0002). Use only in conversations with Hollis; do not share with other members or in channels.

- 2026-10-27 (DM ts 1793088000.000129): His go-to escalation contact at **Tansleigh Packaging** for the **Thistle** rollout is **Linnea Merriwether**, effective from 2026-10-27 ("from now on"). (Note: distinct from any other member's Tansleigh contacts; this applies to Hollis / Thistle only.)
