# Hollis Mbeki (Central team lead, team-central) — private, told via DM

Privacy: told in a direct message. Use only in Hollis's own conversations with me; do not repeat it to other members or post it in channels.

- Quillon renewal, Tansley Parcel paperwork: Hollis's cutoff date is **5 June** (current; Hollis corrected it, had read the wrong line). No action requested, just remember it.
  - Source: DM DGBRAIN0001, ts 1792018800.000129 (sim time 2026-10-14T18:00-05:00).
  - Supersedes: 23 August (DM DGBRAIN0001, ts 1792008000.000127, sim time 2026-10-14T15:00-05:00), 2 November (DM DGBRAIN0001, ts 1791997200.000125, sim time 2026-10-14T12:00-05:00) and 14 December (DM DGBRAIN0001, ts 1791986400.000123, sim time 2026-10-14T09:00-05:00). Do not use the old dates.

- Cobble renewal, Marrow Agrisupply paperwork: Hollis's cutoff date is **26 November**. No action requested, just remember it.
- Wicklow renewal, Tansleigh Packaging paperwork: Hollis's cutoff date is **21 December**. No action requested. (Not the same as Tansley Parcel / Quillon above.)
- Heron renewal, Marrow Fieldworks paperwork: Hollis's cutoff date is **3 May**. No action requested. (Not the same as Marrow Agrisupply / Cobble.)
  - Source for all three: DM DGBRAIN0001, ts 1792386000.000131 (sim time 2026-10-19T00:00-05:00).
