# Priyanka "Pree" Sundaram (Account manager, Central team, team-central) — private, told via DM

Privacy: told in a direct message. Use only in Pree's own conversations with me; do not repeat it to other members or post it in channels.

- Thistle renewal, Tansley Parcel paperwork: Pree's cutoff date is **20 August** ("from now on" — current value). No action requested, just remember it.
  - Source: DM DGBRAIN0002, ts 1793120400.000135 (sim time 2026-10-27T12:00-05:00).
  - No earlier date for this was on record with me. (Not the same as Hollis's Quillon / Tansley Parcel cutoff, which is Hollis's own private note.)
