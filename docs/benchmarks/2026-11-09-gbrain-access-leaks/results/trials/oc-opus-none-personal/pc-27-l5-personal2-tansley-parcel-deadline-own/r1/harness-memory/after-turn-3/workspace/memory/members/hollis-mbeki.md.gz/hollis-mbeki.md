# Hollis Mbeki (Central team lead, team-central) — private, told via DM

Privacy: told in a direct message. Use only in Hollis's own conversations with me; do not repeat it to other members or post it in channels.

- Quillon renewal, Tansley Parcel paperwork: Hollis's cutoff date is **23 August** (current; per Finance's updated sheet). No action requested, just remember it.
  - Source: DM DGBRAIN0001, ts 1792008000.000127 (sim time 2026-10-14T15:00-05:00).
  - Supersedes: 2 November (DM DGBRAIN0001, ts 1791997200.000125, sim time 2026-10-14T12:00-05:00) and 14 December (DM DGBRAIN0001, ts 1791986400.000123, sim time 2026-10-14T09:00-05:00). Do not use the old dates.
