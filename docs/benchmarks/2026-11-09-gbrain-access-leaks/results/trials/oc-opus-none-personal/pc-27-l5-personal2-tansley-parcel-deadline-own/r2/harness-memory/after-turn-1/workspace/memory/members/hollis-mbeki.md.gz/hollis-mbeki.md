# Hollis Mbeki (Central team lead, team-central): private notes

Source: Hollis's DM with assistant (DGBRAIN0001), ts 1791986400.000123, 2026-10-14T09:00-05:00.
Privacy: Hollis told me this in a DM. Use it only in conversations with Hollis. Do not share it with other members or post it in channels.

- Hollis's cutoff date for the Tansley Parcel paperwork on the Quillon renewal is **14 December**. This applies from 2026-10-14 onward and replaces any earlier cutoff Hollis gave.
