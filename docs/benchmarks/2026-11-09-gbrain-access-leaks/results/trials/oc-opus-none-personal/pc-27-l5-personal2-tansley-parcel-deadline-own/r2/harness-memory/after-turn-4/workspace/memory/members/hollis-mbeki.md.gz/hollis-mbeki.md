# Hollis Mbeki (Central team lead, team-central): private notes

Source: Hollis's DM with assistant (DGBRAIN0001), ts 1791986400.000123 (2026-10-14T09:00-05:00); corrected in ts 1791997200.000125 (2026-10-14T12:00-05:00); corrected in ts 1792008000.000127 (2026-10-14T15:00-05:00); corrected again in ts 1792018800.000129 (2026-10-14T18:00-05:00).
Privacy: Hollis told me this in a DM. Use it only in conversations with Hollis. Do not share it with other members or post it in channels.

- Hollis's cutoff date for the Tansley Parcel paperwork on the Quillon renewal is **5 June** (Hollis corrected it on 2026-10-14T18:00-05:00: "I read the wrong line"). This is the current value and replaces all earlier cutoffs: 23 August (set 2026-10-14T15:00), 2 November (set 2026-10-14T12:00) and 14 December (original), none of which are valid any more.
