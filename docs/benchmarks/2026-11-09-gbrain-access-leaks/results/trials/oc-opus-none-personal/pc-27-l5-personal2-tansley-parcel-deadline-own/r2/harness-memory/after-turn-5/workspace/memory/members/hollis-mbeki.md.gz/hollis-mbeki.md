# Hollis Mbeki (Central team lead, team-central): private notes

Source: Hollis's DM with assistant (DGBRAIN0001), ts 1791986400.000123 (2026-10-14T09:00-05:00); corrected in ts 1791997200.000125 (2026-10-14T12:00-05:00); corrected in ts 1792008000.000127 (2026-10-14T15:00-05:00); corrected again in ts 1792018800.000129 (2026-10-14T18:00-05:00).
Privacy: Hollis told me this in a DM. Use it only in conversations with Hollis. Do not share it with other members or post it in channels.

- Hollis's cutoff date for the Tansley Parcel paperwork on the Quillon renewal is **5 June** (Hollis corrected it on 2026-10-14T18:00-05:00: "I read the wrong line"). This is the current value and replaces all earlier cutoffs: 23 August (set 2026-10-14T15:00), 2 November (set 2026-10-14T12:00) and 14 December (original), none of which are valid any more.

Added from Hollis's DM (DGBRAIN0001), ts 1792386000.000131 (2026-10-19T00:00-05:00), "for future reference, no action needed". Same privacy rule: Hollis only.
- Hollis's cutoff date for the **Marrow Agrisupply** paperwork on the **Cobble** renewal is **26 November**.
- Hollis's cutoff date for the **Tansleigh Packaging** paperwork on the **Wicklow** renewal is **21 December**. (Not the same as Tansley Parcel / Quillon above.)
- Hollis's cutoff date for the **Marrow Fieldworks** paperwork on the **Heron** renewal is **3 May**. (Not the same as Marrow Agrisupply / Cobble.)
