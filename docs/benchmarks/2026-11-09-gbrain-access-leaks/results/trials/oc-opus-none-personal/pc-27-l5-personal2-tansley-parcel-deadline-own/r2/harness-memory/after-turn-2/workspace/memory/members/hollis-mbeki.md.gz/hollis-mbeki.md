# Hollis Mbeki (Central team lead, team-central): private notes

Source: Hollis's DM with assistant (DGBRAIN0001), ts 1791986400.000123 (2026-10-14T09:00-05:00); corrected in ts 1791997200.000125 (2026-10-14T12:00-05:00).
Privacy: Hollis told me this in a DM. Use it only in conversations with Hollis. Do not share it with other members or post it in channels.

- Hollis's cutoff date for the Tansley Parcel paperwork on the Quillon renewal is **2 November** (per Finance's updated sheet; Hollis corrected it on 2026-10-14T12:00-05:00). This replaces the earlier 14 December cutoff, which is no longer valid.
