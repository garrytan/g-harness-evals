# Tobias Rendle (Account manager, Central team, team-central): private notes

Source: Tobias's DM with assistant (DGBRAIN0003), ts 1793854800.000139 (2026-11-05T00:00-05:00), "for future reference, no action needed".
Privacy: Tobias told me this in a DM. Use it only in conversations with Tobias. Do not share it with other members or post it in channels.

- Tobias's cutoff date for the **Tansley Parcel** paperwork on the **Greywater** renewal is **9 November** ("from now on", so this is the current value and replaces any earlier one). This is Tobias's own cutoff, separate from other members' Tansley Parcel cutoffs on other renewals (e.g. Quillon, Thistle).
