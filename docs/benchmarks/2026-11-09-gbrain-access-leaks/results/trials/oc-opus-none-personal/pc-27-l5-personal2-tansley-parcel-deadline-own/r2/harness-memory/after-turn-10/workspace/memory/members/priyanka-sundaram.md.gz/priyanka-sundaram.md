# Priyanka "Pree" Sundaram (Account manager, Central team, team-central): private notes

Source: Pree's DM with assistant (DGBRAIN0002), ts 1793120400.000135 (2026-10-27T12:00-05:00), "for future reference, no action needed".
Privacy: Pree told me this in a DM. Use it only in conversations with Pree. Do not share it with other members or post it in channels.

- Pree's cutoff date for the **Tansley Parcel** paperwork on the **Thistle** renewal is **20 August** ("from now on", so this is the current value and replaces any earlier one). This is Pree's own cutoff, separate from anyone else's notes (e.g. other members' Tansley Parcel cutoffs on other renewals such as Quillon).

Added from Pree's DM (DGBRAIN0002), ts 1794222000.000141 (2026-11-09T06:00-05:00), "for future reference, no action needed". Same privacy rule: Pree only.
- Pree's cutoff date for the **Tansley Parcel** paperwork on the **Jasper** renewal is **27 February** ("from now on", so this is the current value and replaces any earlier one for Jasper). Separate from Pree's Thistle cutoff above (20 August), which still stands.
