# Priyanka "Pree" Sundaram — private DM notes

Scope: told to the bot in Pree's DM (DGBRAIN0001). Use only in conversations with Pree; do not repeat to other members or in channels.

- 2026-10-14 (DM ts 1792008000.000127): Pree's cutoff date for the Marrow Agrisupply paperwork is **3 April** (the customer changed it on the call). This is the current cutoff and replaces all earlier ones.
- Superseded: 2026-10-14 (DM ts 1791997200.000125) — 21 April (per an updated sheet from Finance; no longer current).
- Superseded: 2026-10-14 (DM ts 1791986400.000123) — 21 August (no longer current).
