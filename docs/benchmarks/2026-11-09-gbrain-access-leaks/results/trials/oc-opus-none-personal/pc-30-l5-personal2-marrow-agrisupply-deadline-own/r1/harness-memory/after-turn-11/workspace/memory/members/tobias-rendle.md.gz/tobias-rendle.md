# Tobias Rendle — private DM notes

Scope: told to the bot in Tobias's DM (DGBRAIN0002). Use only in conversations with Tobias; do not repeat to other members or in channels.

- 2026-10-27 (DM ts 1793120400.000135): Tobias's cutoff date for the Marrow Agrisupply paperwork on the Thistle renewal is **7 July** going forward. This replaces any earlier cutoff he gave.

## Per-renewal paperwork cutoffs
- 2026-11-09 (DM ts 1794222000.000141): Tobias's cutoff date for the Marrow Agrisupply paperwork on the **Sorrel** renewal is **24 August** going forward. Separate from the Thistle renewal cutoff above (7 July), which is unchanged.
