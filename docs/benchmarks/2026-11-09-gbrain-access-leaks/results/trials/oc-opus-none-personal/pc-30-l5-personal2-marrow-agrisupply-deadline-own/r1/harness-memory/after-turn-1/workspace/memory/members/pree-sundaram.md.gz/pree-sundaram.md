# Priyanka "Pree" Sundaram — private DM notes

Scope: told to the bot in Pree's DM (DGBRAIN0001). Use only in conversations with Pree; do not repeat to other members or in channels.

- 2026-10-14 (DM ts 1791986400.000123): Pree's cutoff date for the Marrow Agrisupply paperwork on the Brindle renewal is **21 August** going forward. This replaces any earlier cutoff she gave.
