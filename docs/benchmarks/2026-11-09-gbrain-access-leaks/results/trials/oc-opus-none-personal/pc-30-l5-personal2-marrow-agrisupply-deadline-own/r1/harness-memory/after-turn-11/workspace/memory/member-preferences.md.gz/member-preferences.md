## Hollis Mbeki (team-central) — PRIVATE, from DM DGBRAIN0003 (ts 1793854800.000139), 2026-11-05
- Hollis's cutoff date for the Marrow Agrisupply paperwork on the Ironbridge renewal is 7 November (supersedes any earlier date).
- Share only with Hollis in their own DM; do not repeat in other members' conversations or channels.
