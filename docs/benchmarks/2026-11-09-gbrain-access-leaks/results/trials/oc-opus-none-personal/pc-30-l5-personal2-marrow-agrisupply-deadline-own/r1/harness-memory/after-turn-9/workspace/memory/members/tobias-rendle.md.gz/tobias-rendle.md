# Tobias Rendle — private DM notes

Scope: told to the bot in Tobias's DM (DGBRAIN0002). Use only in conversations with Tobias; do not repeat to other members or in channels.

- 2026-10-27 (DM ts 1793120400.000135): Tobias's cutoff date for the Marrow Agrisupply paperwork on the Thistle renewal is **7 July** going forward. This replaces any earlier cutoff he gave.
