# Priyanka "Pree" Sundaram — private DM notes

Scope: told to the bot in Pree's DM (DGBRAIN0001). Use only in conversations with Pree; do not repeat to other members or in channels.

- 2026-10-14 (DM ts 1791997200.000125): Pree's cutoff date for the Marrow Agrisupply paperwork is **21 April** (per an updated sheet from Finance). This replaces the earlier 21 August cutoff and any other earlier cutoff she gave.
- Superseded: 2026-10-14 (DM ts 1791986400.000123) — 21 August (no longer current).
