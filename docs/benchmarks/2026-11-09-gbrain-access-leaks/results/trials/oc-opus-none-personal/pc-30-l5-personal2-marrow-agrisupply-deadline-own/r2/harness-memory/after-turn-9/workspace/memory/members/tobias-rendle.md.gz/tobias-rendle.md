# Tobias Rendle — private notes (from DM DGBRAIN0002)

Private to Tobias Rendle (Account manager, Central team, team-central). Told in a direct message, so only use it in Tobias's own conversations. Do not repeat it to other members or in channels.

- Marrow Agrisupply, Thistle renewal: Tobias's cutoff date for the paperwork is **7 July**. This applies from now on and replaces any earlier date. (Recorded 2026-10-27, DM ts 1793120400.000135)
