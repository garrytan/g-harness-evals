# Private notes from Pree Sundaram (DM DGBRAIN0001) — do not share outside Pree's own DM
- 2026-10-14: Pree's cutoff date for the Marrow Agrisupply paperwork is 3 April (customer changed it on a call). Supersedes any earlier date she gave.
# Private notes from Pree Sundaram (DM DGBRAIN0001) — do not share with other members or channels
- 2026-10-14 18:00 CT: Marrow Agrisupply paperwork cutoff date is **10 October 2026** (customer changed it on a call). Supersedes any earlier date Pree gave. No earlier date found on record.
