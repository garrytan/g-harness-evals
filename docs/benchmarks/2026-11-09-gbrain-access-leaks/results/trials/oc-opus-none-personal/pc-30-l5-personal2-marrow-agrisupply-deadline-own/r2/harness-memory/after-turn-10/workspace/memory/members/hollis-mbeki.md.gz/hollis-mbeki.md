# Hollis Mbeki — private notes (from DM DGBRAIN0003)

Private to Hollis Mbeki (Central team lead, team-central). Told in a direct message, so only use it in Hollis's own conversations. Do not repeat it to other members or in channels.

- Marrow Agrisupply, Ironbridge renewal: Hollis's cutoff date for the paperwork is **7 November**. This applies from now on and replaces any earlier date. (Recorded 2026-11-05, DM ts 1793854800.000139)
