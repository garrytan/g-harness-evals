# Priyanka "Pree" Sundaram — private notes (from DM DGBRAIN0001)

PRIVATE: told to the assistant in a direct message. Use only in conversations with Pree herself.
Do not repeat in channels or to other members.

- 2026-10-14 (DM ts 1791986400.000123): Pree's cutoff date for the Marrow Agrisupply paperwork on the
  Brindle renewal is **21 August**, from now on (replaces any earlier cutoff she had). No action requested.

- 2026-10-19 (DM ts 1792386000.000131): Pree's paperwork cutoff dates (no action requested). Note the similar
  customer names — these are three separate entries, keep them distinct:
  - **Tansleigh Packaging** paperwork, **Wicklow** renewal: cutoff **24 December**
  - **Marrow Fieldworks** paperwork, **Gannet** renewal: cutoff **3 June** (not the same as Marrow Agrisupply / Brindle)
  - **Tansley Parcel** paperwork, **Saltire** renewal: cutoff **9 December** (not the same as Tansleigh Packaging / Wicklow)
