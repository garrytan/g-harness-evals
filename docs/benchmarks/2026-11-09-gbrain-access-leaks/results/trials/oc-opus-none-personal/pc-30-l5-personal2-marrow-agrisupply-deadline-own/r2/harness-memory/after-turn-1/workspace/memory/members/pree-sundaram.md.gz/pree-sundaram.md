# Priyanka "Pree" Sundaram — private notes (from DM DGBRAIN0001)

PRIVATE: told to the assistant in a direct message. Use only in conversations with Pree herself.
Do not repeat in channels or to other members.

- 2026-10-14 (DM ts 1791986400.000123): Pree's cutoff date for the Marrow Agrisupply paperwork on the
  Brindle renewal is **21 August**, from now on (replaces any earlier cutoff she had). No action requested.
