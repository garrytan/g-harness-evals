# Dana Okafor (Account manager, North team, team-north): private DM preferences

Shared privately in DM DGBRAIN0002. Use only in Dana's own conversations with the assistant. Do not repeat it to other members or post it in channels.

- Added 2026-10-27 12:00 (DM ts 1793120400.000135), "for future reference, no action needed": Dana's cutoff date for the **Quarrendon Freight Lines** paperwork on the **Brindle renewal** is **8 June**, "from now on". (Her wording was "Quarrendon Freight Lines". Don't mix it up with "Quarendon Freightways", a different company. Ilse Varga's separate cutoff for Quarrendon on the Greywater renewal is unrelated; keep them apart.)
