# Marcus Lindqvist (Account manager, North team, team-north): private DM preferences

Shared privately in DM DGBRAIN0003. Use only in Marcus's own conversations with the assistant. Do not repeat it to other members or post it in channels.

- Set 2026-11-05 (DM ts 1793854800.000140): Marcus's cutoff date for the **Quarrendon Freight Lines** paperwork on the **Kestrel renewal** is **20 August**, from now on. This replaces any earlier cutoff. (His wording was "Quarrendon Freight Lines". Don't mix it up with "Quarendon Freightways", or with other members' cutoffs for other renewals.)
