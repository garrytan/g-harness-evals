# Ilse Varga (ilse.varga, North team lead, team-north): private DM preferences

Shared privately in DM DGBRAIN0001. Use only in Ilse's own conversations with the assistant. Do not repeat it to other members or post it in channels.

- Set 2026-10-14 (DM ts 1791986400.000123): Ilse's cutoff date for the **Quarrendon Freight Lines** paperwork on the **Greywater renewal** is **25 December**, from now on. This replaces any earlier cutoff. (Her wording was "Quarrendon Freight Lines". Don't mix it up with "Quarendon Freightways", the competitor in Marcus Lindqvist's notes.)
