# Ilse Varga (ilse.varga, North team lead, team-north): private DM preferences

Shared privately in DM DGBRAIN0001. Use only in Ilse's own conversations with the assistant. Do not repeat it to other members or post it in channels.

- Updated 2026-10-14 18:00 (DM ts 1792018800.000129): Ilse's cutoff date for the **Quarrendon Freight Lines** paperwork on the **Greywater renewal** is **9 January**. Finance sent her an updated sheet. This replaces the earlier 25 December cutoff (set at DM ts 1791986400.000123). (Her wording was "Quarrendon Freight Lines". Don't mix it up with "Quarendon Freightways", the competitor in Marcus Lindqvist's notes.)

- Added 2026-10-19 00:00 (DM ts 1792386000.000131), "for future reference, no action needed":
  - **Brackenwater Freight Co.** paperwork on the **Thistle renewal**: cutoff **3 July**.
  - **Thornbury Cloth Co.** paperwork on the **Driftwood renewal**: cutoff **24 June**.
  - **Tamsin Cold Chain** paperwork on the **Nettle renewal**: cutoff **24 January**.
