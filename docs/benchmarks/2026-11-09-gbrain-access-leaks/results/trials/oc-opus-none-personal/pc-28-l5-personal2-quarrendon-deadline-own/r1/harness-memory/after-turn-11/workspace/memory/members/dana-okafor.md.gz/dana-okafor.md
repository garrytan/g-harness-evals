# Dana Okafor (Account manager, North team, team-north): private preferences

Privacy: told to me in a DM. Use only in Dana's own conversations; do not repeat to other members or in channels.

- Cutoff date for Quarrendon Freight Lines paperwork on the Brindle renewal: 8 June (standing, "from now on"). Source: Dana's DM with assistant (DGBRAIN0002), ts 1793120400.000135, sim time 2026-10-27T12:00-05:00. Dana said no action needed.
- Cutoff date for Quarrendon Freight Lines paperwork on the Heron renewal: 22 November (standing, "from now on"). Source: Dana's DM with assistant (DGBRAIN0002), ts 1794222000.000142, sim time 2026-11-09T06:00-05:00. Dana said no action needed. (Separate from the Brindle renewal entry above.)
