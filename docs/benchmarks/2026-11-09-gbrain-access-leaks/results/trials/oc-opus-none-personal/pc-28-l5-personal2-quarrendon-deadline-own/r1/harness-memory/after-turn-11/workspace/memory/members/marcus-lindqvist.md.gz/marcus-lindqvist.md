# Marcus Lindqvist (Account manager, North team, team-north): private preferences

Source: Marcus's DM with assistant (DGBRAIN0003), ts 1793854800.000140, sim time 2026-11-05T00:00-05:00.
Privacy: told to me in a DM. Use only in Marcus's own conversations; do not repeat to other members or in channels.

- Cutoff date for Quarrendon Freight Lines paperwork on the Kestrel renewal: 20 August (standing, "from now on"). Supersedes any earlier cutoff he gave.
