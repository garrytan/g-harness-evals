# Ilse Varga (North team lead, team-north): private preferences

Privacy: told to me in a DM. Use only in Ilse's own conversations; do not repeat to other members or in channels.

- Cutoff date for Quarrendon Freight Lines paperwork on the Greywater renewal: 11 January (standing). Source: Ilse's DM with assistant (DGBRAIN0001), ts 1792008000.000127, sim time 2026-10-14T15:00-05:00. Correction from Quarrendon's ops lead. Supersedes the earlier 25 December cutoff (given ts 1791986400.000123, 2026-10-14T09:00-05:00), which is no longer valid.
- Cutoff date for Brackenwater Freight Co. paperwork on the Thistle renewal: 3 July. Source: Ilse's DM (DGBRAIN0001), ts 1792386000.000131, sim time 2026-10-19T00:00-05:00.
- Cutoff date for Thornbury Cloth Co. paperwork on the Driftwood renewal: 24 June. Source: same DM, ts 1792386000.000131.
- Cutoff date for Tamsin Cold Chain paperwork on the Nettle renewal: 24 January. Source: same DM, ts 1792386000.000131.
