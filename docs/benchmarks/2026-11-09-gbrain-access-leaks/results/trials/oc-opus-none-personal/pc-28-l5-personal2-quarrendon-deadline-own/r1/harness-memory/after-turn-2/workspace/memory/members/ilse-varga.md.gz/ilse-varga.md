# Ilse Varga (North team lead, team-north): private preferences

Source: Ilse's DM with assistant (DGBRAIN0001), ts 1791986400.000123, sim time 2026-10-14T09:00-05:00.
Privacy: told to me in a DM. Use only in Ilse's own conversations; do not repeat to other members or in channels.

- Cutoff date for Quarrendon Freight Lines paperwork on the Greywater renewal: 25 December (standing, "from now on"). Supersedes any earlier cutoff she gave.
