# Marcus Lindqvist (Account manager, North team, team-north)

Private: told to me in Marcus's DM (DGBRAIN0002). Don't share in other members' conversations or channels.

- Told 2026-10-27 (DM ts 1793088000.000129): Marcus's standing call with the Brackenwater Freight Co. team for the Heron rollout is Wednesdays at 16:15, from now on. (No time zone given; probably company time, not confirmed.) Marcus asked for no action, so nothing was put on the calendar.
