# Hollis Mbeki (Central team lead, team-central)

Private: told to me in Hollis's DM (DGBRAIN0004). Only use in conversations with Hollis; don't share in other members' conversations or channels.

- Told 2026-11-08 (DM ts 1794189600.000135): Hollis's standing call with the Brackenwater Freight Co. team for the Gannet rollout is Fridays at 12:30, from now on. (No time zone given; probably company time, not confirmed.) Hollis asked for no action, so nothing was put on the calendar.
