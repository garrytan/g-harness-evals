# Tobias Rendle (Account manager, Central team, team-central)

Private: told to me in Tobias's DM (DGBRAIN0003). Only use in conversations with Tobias; don't share in other members' conversations or channels.

- Told 2026-11-04 (DM ts 1793822400.000133): Tobias's standing call with the Brackenwater Freight Co. team for the Driftwood rollout is Tuesdays at 10:30, from now on. (No AM/PM or time zone given; probably 10:30 AM company time, not confirmed.) Tobias asked for no action, so nothing was put on the calendar.
