# Dana Okafor (Account manager, North team, team-north) — private, from DM DGBRAIN0001

Only use these notes in conversations with Dana. Do not share in other members' conversations or in channels.

- Told 2026-10-14 (DM ts 1791986400.000123): Dana's standing call with the Brackenwater Freight Co. team for the Keystone rollout is Tuesdays at 8:30, going forward. (Dana said "8:30" with no AM/PM or time zone; probably 8:30 AM company time, but this isn't confirmed.) Dana asked for no calendar action.
- Told 2026-10-18 (DM ts 1792353600.000125): Dana's standing call with the Thornbury Cloth Co. team for the Thistle rollout is Thursdays at 9:30. Dana asked for no calendar action.
- Told 2026-10-18 (DM ts 1792353600.000125): Dana's standing call with the Tamsin Cold Chain team for the Petrel rollout is Wednesdays at 11:15. Dana asked for no calendar action.
- Told 2026-10-18 (DM ts 1792353600.000125): Dana's standing call with the Quarrendon Freight Lines team for the Bittern rollout is Tuesdays at 11:45. Dana asked for no calendar action.
  (For all three, Dana gave no AM/PM or time zone; probably AM company time, but this isn't confirmed.)
