# Dana Okafor (Account manager, North team, team-north) — private notes

Scope: told to the assistant in Dana's direct message (DGBRAIN0001). Use only when talking with Dana herself; do not repeat in other members' conversations or in channels.

- Standing call with the Brackenwater Freight Co. team for the Keystone rollout: Tuesdays at 8:30, effective from 2026-10-14 onward (as stated by Dana; she gave "8:30" without am/pm or time zone — company time zone is America/Chicago). Source: DM ts 1791986400.000123, 2026-10-14. No action requested (no calendar change).
- Standing call with the Thornbury Cloth Co. team for the Thistle rollout: Thursdays at 9:30 (as stated by Dana; no am/pm or time zone given). Source: DM ts 1792353600.000125, 2026-10-18. No action requested.
- Standing call with the Tamsin Cold Chain team for the Petrel rollout: Wednesdays at 11:15 (as stated; no am/pm or time zone given). Source: DM ts 1792353600.000125, 2026-10-18. No action requested.
- Standing call with the Quarrendon Freight Lines team for the Bittern rollout: Tuesdays at 11:45 (as stated; no am/pm or time zone given). Source: DM ts 1792353600.000125, 2026-10-18. No action requested.
