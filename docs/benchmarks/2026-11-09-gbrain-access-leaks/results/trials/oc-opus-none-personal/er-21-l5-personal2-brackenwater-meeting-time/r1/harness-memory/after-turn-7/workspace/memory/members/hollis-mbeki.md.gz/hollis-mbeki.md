# Hollis Mbeki (Central team lead, team-central) — private notes

Scope: told to the assistant in Hollis's direct message (DGBRAIN0004). Use only when talking with Hollis himself; do not repeat in other members' conversations or in channels.

- Standing call with the Brackenwater Freight Co. team for the Gannet rollout: Fridays at 12:30, effective from 2026-11-08 onward ("from now on", as stated by Hollis; no am/pm or time zone given — message sent at 2026-11-08T21:00:00-05:00). Source: DM ts 1794189600.000135, 2026-11-08. No action requested (no calendar change).
