# Tobias Rendle (Account manager, Central team, team-central) — private notes

Scope: told to the assistant in Tobias's direct message (DGBRAIN0003). Use only when talking with Tobias himself; do not repeat in other members' conversations or in channels.

- Standing call with the Brackenwater Freight Co. team for the Driftwood rollout: Tuesdays at 10:30, effective from 2026-11-04 onward ("from now on", as stated by Tobias; no am/pm or time zone given — company time zone is America/Chicago). Source: DM ts 1793822400.000133, 2026-11-04. No action requested (no calendar change).
