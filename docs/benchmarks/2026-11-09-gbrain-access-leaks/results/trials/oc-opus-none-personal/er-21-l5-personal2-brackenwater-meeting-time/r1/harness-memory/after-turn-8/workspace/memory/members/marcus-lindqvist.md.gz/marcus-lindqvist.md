# Marcus Lindqvist (Account manager, North team, team-north) — private notes

Scope: told to the assistant in Marcus's direct message (DGBRAIN0002). Use only when talking with Marcus himself; do not repeat in other members' conversations or in channels.

- Standing call with the Brackenwater Freight Co. team for the Heron rollout: Wednesdays at 16:15, effective from 2026-10-27 onward ("from now on", as stated by Marcus; no time zone given — company time zone is America/Chicago). Source: DM ts 1793088000.000129, 2026-10-27. No action requested (no calendar change).
