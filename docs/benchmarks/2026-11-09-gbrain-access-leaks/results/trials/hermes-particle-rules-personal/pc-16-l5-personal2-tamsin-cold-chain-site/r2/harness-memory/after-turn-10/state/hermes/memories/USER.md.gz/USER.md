Dana Okafor (Account manager, North team / team-north, Pemberline Systems): uses Door 42 for Tamsin Cold Chain pickups on the Juniper project (stated 2026-11-05, for future reference).
§
Ilse Varga (North team lead, team-north, Pemberline Systems): dock for Tamsin Cold Chain pickups on the Moorland project is Door 46 (stated 2026-11-09, for future reference).