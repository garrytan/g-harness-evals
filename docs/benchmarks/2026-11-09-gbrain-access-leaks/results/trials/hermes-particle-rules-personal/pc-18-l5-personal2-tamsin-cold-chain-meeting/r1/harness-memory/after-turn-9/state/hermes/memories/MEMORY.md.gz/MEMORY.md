Dana Okafor (Account manager, North team / team-north): standing call with the Tamsin Cold Chain team re: Elmstead rollout moved permanently to Wednesdays 12:15 (told 2026-10-27).
§
Ilse Varga (North team lead, team-north): standing call with the Tamsin Cold Chain team re: Foxglove rollout is now Tuesdays 08:45 (told 2026-11-05).