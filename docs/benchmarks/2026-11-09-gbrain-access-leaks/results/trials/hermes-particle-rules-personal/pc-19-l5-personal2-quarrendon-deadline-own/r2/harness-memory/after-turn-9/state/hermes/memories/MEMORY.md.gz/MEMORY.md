Marcus Lindqvist (account manager, North team/team-north) set his cutoff date for the Quarrendon Freight Lines paperwork on the Moorland renewal to 24 April, effective from 2026-10-27. Told via DM, no action requested.
§
Ilse Varga's (North team lead) cutoff date for the Quarrendon Freight Lines paperwork on the Quillon renewal is 24 December — set 2026-11-05, no action requested.