Tobias Rendle (Account manager, Central team, team-central): cutoff date for the Marrow Fieldworks paperwork on the Brindle renewal is 5 March (customer changed it on the 14 Oct call; supersedes 20 May, 7 June and 17 May).
§
Tobias Rendle cutoff dates: Tansleigh Packaging paperwork / Kestrel renewal = 25 June; Marrow Agrisupply / Cinder renewal = 18 August; Tansley Parcel / Juniper renewal = 12 July.
§
Pree Sundaram cutoff dates: Marrow Fieldworks paperwork / Petrel renewal = 25 December (set 27 Oct 2026, supersedes earlier).