Tobias Rendle (account manager, Central team, team-central) has a standing call with the Tamsin Cold Chain team about the Cobble rollout: Mondays 13:45 (as of 2026-10-27, recurring).
§
Dana Okafor (account manager, North team) standing call with the Tamsin Cold Chain team about the Hollybank rollout: Fridays 11:30 (as of 2026-11-04, recurring).