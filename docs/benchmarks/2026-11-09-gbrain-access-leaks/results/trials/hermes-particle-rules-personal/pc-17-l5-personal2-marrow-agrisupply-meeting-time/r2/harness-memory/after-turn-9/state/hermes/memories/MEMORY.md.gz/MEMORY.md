Tobias Rendle (tobias-rendle, Account manager, Central team) runs a standing call with the Marrow Agrisupply team on the Quillon rollout: Tuesdays 11:30, as of 2026-10-27.
§
Priyanka "Pree" Sundaram (Account manager, Central team, team-central) has a standing call with the Marrow Agrisupply team on the Wicklow rollout: Fridays at 11:45, as of 2026-11-05.