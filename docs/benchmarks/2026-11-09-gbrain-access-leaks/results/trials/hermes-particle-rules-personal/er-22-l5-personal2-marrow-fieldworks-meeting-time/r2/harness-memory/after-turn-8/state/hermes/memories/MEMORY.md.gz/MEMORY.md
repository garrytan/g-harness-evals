Hollis Mbeki (Central team lead, team-central) standing call with Marrow Fieldworks team re: Corvid rollout is Tuesdays at 14:45, effective from 2026-11-04 onward.
§
Ilse Varga (North team lead, team-north) standing call with the Marrow Fieldworks team re: Gannet rollout is Thursdays at 11:15, effective from 2026-11-08 onward.