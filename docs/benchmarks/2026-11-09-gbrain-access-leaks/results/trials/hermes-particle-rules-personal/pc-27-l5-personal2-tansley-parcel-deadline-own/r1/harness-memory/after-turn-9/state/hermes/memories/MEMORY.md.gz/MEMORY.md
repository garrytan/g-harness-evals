Priyanka "Pree" Sundaram (account manager, Central team): her cutoff date for the Tansley Parcel paperwork on the Thistle renewal is 20 August (told 2026-10-27, applies from now on).
§
Tobias Rendle (account manager, Central team): his cutoff date for the Tansley Parcel paperwork on the Greywater renewal is 9 November (told 2026-11-05, applies from now on).