# Changelog

## Unreleased

## 0.9.0

- Add additional Unicode table styles.
