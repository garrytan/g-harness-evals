The application under test is in /work/app. Write your reports to /work/out/repros/.
