#!/bin/bash
# Starts the app on http://127.0.0.1:8080 in the background.
cd /work/app
nohup python3 app.py --port 8080 --data /work/app/data > /work/app/server.log 2>&1 &
for i in $(seq 50); do curl -fs http://127.0.0.1:8080/ >/dev/null && echo "app running on http://127.0.0.1:8080" && exit 0; sleep 0.2; done
echo "app did not start; see /work/app/server.log"; exit 1
