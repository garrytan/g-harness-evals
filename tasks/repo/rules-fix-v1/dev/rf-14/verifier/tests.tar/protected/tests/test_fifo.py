import unittest

from cachetools import FIFOCache

from . import CacheTestMixin


class FIFOCacheTest(unittest.TestCase, CacheTestMixin):
    Cache = FIFOCache

    def test_fifo(self):
        import copy

        cache = FIFOCache[int, int](maxsize=2)

        cache[1] = 1
        cache[2] = 2
        cache[3] = 3

        self.assertEqual(len(cache), 2)
        self.assertEqual(cache[2], 2)
        self.assertEqual(cache[3], 3)
        self.assertNotIn(1, cache)

        cache[2]
        # a shallow copy evicts in the same order, on its own
        self.assertEqual((2, 2), copy.copy(cache).popitem())
        cache[4] = 4
        self.assertEqual(len(cache), 2)
        self.assertEqual(cache[3], 3)
        self.assertEqual(cache[4], 4)
        self.assertNotIn(2, cache)

        cache[5] = 5
        self.assertEqual(len(cache), 2)
        self.assertEqual(cache[4], 4)
        self.assertEqual(cache[5], 5)
        self.assertNotIn(3, cache)

    def test_fifo_getsizeof(self):
        cache = FIFOCache[int, int](maxsize=3, getsizeof=lambda x: x)

        cache[1] = 1
        cache[2] = 2

        self.assertEqual(len(cache), 2)
        self.assertEqual(cache[1], 1)
        self.assertEqual(cache[2], 2)

        cache[3] = 3

        self.assertEqual(len(cache), 1)
        self.assertEqual(cache[3], 3)
        self.assertNotIn(1, cache)
        self.assertNotIn(2, cache)

        with self.assertRaises(ValueError):
            cache[4] = 4
        self.assertEqual(len(cache), 1)
        self.assertEqual(cache[3], 3)

    def test_fifo_update_existing(self):
        cache = FIFOCache[int, int | str](maxsize=2)

        cache[1] = 1
        cache[2] = 2
        cache[1] = "updated"
        cache[3] = 3

        self.assertEqual(cache[1], "updated")
        self.assertIn(3, cache)
        self.assertNotIn(2, cache)
