# Changelog

## Unreleased

- Added: column options by name

## 0.11.3

- Fixed: Maintenance release.
