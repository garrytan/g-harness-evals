# Changelog

## Unreleased

- Added: 12h times (7:30pm) in at()

## 1.2.2

- Fixed: Jobs scheduled with until() and a time zone are cancelled on time.
