# Changelog

## Unreleased

- Added group_by

## 1.1.0

- Added: Python 3.14 support.
