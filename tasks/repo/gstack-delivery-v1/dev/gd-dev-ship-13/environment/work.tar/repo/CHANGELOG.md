# Changelog

## Unreleased

- Acronyms!! (camelize/underscore/humanize/titleize)

## 0.5.1

- Fixed: Type hints for every public function.
