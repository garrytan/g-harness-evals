# Changelog

## Unreleased

- shape() recipe

## 11.2.1

- Fixed: Type stubs for the running statistics recipes.
