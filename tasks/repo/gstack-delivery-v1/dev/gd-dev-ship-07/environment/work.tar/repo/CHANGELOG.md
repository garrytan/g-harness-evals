# Changelog

## Unreleased

- new weighted_mean

## 11.2.1

- Fixed: Type stubs for the running statistics recipes.
