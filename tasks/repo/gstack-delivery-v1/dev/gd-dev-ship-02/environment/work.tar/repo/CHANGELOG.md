# Changelog

## Unreleased

- Added: html_attrs helper

## 0.14.0

- Changed: Maintenance release.
