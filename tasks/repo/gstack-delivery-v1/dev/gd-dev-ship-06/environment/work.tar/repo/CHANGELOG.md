# Changelog

## Unreleased

- argmin/argmax: new default + last kwargs

## 11.2.1

- Fixed: Type stubs for the running statistics recipes.
