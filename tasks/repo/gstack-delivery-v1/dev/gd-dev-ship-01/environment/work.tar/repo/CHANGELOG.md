# Changelog

## Unreleased

- add rule api (plural/singular/irregular/uncountable)

## 0.5.1

- Fixed: Type hints for every public function.
