# Changelog

## Unreleased

- Added: parse_spec

## 1.2.2

- Fixed: Jobs scheduled with until() and a time zone are cancelled on time.
