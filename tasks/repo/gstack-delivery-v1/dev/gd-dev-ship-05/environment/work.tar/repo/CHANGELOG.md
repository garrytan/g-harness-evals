# Changelog

## Unreleased

- Added: string functions

## 1.1.0

- Added: Python 3.14 support.
