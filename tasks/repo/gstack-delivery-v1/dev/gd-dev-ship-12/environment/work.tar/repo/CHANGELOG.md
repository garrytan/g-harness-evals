# Changelog

## Unreleased

- Added to_identifier()

## 0.5.1

- Fixed: Type hints for every public function.
